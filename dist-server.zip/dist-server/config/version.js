'use strict';

var version = {
    JS_VERSION: '4.2.21',
    CSS_VERSION: '4.2.18',
    ASSETS_VERSION: '4.2'
};

module.exports = version;