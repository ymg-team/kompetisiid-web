'use strict';

var version = {
    JS_VERSION: '4.2.22',
    CSS_VERSION: '4.2.19',
    ASSETS_VERSION: '4.2'
};

module.exports = version;