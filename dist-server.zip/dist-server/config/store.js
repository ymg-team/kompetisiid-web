'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _redux = require('redux');

var _reduxThunk = require('redux-thunk');

var _reduxThunk2 = _interopRequireDefault(_reduxThunk);

var _api = require('../store/middlewares/api');

var _api2 = _interopRequireDefault(_api);

var _reduxLogger = require('redux-logger');

var _reduxLogger2 = _interopRequireDefault(_reduxLogger);

var _reducer = require('../store/kompetisi/reducer');

var _reducer2 = _interopRequireDefault(_reducer);

var _reducer3 = require('../store/berita/reducer');

var _reducer4 = _interopRequireDefault(_reducer3);

var _reducer5 = require('../store/pasang/reducer');

var _reducer6 = _interopRequireDefault(_reducer5);

var _reducer7 = require('../store/user/reducer');

var _reducer8 = _interopRequireDefault(_reducer7);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// reducers
var Middlewares = void 0;

if (process.env.NODE_ENV == 'production' || typeof window == 'undefined') {
  Middlewares = (0, _redux.applyMiddleware)(_api2.default, _reduxThunk2.default);
} else {
  Middlewares = (0, _redux.applyMiddleware)(_api2.default, (0, _reduxLogger2.default)(), _reduxThunk2.default);
}

var Reducers = (0, _redux.combineReducers)({
  Kompetisi: _reducer2.default,
  Berita: _reducer4.default,
  Pasang: _reducer6.default,
  User: _reducer8.default
});

var preloadedState = typeof window != 'undefined' ? window.__data__ : {};

exports.default = (0, _redux.createStore)(Reducers, preloadedState, Middlewares);