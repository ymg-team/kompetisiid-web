'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.default = function (req, res) {
    var _req$reqdata = req.reqdata,
        method = _req$reqdata.method,
        url = _req$reqdata.url,
        _req$reqdata$params = _req$reqdata.params,
        params = _req$reqdata$params === undefined ? {} : _req$reqdata$params,
        nextaction = _req$reqdata.nextaction,
        _req$reqdata$resType = _req$reqdata.resType,
        resType = _req$reqdata$resType === undefined ? 'json' : _req$reqdata$resType;

    var debugApiReq = require('debug')('app:api-req');
    var debugApiRes = require('debug')('app:api-res');

    params.resType = resType;
    // log
    debugApiReq(method.toUpperCase() + ' ' + (process.env.API_HOST + url) + ' at ' + new Date().toISOString().replace(/T/, ' ').replace(/\..+/, ''));
    return (0, _apiCaller.requestAPIV2)(method, url, params).then(function (response) {

        // log 
        debugApiRes(method.toUpperCase() + ' ' + (process.env.API_HOST + url) + ' response status ' + response.statusCode + ' at ' + new Date().toISOString().replace(/T/, ' ').replace(/\..+/, ''));
        if (nextaction) nextaction(result);
        if (resType === 'json') res.json(response.body);
        if (resType === 'text') res.end(response.body);
        if (resType === 'xml') {
            var xml = require('xml');
            res.set('Content-Type', 'text/xml');
            res.end(xml(response.body));
        }
    });
};

var _apiCaller = require('../../helpers/apiCaller');