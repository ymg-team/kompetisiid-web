"use strict";

Object.defineProperty(exports, "__esModule", {
   value: true
});
exports.addToken = addToken;
function addToken(req, res, next) {
   return next();
}