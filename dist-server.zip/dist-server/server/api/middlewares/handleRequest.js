'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.post = post;

var _formidable = require('formidable');

var _formidable2 = _interopRequireDefault(_formidable);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function post(req, res, next) {
    var form = new _formidable2.default.IncomingForm();
    form.uploadDir = '/tmp';
    form.parse(req, function (err, fields, files) {
        var params = fields;
        params.files = files;
        req.params = Object.assign({}, req.params, params);
        next();
    });
} /**
   * Created by yussan on 13/11/16.
   */