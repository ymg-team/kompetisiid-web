'use strict';

var _express = require('express');

var _express2 = _interopRequireDefault(_express);

var _user = require('../controllers/user');

var controller = _interopRequireWildcard(_user);

var _handleRequest = require('../middlewares/handleRequest');

var requestMiddleware = _interopRequireWildcard(_handleRequest);

var _apiCaller = require('../middlewares/apiCaller');

var _apiCaller2 = _interopRequireDefault(_apiCaller);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Created by yussan on 13/11/16.
 */
var router = _express2.default.Router();

router.get('/:username', controller.getProfile, _apiCaller2.default);
router.post('/login', requestMiddleware.post, controller.postLogin, _apiCaller2.default);
router.post('/register', requestMiddleware.post, controller.postRegister, _apiCaller2.default);
router.post('/logout', requestMiddleware.post, controller.postLogout, _apiCaller2.default);
router.post('/emailverification', requestMiddleware.post, controller.postEmailVerification, _apiCaller2.default);

module.exports = router;