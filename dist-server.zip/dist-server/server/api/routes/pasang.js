'use strict';

var _express = require('express');

var _express2 = _interopRequireDefault(_express);

var _pasang = require('../controllers/pasang');

var controller = _interopRequireWildcard(_pasang);

var _handleRequest = require('../middlewares/handleRequest');

var requestMiddleware = _interopRequireWildcard(_handleRequest);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var router = _express2.default.Router(); /**
                                          * Created by yussan on 13/11/16.
                                          */


router.post('/cepat', requestMiddleware.post, controller.postCepat);

module.exports = router;