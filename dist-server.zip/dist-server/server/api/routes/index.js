'use strict';

var _express = require('express');

var _express2 = _interopRequireDefault(_express);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var router = _express2.default.Router();

router.use('/kompetisi', require('./kompetisi'));
router.use('/jelajah', require('./jelajah'));
router.use('/news', require('./news'));
router.use('/pasang', require('./pasang'));
router.use('/user', require('./user'));

module.exports = router;