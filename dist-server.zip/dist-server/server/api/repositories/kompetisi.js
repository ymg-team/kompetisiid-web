'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getCategories = getCategories;
exports.getJelajah = getJelajah;
exports.getDetail = getDetail;
exports.getPengumuman = getPengumuman;
exports.getRelated = getRelated;
exports.getFavoritedtag = getFavoritedtag;

var _apiCaller = require('../../helpers/apiCaller');

function getCategories(callback) {
    (0, _apiCaller.requestAPI)('get', '/kategori/kategori', {}, function (response) {
        callback(response);
    });
}

function getJelajah(params, callback) {
    var Url = params.query.popular && parseInt(params.query.popular) === 1 ? '/jelajah/popular' : '/jelajah';
    (0, _apiCaller.requestAPI)('get', Url, params, function (response) {
        callback(response);
    });
}

function getDetail(id, callback) {
    (0, _apiCaller.requestAPI)('get', '/kompetisi/data/' + id, {}, function (response) {
        callback(response);
    });
}

function getPengumuman(id, callback) {
    (0, _apiCaller.requestAPI)('get', '/kompetisi/pengumuman/' + id, {}, function (response) {
        callback(response);
    });
}

function getRelated(id, callback) {
    (0, _apiCaller.requestAPI)('get', '/kompetisi/related/' + id, {}, function (response) {
        callback(response);
    });
}

function getFavoritedtag(params, callback) {
    (0, _apiCaller.requestAPI)('get', '/kompetisi/favoritedtags', {}, function (response) {
        callback(response);
    });
}