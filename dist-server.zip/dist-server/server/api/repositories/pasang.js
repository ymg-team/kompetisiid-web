'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.postCepat = postCepat;

var _apiCaller = require('../../helpers/apiCaller');

function postCepat(params, callback) {
    return (0, _apiCaller.requestAPI)('post', '/pasang/cepat', params, function (response) {
        callback(response);
    });
} /**
   * Created by yussan on 13/11/16.
   */