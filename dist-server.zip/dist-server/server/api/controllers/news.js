'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getNews = getNews;
exports.getRelated = getRelated;
exports.getNewsDetail = getNewsDetail;
/**
 * الرَّحِيم الرَّحْمَنِ اللَّهِ بِسْمِ
 * created by yussan 23 Oct 2016 18:29
 */

function getNews(req, res, next) {
    var params = req.params;

    params.query = req.query;
    req.reqdata = {
        method: 'get',
        params: params,
        url: '/berita/list'
    };

    next();
}

function getRelated(req, res, next) {
    var params = req.params;

    params.query = req.query;
    req.reqdata = {
        method: 'get',
        params: params,
        url: '/berita/related/' + req.params.id
    };

    next();
}

function getNewsDetail(req, res, next) {
    req.reqdata = {
        method: 'get',
        params: req.params,
        url: '/berita/read/' + req.params.id
    };

    next();
}