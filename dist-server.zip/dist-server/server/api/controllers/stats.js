'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getStats = getStats;
/**
 * function to get stats data
 */
function getStats(req, res, next) {
    req.reqdata = {
        method: 'get',
        url: '/stats'
    };

    next();
}