'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.postCepat = postCepat;

var _pasang = require('../repositories/pasang');

var repo = _interopRequireWildcard(_pasang);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function postCepat(req, res) {
    return repo.postCepat(req.params, function (response) {
        res.json(response);
    });
} /**
   * الرَّحِيم الرَّحْمَنِ اللَّهِ بِسْمِ
   * Created by yussan on 13/11/16.
   */