'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getJelajah = getJelajah;
exports.getRelated = getRelated;
exports.getCategories = getCategories;
exports.getDetail = getDetail;
exports.getFavoritedtag = getFavoritedtag;
exports.getPengumuman = getPengumuman;

var _kompetisi = require('../repositories/kompetisi');

var repo = _interopRequireWildcard(_kompetisi);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

/***
 * function to get kompetisi list
 * @method GET
 * @query limit (int)
 * @query popular (boolean), default not set
 * @query mediapartner (boolean), default not set
 * @query garansi (boolean), default not set
 * @query support (boolean), default not set
 * @query berakhir (boolean), default not set
 * @query lastid (string), encoded last id, use to load more data
 * @query firstid (string), encoded first id, use to load new data
 * @query mainkat (int), id main category
 * @query subkat (int), id sub category
 * @query tag (string), tag
 * @query q (string), keyboard to searching
 */
function getJelajah(req, res, next) {
    var url = req.query.popular && parseInt(req.query.popular) === 1 ? '/jelajah/popular' : '/jelajah';
    var params = req.params;

    params.query = req.query;
    req.reqdata = {
        method: 'get',
        params: req.params,
        url: url
    };

    next();
}

/**
 *  function to get related competition
 *  @method GET
 *  @params (string) encid on url
 */
function getRelated(req, res) {
    repo.getRelated(req.params.id, function (response) {
        return res.json(response);
    });
}

/**
 * function to get all categories available
 * @method GET
 */
function getCategories(req, res) {
    repo.getCategories(function (response) {
        return res.json(response);
    });
}

/**
 * function to get detail competition
 * @method GET
 * @param (string) encoded id
 */
function getDetail(req, res) {
    repo.getDetail(req.params.id, function (response) {
        return res.json(response);
    });
}

/**
 * function to get favorited tag
 */
function getFavoritedtag(req, res) {
    repo.getFavoritedtag({}, function (response) {
        return res.json(response);
    });
}

/**
 * function to get pengumuman kompetisi
 * @method GET
 * @param (string) encoded id
 */
function getPengumuman(req, res) {
    repo.getPengumuman(req.params.id, function (response) {
        return res.json(response);
    });
}