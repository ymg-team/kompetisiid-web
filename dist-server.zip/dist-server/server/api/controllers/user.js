'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getProfile = getProfile;
exports.postLogin = postLogin;
exports.postRegister = postRegister;
exports.postLogout = postLogout;
exports.postEmailVerification = postEmailVerification;

var _session = require('../../helpers/session');

var Session = _interopRequireWildcard(_session);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function getProfile(req, res, next) {
    req.reqdata = {
        method: 'get',
        params: req.params,
        url: '/user/profile/' + req.params.username
    };

    next();
} /**
   * الرَّحِيم الرَّحْمَنِ اللَّهِ بِسْمِ
   * Created by yussan on 13/11/16.
   */

function postLogin(req, res, next) {
    req.reqdata = {
        method: 'post',
        url: '/user/login',
        params: req.params,
        nextaction: function nextaction(result) {
            if (result.meta.code === 201) Session.setData(req, 'userdata', result);
        }
    };

    next();
}

function postRegister(req, res, next) {
    req.reqdata = {
        method: 'post',
        url: '/user/register',
        params: req.params,
        nextaction: function nextaction(result) {
            if (result.meta.code === 201) Session.setData(req, 'userdata', result);
        }
    };

    next();
}

function postLogout(req, res, next) {
    req.reqdata = {
        method: 'post',
        url: '/user/logout',
        params: req.params,
        nextaction: function nextaction(result) {
            Session.destroy(req, 'userdata');
        }
    };

    next();
}

function postEmailVerification(req, res, next) {
    req.reqdata = {
        method: 'post',
        url: '/user/emailverification?token=' + req.query.token,
        params: req.params,
        nextaction: function nextaction(result) {
            if (result.meta.code === 201) {
                var nextdata = req.session.userdata;
                if (nextdata) {
                    nextdata.data.is_verified = 1;
                    Session.update(req, 'userdata', nextdata);
                }
            }
        }
    };

    next();
}