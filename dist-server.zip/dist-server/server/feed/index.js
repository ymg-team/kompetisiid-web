'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _express = require('express');

var _express2 = _interopRequireDefault(_express);

var _apiCaller = require('../api/middlewares/apiCaller');

var _apiCaller2 = _interopRequireDefault(_apiCaller);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Created by yussan on 17/02/17.
 */
var Router = _express2.default.Router();

/**
 * Function to get feed kompetisi
 * @method GET
 * @route /feed
 * @return mixed
 */
Router.get('/', function (req, res, next) {
    req.reqdata = {
        method: 'get',
        url: '/feed',
        resType: 'text'
    };
    next();
}, _apiCaller2.default);

/**
 * Function to get feed berita
 * @method GET
 * @route /feed/berita
 * @return mixed
 */
Router.get('/berita', function (req, res, next) {
    req.reqdata = {
        method: 'get',
        url: '/feed/berita',
        resType: 'text'
    };
    next();
}, _apiCaller2.default);

/**
 * Function to get feed berita
 * @method GET
 * @route /feed/berita
 * @return mixed
 */
Router.get('/news', function (req, res, next) {
    req.reqdata = {
        method: 'get',
        url: '/feed/berita',
        resType: 'text'
    };
    next();
}, _apiCaller2.default);

exports.default = Router;