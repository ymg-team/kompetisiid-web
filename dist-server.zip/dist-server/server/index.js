#!/usr/bin/env node
'use strict';

var _app = require('./app');

var _app2 = _interopRequireDefault(_app);

var _http = require('http');

var _http2 = _interopRequireDefault(_http);

var _cluster = require('cluster');

var _cluster2 = _interopRequireDefault(_cluster);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var Port = process.env.KI_PORT || 1470;

if (_cluster2.default.isMaster && process.env.NODE_ENV === 'production') {
    var NumWorkers = require('os').cpus().length;
    console.log('Master cluster setting up ' + NumWorkers + ' workers');

    for (var i = 0; i < NumWorkers; i++) {
        _cluster2.default.fork();
    }

    _cluster2.default.on('online', function (worker) {
        console.log('Worker ' + worker.process.pid + ' is online');
    });

    _cluster2.default.on('exit', function (worker, code, signal) {
        console.log('Worker ' + worker.process.pid + ' died with code ' + code + ' and signal ' + signal + ' ');
        console.log('Starting new worker');
        _cluster2.default.fork();
    });
} else {
    var onError = function onError(error) {
        console.log(error);

        if (error.syscall !== 'listen') {
            throw error;
        }

        var bind = typeof port === 'string' ? 'Pipe ' + Port : 'Port ' + Port;

        // handle specific listen errors with friendly messages
        switch (error.code) {
            case 'EACCES':
                console.error(bind + ' requires elevated privileges');
                process.exit(1);
                break;
            case 'EADDRINUSE':
                console.error(bind + ' is already in use');
                process.exit(1);
                break;
            default:
                throw error;
        }
    };

    var onListening = function onListening() {
        var addr = Server.address();
        var bind = typeof addr === 'string' ? 'pipe ' + addr : 'port ' + addr.port;
        console.log('Listening on ' + bind);
    };

    //start server
    _app2.default.set('port', Port);

    var Server = _http2.default.createServer(_app2.default);

    Server.listen(Port);
    Server.on('error', onError);
    Server.on('listening', onListening);
}