'use strict';

var _app = require('./app');

var _app2 = _interopRequireDefault(_app);

var _cluster = require('cluster');

var _cluster2 = _interopRequireDefault(_cluster);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var Port = process.env.KI_PORT || 1470;

if (_cluster2.default.isMaster && process.env.NODE_ENV === 'production') {
    var NumWorkers = require('os').cpus().length;
    console.log('Master cluster setting up ' + NumWorkers + ' workers');

    for (var i = 0; i < NumWorkers; i++) {
        _cluster2.default.fork();
    }

    _cluster2.default.on('online', function (worker) {
        console.log('Worker ' + worker.process.pid + ' is online');
    });

    _cluster2.default.on('exit', function (worker, code, signal) {
        console.log('Worker ' + worker.process.pid + ' died with code ' + code + ' and signal ' + signal + ' ');
        console.log('Starting new worker');
        _cluster2.default.fork();
    });
} else {
    //start server
    _app2.default.listen(Port, function () {
        console.log('Server is listening on port: ' + Port);
    });
}