'use strict';

var _express = require('express');

var _express2 = _interopRequireDefault(_express);

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _server = require('react-dom/server');

var _server2 = _interopRequireDefault(_server);

var _reactRouter = require('react-router');

var _LocationUtils = require('history/LocationUtils');

var _history = require('history');

var _routes = require('../client/routes');

var _routes2 = _interopRequireDefault(_routes);

var _version = require('../config/version');

var _version2 = _interopRequireDefault(_version);

var _store = require('../config/store');

var _store2 = _interopRequireDefault(_store);

var _reactHelmet = require('react-helmet');

var _reactHelmet2 = _interopRequireDefault(_reactHelmet);

var _webpackAssets = require('../config/webpack-assets');

var _webpackAssets2 = _interopRequireDefault(_webpackAssets);

var _reactRedux = require('react-redux');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Created by yussan on 02/10/16.
 */
var App = (0, _express2.default)();

// server rendering
module.exports = App.use(function (req, res) {
    var location = (0, _LocationUtils.createLocation)(req.url);
    (0, _reactRouter.match)({ routes: _routes2.default, location: location }, function (err, redirectLocation, renderProps) {
        if (err) return res.status(500).end('internal server error');
        if (!renderProps) return res.status(404).end('not found');

        // preloaded state
        var preloadedState = _store2.default.getState();

        //start render
        getReduxPromise().then(function () {
            var html = '';

            preloadedState = _store2.default.getState();
            var userdata = req.session.userdata;

            if (userdata && userdata.meta && userdata.meta.code == 201) {
                delete userdata.data.password;
                delete userdata.data.token;
                preloadedState.User.session = Object.assign({}, userdata);
            }
            try {
                html = _server2.default.renderToString(_react2.default.createElement(
                    _reactRedux.Provider,
                    { store: _store2.default },
                    _react2.default.createElement(_reactRouter.RouterContext, renderProps)
                ));
            } catch (e) {
                console.error(e);
                return res.status(500).send('error rendering');
            }

            var head = _reactHelmet2.default.rewind();
            res.send(renderFullPage(head, html, preloadedState, req.session).replace(/\s\s+/g, ""));
        });

        function getReduxPromise() {
            var location = renderProps.location,
                params = renderProps.params;

            var history = (0, _history.createMemoryHistory)();
            var comp = renderProps.components[renderProps.components.length - 1].WrappedComponent;

            var promise = comp && comp.fetchData ? comp.fetchData({ query: location.query, params: params, store: _store2.default, history: history, token: req.session.token }) : Promise.resolve();

            return promise;
        }
    });
});

function renderFullPage(head, html, state) {
    // <link href="/assets/4.2/css/style.css?v=${version.CSS_VERSION}" rel="stylesheet">
    // <script type="text/javascript" src="/assets/4.2/js/script-min.js?v=${version.JS_VERSION}"></script>
    return '\n        <!DOCTYPE html>\n        <html lang="id-id">\n            <head>\n                ' + head.title.toString() + '\n                ' + head.meta.toString() + '\n                ' + head.style.toString() + '\n                ' + head.link.toString() + '\n                <meta charset="utf-8" />\n                <meta http-equiv="X-UA-Compatible" content="IE=edge" />\n                <meta name="viewport" content="width=device-width, initial-scale=1" />\n                <meta property="fb:app_id" content="1419514554927551" />\n                <meta property="fb:admins" content="xyussanx" />\n                <meta property="fb:pages" content="309615952470901" />\n                <meta name="viewport" content="width=device-width, initial-scale=1" />\n                <meta name="google-signin-client_id" content="362573543654-djkou7th41pu964e7qs32ggogn1rbah6.apps.googleusercontent.com">\n                <meta name="google-site-verification" content="pUksy8ewwm4bzRVqaTQXKmWfRFZc9_L0iuESNDg7190" />\n                <meta property="fb:app_id" content="1419514554927551">\n                <meta property="fb:admins" content="100000359263988">\n                <link href="https://d33wubrfki0l68.cloudfront.net/bundles/bf8f3056db2faef1b6689a08130044818eefc58d.css" rel="stylesheet">\n                <link href="/assets/4.2/lib/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet">\n                <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">\n                <link rel="icon" href="/assets/icons/icon-128x128.png" />\n                <link rel="manifest" href="/manifest.json" />\n                <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="Cari Kompetisi"/>\n            </head>\n            <body>\n                <div id="root">' + html + '</div>\n                <div id="fb-root"></div>\n                ' + head.script.toString() + '\n                ' + getScript(state) + '\n            </body>\n        </html>\n    ';
}

// initial script
function getScript(state) {
    return '\n    <script>\n        if(\'serviceWorker\' in navigator)\n        {\n            navigator.serviceWorker.register(\'/service-worker.js\')\n                .then(function(registration){\n                    console.log(registration);\n                }).catch(function(err){\n                    console.log(\'ServiceWorker registration is failed\', err);\n                });\n        }\n    </script>  \n    <script type="text/javascript">window.__data__ = ' + JSON.stringify(state) + '</script>\n    <script type="text/javascript" src="https:////connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.8&appId=1419514554927551" async defer></script>\n    <script type="text/javascript" src="https://apis.google.com/js/platform.js" async defer></script>\n    <script type="text/javascript" src="https://d33wubrfki0l68.cloudfront.net/js/89ab2d780125b7a9d3b5c5b0f8aca8b03ad69933/js/script-min.js"></script>\n    <script src="' + _webpackAssets2.default.vendor.js + '"></script>\n    <script src="' + _webpackAssets2.default.app.js + '"></script>\n    ' + (process.env.NODE_ENV === 'production' ? getTrackingScript() : '') + '\n    ' + getAdsenseScript() + '\n    ';
}

// adsense script
function getAdsenseScript() {
    return '\n    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>\n    ';
}

// tracking script
function getTrackingScript() {
    return '\n    <!-- Histats.com  START  (aync)-->\n    <script type="text/javascript">var _Hasync= _Hasync|| [];\n    _Hasync.push([\'Histats.start\', \'1,2475171,4,0,0,0,00010000\']);\n    _Hasync.push([\'Histats.fasi\', \'1\']);\n    _Hasync.push([\'Histats.track_hits\', \'\']);\n    (function() {\n    var hs = document.createElement(\'script\'); hs.type = \'text/javascript\'; hs.async = true;\n    hs.src = (\'//s10.histats.com/js15_as.js\');\n    (document.getElementsByTagName(\'head\')[0] || document.getElementsByTagName(\'body\')[0]).appendChild(hs);\n    })();</script>\n    <noscript><a href="/" target="_blank"><img  src="//sstatic1.histats.com/0.gif?2475171&101" alt="web stats" border="0"></a></noscript>\n    <!-- Histats.com  END  -->    \n\n    <!-- Ganal -->\n    <script>\n    (function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){\n    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),\n    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)\n    })(window,document,\'script\',\'https://www.google-analytics.com/analytics.js\',\'ga\');\n    ga(\'create\', \'UA-44428186-4\', \'auto\');\n    ga(\'send\', \'pageview\');\n    </script>\n    <!-- end of Ganal -->\n    ';
}