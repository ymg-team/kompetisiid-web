'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _express = require('express');

var _express2 = _interopRequireDefault(_express);

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _cookieParser = require('cookie-parser');

var _cookieParser2 = _interopRequireDefault(_cookieParser);

var _cookieSession = require('cookie-session');

var _cookieSession2 = _interopRequireDefault(_cookieSession);

var _api = require('./api');

var _api2 = _interopRequireDefault(_api);

var _feed = require('./feed');

var _feed2 = _interopRequireDefault(_feed);

var _render = require('./render');

var _render2 = _interopRequireDefault(_render);

var _compression = require('compression');

var _compression2 = _interopRequireDefault(_compression);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var App = (0, _express2.default)();

App.disable('x-powered-by');

if (process.env.NODE_ENV === 'production') {
    App.use((0, _compression2.default)());
}

App.use((0, _cookieParser2.default)());
App.use((0, _cookieSession2.default)({
    secret: 'kindoyasds6&^USdgsudsiuGs6d6',
    name: 'ki_session',
    maxAge: 12 * 30 * 24 * 60 * 60 * 1000
}));

var staticOptions = function staticOptions() {
    if (process.env.NODE_ENV == 'production') {
        return {
            maxAge: 172800000,
            etag: false
        };
    } else {
        return {};
    }
};

// global midleware
App.use(function (req, res, next) {
    if (!req.session.token) req.session.token = 'ki-324892374skljfhlsiudfh&6';
    // log
    var debugReq = require('debug')('app:req');
    debugReq(req.method + ' ' + req.originalUrl + ' at ' + new Date().toISOString().replace(/T/, ' ').replace(/\..+/, ''));
    next();
});

// static files
App.use('/robot.txt', _express2.default.static(__dirname + '/../../public/robot.txt'));
App.use('/opensearch.xml', _express2.default.static(__dirname + '/../../public/opensearch.xml'));
App.use('/manifest.json', _express2.default.static(__dirname + '/../../public/manifest.json'));
App.use('/service-worker.js', _express2.default.static(__dirname + '/../../public/service-worker.js'));
App.use('/build', _express2.default.static(_path2.default.resolve(__dirname + '/../../dist-client'), staticOptions()));
App.use('/assets', _express2.default.static(_path2.default.resolve(__dirname + '/../../public/assets'), staticOptions()));

// app routes
App.use('/api', _api2.default);
App.use('/feed', _feed2.default);
App.get('*', _render2.default);

function checkAuth(req, res, next) {
    if (req.url === '/login' && req.session.userdata && req.session.userdata.meta) return res.redirect('/');
    next();
}

exports.default = App;