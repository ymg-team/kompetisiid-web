'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getData = getData;
exports.setData = setData;
exports.update = update;
exports.destroy = destroy;
/**
 * Created by yussan on 28/01/17.
 */
function getData(req, key) {
    return req.session && req.session[key] ? req.session[key] : {};
}

function setData(req, key, data) {
    return new Promise(function (resolve, reject) {
        if (data.remember) req.sessionOptions.maxAge = 'Session';
        var nextsession = req.session.length > 0 ? req.session : {};
        nextsession[key] = data;
        req.session = nextsession;
        resolve();
    });
}

function update(req, key, nextdata) {
    return new Promise(function (resolve, reject) {
        var nextsession = req.session.length > 0 ? req.session : {};
        nextsession[key] = Object.assign({}, nextsession[key], nextdata);
        req.session = nextsession;
        resolve();
    });
}

function destroy(req, key) {
    return new Promise(function (resolve, reject) {
        delete req.session[key];
        resolve();
    });
}