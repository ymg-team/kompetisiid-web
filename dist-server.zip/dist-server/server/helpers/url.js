'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.serialize = serialize;
function serialize(obj) {
  var str = [];

  for (var p in obj) {
    if (obj.hasOwnProperty(p)) str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
  }

  return str.join('&');
}