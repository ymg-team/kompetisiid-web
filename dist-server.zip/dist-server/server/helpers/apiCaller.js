'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.requestAPI = requestAPI;
exports.requestAPIV2 = requestAPIV2;

var _request = require('request');

var _request2 = _interopRequireDefault(_request);

var _Exceptions = require('../../store/helpers/Exceptions');

var _url = require('./url');

var Url = _interopRequireWildcard(_url);

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _host = require('../../config/host');

var _host2 = _interopRequireDefault(_host);

var _https = require('https');

var _https2 = _interopRequireDefault(_https);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var API_HOST = _host2.default[process.env.NODE_ENV].api;
// generate agent
var agentOptions = new _https2.default.Agent({
    rejectUnauthorized: false
});

/**
 * function to get data from API
 * @params (string) method, (string) endpoint, (object) params
 */
function requestAPI() {
    var method = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'GET';
    var endpoint = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
    var params = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    var callback = arguments[3];

    // TODO : change static token to dinamic token
    var token = '';
    if (params.token) {
        token = params.token;
        delete params.token;
    }

    //set query
    if (params.query) {
        endpoint = endpoint + '?' + Url.serialize(params.query);
        delete params.query;
    }

    //set options
    var options = {
        method: method,
        uri: API_HOST + endpoint,
        timeout: 60000,
        // resolved from : https://stackoverflow.com/questions/20433287/node-js-request-cert-has-expired#answer-29397100
        agentOptions: agentOptions,
        headers: {
            token: token,
            'User-Agent': 'request',
            'Content-Type': 'json'
        }

        // using POST method
    };if (method.toLowerCase() === 'post') {
        options.formData = params;

        // upload files
        if (options.formData.files) {
            var files = options.formData.files;
            delete options.formData.files;

            Object.keys(files).map(function (n) {
                options.formData[n] = {
                    value: _fs2.default.createReadStream(files[n]._writeStream.path),
                    options: {
                        filename: files[n].name,
                        type: files[n].type
                    }
                };
            });
        }
    }

    //start request
    try {
        (0, _request2.default)(options, function (error, response, body) {
            // console.log(`response from ${options.uri}: `)

            if (error) {
                console.error('error endpoint :' + endpoint, error);
                return callback((0, _Exceptions.httpException)(500));
            } else //success
                {
                    var json = isJSON(body);
                    if (json) {
                        return callback(json);
                    } else {
                        return callback((0, _Exceptions.httpException)(500, 'error response : json not valid'));
                    }
                }
        });
    } catch (err) {
        return callback((0, _Exceptions.httpException)(500, 'error endpoint :' + endpoint + ' ,' + err.message + ', ' + err.stack));
    }
}

/**
 * function to get data from API version 2
 * using promise
 * @params (string) method, (string) endpoint, (object) params
 */
function requestAPIV2() {
    var method = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'GET';
    var endpoint = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
    var params = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

    var token = '';
    if (params.token) {
        token = params.token;
        delete params.token;
    }

    //set query
    if (params.query) {
        endpoint = endpoint + '?' + Url.serialize(params.query);
        delete params.query;
    }

    //set options
    var options = {
        method: method,
        uri: API_HOST + endpoint,
        timeout: 60000,
        agentOptions: agentOptions,
        headers: {
            token: token,
            'User-Agent': 'request'
            // 'Content-Type' : 'json',
        }

        // using POST method
    };if (method.toLowerCase() === 'post') {
        options.formData = params;

        // upload files
        if (options.formData.files) {
            var files = options.formData.files;

            delete options.formData.files;

            Object.keys(files).map(function (n) {
                options.formData[n] = {
                    value: _fs2.default.createReadStream(files[n]._writeStream.path),
                    options: {
                        filename: files[n].name,
                        type: files[n].type
                    }
                };
            });
        }
    }

    //start request
    return new Promise(function (resolve, reject) {
        try {
            (0, _request2.default)(options, function (error, response, body) {
                // console.log(`response from ${options.uri}: `)

                if (error) {
                    console.error('error endpoint :' + endpoint, error);
                    return resolve((0, _Exceptions.httpException)(500));
                } else //success
                    {
                        if (params.resType === 'json') {
                            var json = isJSON(body);
                            if (json) return resolve({ body: json, statusCode: response.statusCode });
                        }

                        return resolve({ body: body, statusCode: response.statusCode });
                    }
            });
        } catch (err) {
            return resolve((0, _Exceptions.httpException)(500, 'error endpoint :' + endpoint + ' ,' + err.message + ', ' + err.stack));
        }
    });
}

function isJSON(str) {
    if (typeof str !== 'string') {
        return false;
    } else {
        try {
            var json = JSON.parse(str);
            return json;
        } catch (e) {
            return false;
        }
    }
}