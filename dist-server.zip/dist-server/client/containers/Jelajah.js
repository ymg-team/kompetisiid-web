'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _Kompetisi = require('../components/box/Kompetisi');

var _Kompetisi2 = _interopRequireDefault(_Kompetisi);

var _actions = require('../../store/kompetisi/actions');

var KompetisiActions = _interopRequireWildcard(_actions);

var _Filter = require('../components/jelajah/Filter');

var _Filter2 = _interopRequireDefault(_Filter);

var _reactHelmet = require('react-helmet');

var _reactHelmet2 = _interopRequireDefault(_reactHelmet);

var _reactRouter = require('react-router');

var _LocalStorage = require('../../store/helpers/LocalStorage');

var _reactRedux = require('react-redux');

var _redux = require('redux');

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var icon_default = '/assets/images/icon-1.jpg';

var icon = ['/assets/images/icon-2.jpg'];

var Jelajah = function (_React$Component) {
    _inherits(Jelajah, _React$Component);

    _createClass(Jelajah, null, [{
        key: 'fetchData',
        value: function fetchData(_ref) {
            var store = _ref.store,
                params = _ref.params,
                query = _ref.query;

            var State = generateState(query, params);
            var Filter = generateFilter(State);
            var Params = generateParams(State);
            return store.dispatch(KompetisiActions.fetchJelajah(Params, Filter));
        }
    }]);

    function Jelajah(props) {
        _classCallCheck(this, Jelajah);

        var _this2 = _possibleConstructorReturn(this, (Jelajah.__proto__ || Object.getPrototypeOf(Jelajah)).call(this, props));

        _this2.state = generateState(_this2.props.location.query, _this2.props.params);
        return _this2;
    }

    _createClass(Jelajah, [{
        key: 'componentDidMount',
        value: function componentDidMount() {
            window.scrollTo(0, 0);
            //get categories
            var Categories = (0, _LocalStorage.getStorage)('categories');
            if (Categories) {
                this.props.dispatch(KompetisiActions.setCategories(JSON.parse(Categories)));
            } else {
                this.props.dispatch(KompetisiActions.getCategories());
            }

            var _this = this;

            this.setState(setCategories(this.props, this.state));

            window.addEventListener('scroll', function () {
                var Scrollpx = $(this).scrollTop();
                var ContainerHeight = $('#jelajah-container').height();
                if (Scrollpx >= ContainerHeight - 250) _this.reqMoreData();
            });
        }
    }, {
        key: 'componentWillReceiveProps',
        value: function componentWillReceiveProps(np) {
            this.setState(Object.assign(generateState(np.location.query, np.params), setCategories(np, this.state)));
        }
    }, {
        key: 'generateTitle',
        value: function generateTitle() {
            var categories = this.props.kompetisi.categories;
            var _state = this.state,
                main_kat = _state.main_kat,
                sub_kat = _state.sub_kat,
                tag = _state.tag;

            var title = 'Jelajah';
            if (main_kat != '') title = title + ' > ' + categories.data[main_kat].main_kat;
            if (sub_kat != '') title = title + ' > ' + categories.data[main_kat].subkat[sub_kat].sub_kat;
            if (tag != '') title = title + ' > tag : \'' + tag + '\'';
            if (this.state.q && this.state.q != '') title = title + ' > pencarian : \'' + this.state.q + '\'';
            return title;
        }
    }, {
        key: 'reqData',
        value: function reqData() {
            var Filter = generateFilter(this.state);
            var Params = generateParams(this.state, this.props);
            if (!this.props.kompetisi.data[Filter]) {
                this.props.dispatch(KompetisiActions.fetchJelajah(Params, Filter));
            }
        }
    }, {
        key: 'reqMoreData',
        value: function reqMoreData() {
            var Filter = generateFilter(this.state);
            var Params = generateParams(this.state, this.props);
            var Kompetisi = this.props.kompetisi.data[Filter] ? this.props.kompetisi.data[Filter].data : null;
            if (Kompetisi) {
                if (!this.props.kompetisi.data[Filter].is_loading && this.props.kompetisi.data[Filter].meta.code === 200) {
                    Params.lastid = Kompetisi[Kompetisi.length - 1].id_kompetisi;
                    this.props.actions.getJelajahMore(Params, Filter);
                }
            }
        }
    }, {
        key: 'render',
        value: function render() {
            var _this3 = this;

            var _state2 = this.state,
                tag = _state2.tag,
                username = _state2.username;

            var title = 'Jelajah - Kompetisi Indonesia';
            var description = 'Jelajahi kompetisi dari berbagai macam kategori di Kompetisi Indonesia';

            //jelajah kompetisi by tag
            if (tag != '') {
                title = 'Jelajah - Tag : ' + tag;
                description = 'Jelajahi kompetisi berdasarkan tag ' + tag;
            }

            //jelajah kompetisi by username
            if (username != '') {
                title = 'Kompetisi dipasang oleh ' + username;
                description = 'Jelajahi kompetisi yang dipasang oleh ' + username;
            }

            return _react2.default.createElement(
                'div',
                null,
                _react2.default.createElement(_reactHelmet2.default, {
                    title: title,
                    meta: [{ 'name': 'description', 'content': description }, { 'property': 'og:title', 'content': title }, { 'property': 'og:url', 'content': 'http://kompetisi.id/browse' }, { 'property': 'og:image', 'content': 'http://kompetisi.id/assets/images/wide-red-logo.png' }, { 'property': 'og:description', 'content': description }, { 'property': 'og:type', 'content': 'article' }]
                }),
                _react2.default.createElement(
                    'div',
                    { className: 'bg-white' },
                    _react2.default.createElement(
                        'div',
                        { className: 'container' },

                        // accesing jelajah by tag or competition by user
                        tag != '' || username != '' ? _react2.default.createElement(
                            'div',
                            { className: 'col-lg-12' },
                            _react2.default.createElement('div', { className: 'clearfix' }),
                            _react2.default.createElement(
                                'div',
                                { className: 'header-jelajah small' },
                                tag != '' ? _react2.default.createElement(
                                    'p',
                                    null,
                                    'Jelajahi kompetisi berdasarkan tag "',
                                    tag,
                                    '"'
                                ) : null,
                                username != '' ? _react2.default.createElement(
                                    'p',
                                    null,
                                    'Jelajahi kompetisi, dipasang oleh "',
                                    _react2.default.createElement(
                                        _reactRouter.Link,
                                        { to: '/' + username },
                                        username
                                    ),
                                    '"'
                                ) : null
                            )
                        ) :
                        // else
                        _react2.default.createElement(
                            'div',
                            null,
                            _react2.default.createElement(
                                'div',
                                { className: 'col-lg-12' },
                                _react2.default.createElement('hr', null),
                                _react2.default.createElement('div', { className: 'clearfix' }),
                                _react2.default.createElement(
                                    'div',
                                    { className: 'media header-jelajah' },
                                    _react2.default.createElement(
                                        'div',
                                        { className: 'media-left media-middle' },
                                        _react2.default.createElement('img', { className: 'media-object', src: '/assets/images/icon-1.jpg', alt: '...' })
                                    ),
                                    _react2.default.createElement(
                                        'div',
                                        { className: 'media-body' },
                                        _react2.default.createElement(
                                            'div',
                                            { className: 'header-title medium color-red' },
                                            _react2.default.createElement(
                                                'h2',
                                                null,
                                                !this.props.kompetisi.categories.meta ? 'jelajah' : this.generateTitle()
                                            )
                                        ),
                                        _react2.default.createElement(
                                            'p',
                                            null,
                                            description,
                                            '. ',
                                            _react2.default.createElement(
                                                'small',
                                                { className: 'text-muted' },
                                                'image from freepik'
                                            )
                                        )
                                    )
                                ),
                                _react2.default.createElement('div', { className: 'clearfix' }),
                                _react2.default.createElement('hr', null)
                            ),
                            _react2.default.createElement('div', { className: 'clearfix' }),
                            _react2.default.createElement(_Filter2.default, {
                                categories: this.props.kompetisi.categories,
                                main_kat: this.state.main_kat,
                                sub_kat: this.state.sub_kat,
                                main_kat_name: this.props.params.mainkat,
                                sub_kat_name: this.props.params.subkat,
                                is_garansi: this.state.is_garansi,
                                is_mediapartner: this.state.is_mediapartner,
                                is_berakhir: this.state.is_berakhir,
                                q: this.state.q,
                                tag: this.state.tag,
                                changeState: function changeState(n) {
                                    return _this3.setState(n, function () {
                                        _this3.reqData();
                                    });
                                }
                            })
                        ),
                        _react2.default.createElement(
                            'div',
                            { className: 'col-lg-12' },
                            this.props.kompetisi.data[generateFilter(this.state)] && this.props.kompetisi.data[generateFilter(this.state)].data ? _react2.default.createElement(
                                'p',
                                null,
                                'menampilkan ',
                                _react2.default.createElement(
                                    'strong',
                                    null,
                                    this.props.kompetisi.data[generateFilter(this.state)].data.length
                                ),
                                ' dari ',
                                _react2.default.createElement(
                                    'strong',
                                    null,
                                    'banyak'
                                ),
                                ' kompetisi'
                            ) : _react2.default.createElement('br', null)
                        )
                    )
                ),
                _react2.default.createElement(
                    'div',
                    { id: 'jelajah-container' },
                    _react2.default.createElement(_Kompetisi2.default, {
                        params: generateParams(this.state, this.props),
                        filter: generateFilter(this.state),
                        data: this.props.kompetisi.data,
                        class_title: 'header-title medium color-red',
                        dispatch: this.props.dispatch
                    })
                )
            );
        }
    }]);

    return Jelajah;
}(_react2.default.Component);

function setCategories(props, state) {
    var main_kat = state.main_kat,
        sub_kat = state.sub_kat;

    if (props.kompetisi.categories.meta) {
        if (props.params.mainkat) {
            props.kompetisi.categories.data.map(function (n, key) {
                if (n.main_kat === props.params.mainkat) main_kat = key;
            });
        }

        if (props.params.subkat && props.kompetisi.categories.data[main_kat].subkat) {
            props.kompetisi.categories.data[main_kat].subkat.map(function (n, key) {
                if (n.sub_kat === props.params.subkat) sub_kat = key;
            });
        }
    }

    return {
        main_kat: main_kat,
        sub_kat: sub_kat
    };
}

function generateState(query, params) {
    var tag = params.tag,
        username = params.username;
    var mediapartner = query.mediapartner,
        berakhir = query.berakhir,
        garansi = query.garansi,
        q = query.q;


    return {
        main_kat: '',
        sub_kat: '',
        q: q || '',
        tag: tag || '',
        username: username || '',
        is_mediapartner: mediapartner && mediapartner == 1,
        is_berakhir: berakhir && berakhir == 1,
        is_garansi: garansi && garansi == 1
    };
}

function generateParams(n) {
    var props = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
    var main_kat = n.main_kat,
        sub_kat = n.sub_kat,
        is_mediapartner = n.is_mediapartner,
        is_berakhir = n.is_berakhir,
        q = n.q,
        tag = n.tag,
        username = n.username,
        is_garansi = n.is_garansi;

    var Params = {};
    if (props) {
        var categories = props.kompetisi.categories;

        if (main_kat != '') Params.mainkat = categories.data[main_kat].main_kat;
        if (sub_kat != '') Params.subkat = categories.data[main_kat].subkat[sub_kat].sub_kat;
    }
    if (q && q != '') Params.q = q;
    if (username && username != '') Params.username = username;
    if (tag && tag != '') Params.tag = tag;
    if (is_mediapartner) Params.mediapartner = 1;
    if (is_berakhir) Params.berakhir = 1;
    if (is_garansi) Params.garansi = 1;
    Params.limit = 10;

    return Params;
}

function generateFilter(n) {
    var main_kat = n.main_kat,
        sub_kat = n.sub_kat,
        is_mediapartner = n.is_mediapartner,
        is_berakhir = n.is_berakhir,
        q = n.q,
        tag = n.tag,
        is_garansi = n.is_garansi;

    var Filter = 'jelajah';
    if (main_kat != '') Filter = Filter + '_' + main_kat;
    if (sub_kat != '') Filter = Filter + '_' + sub_kat;
    if (q != '') Filter = Filter + '_' + q;
    if (tag != '') Filter = Filter + '_' + tag;
    Filter = Filter + '_' + is_mediapartner + '_' + is_berakhir + '_' + is_garansi;

    return Filter;
}

function mapStateToProps(state) {
    var Kompetisi = state.Kompetisi;


    return {
        kompetisi: Kompetisi
    };
}

function mapDispatchToProps(dispatch) {
    return {
        actions: (0, _redux.bindActionCreators)(Object.assign({}, KompetisiActions), dispatch),
        dispatch: dispatch
    };
}

exports.default = (0, _reactRedux.connect)(mapStateToProps, mapDispatchToProps)(Jelajah);