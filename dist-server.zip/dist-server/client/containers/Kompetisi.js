'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _TabContent = require('../components/kompetisi/TabContent');

var _TabContent2 = _interopRequireDefault(_TabContent);

var _actions = require('../../store/kompetisi/actions');

var KompetisiAct = _interopRequireWildcard(_actions);

var _SubHeader = require('../components/kompetisi/SubHeader');

var _SubHeader2 = _interopRequireDefault(_SubHeader);

var _KompetisiDetail = require('../components/card/KompetisiDetail');

var _KompetisiDetail2 = _interopRequireDefault(_KompetisiDetail);

var _reactRouter = require('react-router');

var _Kompetisi = require('../components/box/Kompetisi');

var _Kompetisi2 = _interopRequireDefault(_Kompetisi);

var _Author = require('../components/card/Author');

var _Author2 = _interopRequireDefault(_Author);

var _Warning = require('../components/kompetisi/Warning');

var _Warning2 = _interopRequireDefault(_Warning);

var _Helmet = require('../components/Helmet');

var _Helmet2 = _interopRequireDefault(_Helmet);

var _reactRedux = require('react-redux');

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Kompetisi = function (_React$Component) {
    _inherits(Kompetisi, _React$Component);

    _createClass(Kompetisi, null, [{
        key: 'fetchData',
        value: function fetchData(_ref) {
            var params = _ref.params,
                store = _ref.store;

            return store.dispatch(KompetisiAct.getDetail(params.encid));
        }
    }]);

    function Kompetisi(props) {
        _classCallCheck(this, Kompetisi);

        var _this = _possibleConstructorReturn(this, (Kompetisi.__proto__ || Object.getPrototypeOf(Kompetisi)).call(this, props));

        _this.state = {
            encid: _this.props.params.encid
        };
        return _this;
    }

    _createClass(Kompetisi, [{
        key: 'componentDidMount',
        value: function componentDidMount() {
            this.checkData(this.props);
        }
    }, {
        key: 'componentWillReceiveProps',
        value: function componentWillReceiveProps(nprops) {
            this.setState({ encid: nprops.params.encid });
            if (this.props.params.encid != nprops.params.encid) {
                this.checkData(nprops);
            }
        }
    }, {
        key: 'checkData',
        value: function checkData(props) {
            var encid = props.params.encid;

            if (props.route.name === 'competition_regulation') window.scrollTo(0, 0);
            if (!props.kompetisi.detail[encid]) this.props.dispatch(getDetail(encid));
        }
    }, {
        key: 'generateNextPrev',
        value: function generateNextPrev() {
            var encid = this.props.params.encid;
            var detail = this.props.kompetisi.detail;


            return _react2.default.createElement(
                'div',
                { className: 'row' },
                _react2.default.createElement(
                    'div',
                    { className: 'col-lg-6 col-md-6 col-sm-6 text-left' },
                    detail[encid].data.prev.id_kompetisi ? _react2.default.createElement(
                        _reactRouter.Link,
                        { to: '/kompetisi/detail/' + detail[encid].data.prev.id_kompetisi + '/' + detail[encid].data.prev.nospace_title },
                        _react2.default.createElement('i', { className: 'glyphicon glyphicon-chevron-left' }),
                        'sebelumnya',
                        _react2.default.createElement('br', null),
                        detail[encid].data.prev.title
                    ) : _react2.default.createElement('div', null)
                ),
                _react2.default.createElement(
                    'div',
                    { className: 'col-lg-6 col-md-6 col-sm-6 text-right' },
                    detail[encid].data.next.id_kompetisi ? _react2.default.createElement(
                        _reactRouter.Link,
                        { to: '/kompetisi/detail/' + detail[encid].data.next.id_kompetisi + '/' + detail[encid].data.next.nospace_title },
                        _react2.default.createElement('i', { className: 'glyphicon glyphicon-chevron-right' }),
                        'berikutnya',
                        _react2.default.createElement('br', null),
                        detail[encid].data.next.title
                    ) : _react2.default.createElement('div', null)
                )
            );
        }
    }, {
        key: 'render',
        value: function render() {
            var encid = this.state.encid;
            var _props$kompetisi = this.props.kompetisi,
                detail = _props$kompetisi.detail,
                pengumuman = _props$kompetisi.pengumuman;

            var helmetdata = {};

            if (detail[encid] && detail[encid].meta && parseInt(detail[encid].meta.code) === 200) {
                var tab = {
                    1: '',
                    2: 'Hadiah ',
                    3: 'Diskusi ',
                    4: 'Pengumuman ',
                    5: 'Kontak ',
                    6: 'Share '
                };
                helmetdata = {
                    title: '' + (tab[this.props.route.active_tab] || '') + detail[encid].data.title,
                    description: detail[encid].data.sort,
                    image: detail[encid].data.poster.original,
                    url: 'http://kompetisi.id/competition/' + detail[encid].data.id_kompetisi + '/regulations/' + detail[encid].data.nospace_title
                };
            } else {
                helmetdata = {
                    title: 'kompetisi tidak ditemukan',
                    description: 'kompetisi tidak ditemukan'
                };
            }
            return _react2.default.createElement(
                'div',
                null,
                _react2.default.createElement(_Helmet2.default, helmetdata),
                _react2.default.createElement('div', { className: 'clearfix' }),
                _react2.default.createElement(_SubHeader2.default, {
                    data: detail[encid]
                }),
                _react2.default.createElement('div', { className: 'p-15' }),
                detail[encid] && detail[encid].meta && parseInt(detail[encid].meta.code) === 200 ? _react2.default.createElement(
                    'div',
                    { className: 'bg-white' },
                    _react2.default.createElement(
                        'div',
                        { className: 'container' },
                        _react2.default.createElement('div', { className: 'clearfix' }),
                        _react2.default.createElement(
                            'div',
                            { className: 'col-md-12' },
                            _react2.default.createElement(_Warning2.default, { data: detail[encid].data })
                        ),
                        _react2.default.createElement(
                            'div',
                            { className: 'col-md-8' },
                            _react2.default.createElement(_TabContent2.default, {
                                data: detail[encid],
                                pengumuman: pengumuman,
                                encid: encid,
                                active: this.props.route.active_tab,
                                dispatch: this.props.dispatch
                            }),
                            detail[encid] && detail[encid].data ? _react2.default.createElement(_Author2.default, {
                                username: detail[encid].data.username,
                                created_at: detail[encid].data.created_at,
                                updated_at: detail[encid].data.updated_at
                            }) : null,
                            _react2.default.createElement('div', { className: 'clearfix' }),
                            detail[encid] && detail[encid].meta && parseInt(detail[encid].meta.code) === 200 ? this.generateNextPrev() : null
                        ),
                        _react2.default.createElement(_KompetisiDetail2.default, {
                            data: detail[encid]
                        }),
                        _react2.default.createElement('div', { className: 'clearfix' })
                    )
                ) : null,
                _react2.default.createElement(_Kompetisi2.default, {
                    title: 'Kompetisi Lainnya',
                    is_related: true,
                    dispatch: this.props.dispatch,
                    id: encid,
                    filter: 'related_' + encid,
                    data: this.props.kompetisi.related
                })
            );
        }
    }]);

    return Kompetisi;
}(_react2.default.Component);

function mapStateToProps(state) {
    var Kompetisi = state.Kompetisi;

    return {
        kompetisi: Kompetisi
    };
}

function mapDispatchToProps(dispatch) {
    return {
        dispatch: dispatch
    };
}

exports.default = (0, _reactRedux.connect)(mapStateToProps, mapDispatchToProps)(Kompetisi);