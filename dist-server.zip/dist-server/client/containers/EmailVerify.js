'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactHelmet = require('react-helmet');

var _reactHelmet2 = _interopRequireDefault(_reactHelmet);

var _Circle = require('../components/spiner/Circle');

var _Circle2 = _interopRequireDefault(_Circle);

var _reactRedux = require('react-redux');

var _actions = require('../../store/user/actions');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } /**
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                * Created by yussan on 04/02/17.
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                */


var EmailVerify = function (_Component) {
    _inherits(EmailVerify, _Component);

    function EmailVerify() {
        _classCallCheck(this, EmailVerify);

        return _possibleConstructorReturn(this, (EmailVerify.__proto__ || Object.getPrototypeOf(EmailVerify)).apply(this, arguments));
    }

    _createClass(EmailVerify, [{
        key: 'componentDidMount',
        value: function componentDidMount() {
            var token = this.props.location.query.token;

            this.props.dispatch((0, _actions.emailVerification)(token));
        }
    }, {
        key: 'componentWillReceiveProps',
        value: function componentWillReceiveProps(np) {
            if (np.email_verification.meta) {
                this.setState({
                    onprogress: false
                }, function () {
                    if (np.email_verification.meta.code === 201) {
                        setTimeout(function () {
                            fullalert.close();
                            window.location.href = '/';
                        }, 1500);
                        fullalert.open('success', np.email_verification.meta.message, false);
                    } else {
                        fullalert.open('error', np.email_verification.meta.message, false);
                    }
                });
            }
        }
    }, {
        key: 'render',
        value: function render() {
            return _react2.default.createElement(
                'div',
                { className: 'text-center' },
                _react2.default.createElement(_reactHelmet2.default, {
                    title: 'Email verification...'
                }),
                _react2.default.createElement(_Circle2.default, null),
                'sedang verifikasi email..'
            );
        }
    }]);

    return EmailVerify;
}(_react.Component);

function mapStateToProps(state) {
    return {
        email_verification: state.User.email_verification
    };
}

function mapDispatchToProps(dispatch) {
    return {
        dispatch: dispatch
    };
}

module.exports = (0, _reactRedux.connect)(mapStateToProps, mapDispatchToProps)(EmailVerify);