'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _Input = require('../components/form/Input');

var _Input2 = _interopRequireDefault(_Input);

var _reactHelmet = require('react-helmet');

var _reactHelmet2 = _interopRequireDefault(_reactHelmet);

var _reactRouter = require('react-router');

var _Validator = require('../helpers/Validator');

var _Validator2 = _interopRequireDefault(_Validator);

var _LoginText = require('../components/LoginText');

var _LoginText2 = _interopRequireDefault(_LoginText);

var _actions = require('../../store/user/actions');

var _reactRedux = require('react-redux');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } /**
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                * Created by yussan on 15/10/16.
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                */


var Register = function (_Component) {
    _inherits(Register, _Component);

    function Register(props) {
        _classCallCheck(this, Register);

        var _this = _possibleConstructorReturn(this, (Register.__proto__ || Object.getPrototypeOf(Register)).call(this, props));

        _this.state = {
            is_accept: false,
            onprogress: false,
            username: '',
            email: '',
            password: '',
            password_confirmation: ''
        };
        return _this;
    }

    _createClass(Register, [{
        key: 'componentDidMount',
        value: function componentDidMount() {
            document.getElementsByTagName('body')[0].style.background = 'rgb(31, 31, 31)';
        }
    }, {
        key: 'componentWillUnmount',
        value: function componentWillUnmount() {
            document.getElementsByTagName('body')[0].style.background = '#FFF';
        }
    }, {
        key: 'componentWillReceiveProps',
        value: function componentWillReceiveProps(np) {
            if (np.register.meta) {
                this.setState({
                    onprogress: false
                }, function () {
                    if (np.register.meta.code === 201) {
                        setTimeout(function () {
                            fullalert.close();
                            window.location.href = '/';
                        }, 1500);
                        fullalert.open('success', np.register.meta.message, false);
                    } else {
                        fullalert.open('error', np.register.meta.message);
                    }
                });
            }
        }
    }, {
        key: 'handleChangeAccept',
        value: function handleChangeAccept() {
            return this.setState({ is_accept: !this.state.is_accept });
        }
    }, {
        key: 'handleRegister',
        value: function handleRegister() {
            var _this2 = this;

            if (_Validator2.default.validateSubmit()) {
                var _state = this.state,
                    username = _state.username,
                    email = _state.email,
                    password = _state.password,
                    password_confirmation = _state.password_confirmation;

                console.log('\"yeah formdata is valid !\"');
                this.setState({
                    onprogress: true
                }, function () {
                    _this2.props.dispatch((0, _actions.register)({
                        username: username, email: email, password: password, password_confirmation: password_confirmation
                    }));
                });
            } else {
                fullalert.open('error', 'isian kamu belum lengkap');
            }
        }
    }, {
        key: 'changeState',
        value: function changeState(key, val) {
            return this.setState(_defineProperty({}, key, val));
        }
    }, {
        key: 'render',
        value: function render() {
            var _this3 = this;

            return _react2.default.createElement(
                'div',
                { className: 'container' },
                _react2.default.createElement(_reactHelmet2.default, {
                    title: 'Register - Kompetisi Indonesia',
                    description: 'Mendaftarkan akun baru di Kompetisi Indonesia'
                }),
                _react2.default.createElement(
                    'div',
                    { className: 'col-md-12 full-body-header' },
                    _react2.default.createElement(
                        _reactRouter.Link,
                        { to: '/' },
                        _react2.default.createElement('img', { src: '/assets/images/logo.png' })
                    )
                ),
                _react2.default.createElement(
                    'div',
                    { className: 'col-md-7' },
                    _react2.default.createElement(_LoginText2.default, null)
                ),
                _react2.default.createElement(
                    'div',
                    { className: 'col-md-5' },
                    _react2.default.createElement(
                        'div',
                        { className: 'login-box' },
                        _react2.default.createElement(
                            'form',
                            { method: 'POST', action: 'javascript:;' },
                            _react2.default.createElement(
                                'h2',
                                null,
                                'Mendaftarkan akun baru'
                            ),
                            _react2.default.createElement(_Input2.default, {
                                label: 'username.',
                                type: 'text',
                                name: 'username',
                                required: true,
                                value: this.state.username,
                                validate: this.state.validate_username ? this.state.validate_username : {},
                                min: 0,
                                max: 20,
                                custom_class: 'form-control',
                                changeState: function changeState(key, val) {
                                    return _this3.changeState(key, key === 'username' ? val.replace(/\s/g, '') : val);
                                }
                            }),
                            _react2.default.createElement(_Input2.default, {
                                label: 'email.',
                                type: 'email',
                                name: 'email',
                                required: true,
                                value: this.state.email,
                                validate: this.state.validate_email ? this.state.validate_email : {},
                                min: 0,
                                max: 100,
                                custom_class: 'form-control',
                                changeState: function changeState(key, val) {
                                    return _this3.setState(_defineProperty({}, key, val));
                                }
                            }),
                            _react2.default.createElement(_Input2.default, {
                                label: 'password.',
                                type: 'password',
                                name: 'password',
                                required: true,
                                value: this.state.password,
                                validate: this.state.validate_password ? this.state.validate_password : {},
                                min: 0,
                                max: 50,
                                custom_class: 'form-control',
                                changeState: function changeState(key, val) {
                                    return _this3.setState(_defineProperty({}, key, val));
                                }
                            }),
                            _react2.default.createElement(_Input2.default, {
                                label: 'ulangi password.',
                                type: 'password',
                                name: 'password_confirmation',
                                required: true,
                                value: this.state.password_confirmation,
                                validate: this.state.validate_password_confirmation ? this.state.validate_password_confirmation : {},
                                min: 0,
                                max: 50,
                                custom_class: 'form-control',
                                changeState: function changeState(key, val) {
                                    return _this3.setState(_defineProperty({}, key, val));
                                }
                            }),
                            _react2.default.createElement(
                                'div',
                                { className: 'checkbox' },
                                _react2.default.createElement(
                                    'label',
                                    null,
                                    _react2.default.createElement('input', { onChange: this.handleChangeAccept.bind(this), type: 'checkbox', defaultValue: 'ingat saya' }),
                                    'Saya menyetujui ',
                                    _react2.default.createElement(
                                        'a',
                                        { target: '_blank', href: '/' },
                                        'syarat dan ketentuan'
                                    )
                                )
                            ),
                            _react2.default.createElement('br', null),
                            _react2.default.createElement(
                                'button',
                                {
                                    disabled: this.state.onprogress || !this.state.is_accept,
                                    onClick: function onClick() {
                                        return _this3.handleRegister();
                                    },
                                    className: 'btn btn-primary',
                                    style: { width: '100%' } },
                                'daftar'
                            ),
                            _react2.default.createElement(
                                'div',
                                { className: 'text-center' },
                                _react2.default.createElement(
                                    'small',
                                    { className: 'text-muted' },
                                    'sudah punya akun silahkan',
                                    ' ',
                                    _react2.default.createElement(
                                        _reactRouter.Link,
                                        { to: '/login' },
                                        'masuk'
                                    ),
                                    ' ',
                                    'disini'
                                )
                            )
                        )
                    ),
                    _react2.default.createElement(
                        'div',
                        { className: 'text-center' },
                        _react2.default.createElement(
                            'small',
                            { className: 'white-text' },
                            'Kompetisi copyright \xA9 Id More 2016'
                        )
                    )
                )
            );
        }
    }]);

    return Register;
}(_react.Component);

exports.default = Register;


function mapStateToProps(state) {
    return {
        register: state.User.register
    };
}

function mapDispatchToProps(dispatch) {
    return {
        dispatch: dispatch
    };
}

module.exports = (0, _reactRedux.connect)(mapStateToProps, mapDispatchToProps)(Register);