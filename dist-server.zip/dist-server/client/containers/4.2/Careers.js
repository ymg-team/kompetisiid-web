'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _Helmet = require('../../components/Helmet');

var _Helmet2 = _interopRequireDefault(_Helmet);

var _Subheader = require('../../components/4.2/Subheader');

var _Subheader2 = _interopRequireDefault(_Subheader);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var Careers = function Careers() {
    return _react2.default.createElement(
        'div',
        null,
        _react2.default.createElement(_Helmet2.default, {
            title: 'Karir - Kompetisi Indonesia',
            description: 'Mari bergabung bersama kami untuk terus meramaikan semangat kompetisi di Indonesia'
        }),
        _react2.default.createElement(
            'div',
            { className: 'col-md-12 careers-header', style: { textAlign: 'center', backgroundImage: 'url(/assets/4.2/img/careers-background.jpg)' } },
            _react2.default.createElement(
                'div',
                { className: 'container' },
                _react2.default.createElement('div', { className: 'row no-margin' }),
                _react2.default.createElement(
                    'h1',
                    null,
                    'Mari Berkarir Bersama KI'
                ),
                _react2.default.createElement(
                    'h3',
                    null,
                    'Kompetisi.id adalah salah satu produk dari ByIdMore yang sama-sama bertujuan untuk melakukan lebih untuk Indonesia. Mari bergabung bersama kami untuk terus meramaikan semangat kompetisi di Indonesia.',
                    _react2.default.createElement('br', null),
                    'Kami sedang mencari jiwa-jiwa bertalenta untuk menjadi bagian dari KI yang memiliki bagian sebagai berikut.'
                ),
                _react2.default.createElement(
                    'a',
                    { className: 'btn btn-white btn-bg', href: '#available-careers', style: { fontWeight: 'bold' } },
                    'Telusuri Lowongan Tersedia ',
                    _react2.default.createElement(
                        'i',
                        { className: 'fa fa-arrow-circle-o-down' },
                        ' '
                    )
                )
            )
        ),
        _react2.default.createElement(
            'div',
            { className: 'col-md-8 col-md-push-2 m-t-b-20 align-center careers', style: { lineHeight: 2 } },
            _react2.default.createElement(
                'section',
                { className: 'col-md-12', id: 'available-careers' },
                _react2.default.createElement(
                    'h1',
                    null,
                    'Bagian Yang Tersedia'
                ),
                _react2.default.createElement(
                    'div',
                    { className: 'col-md-12' },
                    _react2.default.createElement(
                        'div',
                        { className: 'col-md-12' },
                        _react2.default.createElement(
                            'h2',
                            null,
                            'Software Engineer'
                        )
                    ),
                    _react2.default.createElement(
                        'div',
                        { className: 'col-md-6 carrers-item' },
                        _react2.default.createElement(
                            'strong',
                            null,
                            'Web Developers'
                        ),
                        _react2.default.createElement(
                            'ul',
                            { className: 'align-left' },
                            _react2.default.createElement(
                                'li',
                                null,
                                'NodeJS + Express (isomorphic app)'
                            ),
                            _react2.default.createElement(
                                'li',
                                null,
                                'ReactJS (diutamakan), VueJS (libs based on components)'
                            ),
                            _react2.default.createElement(
                                'li',
                                null,
                                'Terbiasa menggunakan dependensi pendukung dari',
                                _react2.default.createElement(
                                    'i',
                                    null,
                                    'NPM'
                                ),
                                ', atau',
                                _react2.default.createElement(
                                    'i',
                                    null,
                                    'tool-tool'
                                ),
                                'untuk',
                                _react2.default.createElement(
                                    'i',
                                    null,
                                    'development'
                                ),
                                'seperti',
                                _react2.default.createElement(
                                    'i',
                                    null,
                                    'Grunt, Prepack, Webpack, dll'
                                )
                            ),
                            _react2.default.createElement(
                                'li',
                                null,
                                'Kami menggunakan',
                                _react2.default.createElement(
                                    'i',
                                    null,
                                    'git'
                                ),
                                'sebagai',
                                _react2.default.createElement(
                                    'i',
                                    null,
                                    'version control system'
                                )
                            )
                        ),
                        _react2.default.createElement(
                            'button',
                            { className: 'btn btn-gray btn-sm', disabled: 'true' },
                            'Pendaftaran Belum Dibuka'
                        )
                    ),
                    _react2.default.createElement(
                        'div',
                        { className: 'col-md-6 carrers-item' },
                        _react2.default.createElement(
                            'strong',
                            null,
                            'API Developers'
                        ),
                        _react2.default.createElement(
                            'ul',
                            { className: 'align-left' },
                            _react2.default.createElement(
                                'li',
                                null,
                                'Python + Flasks (api core)'
                            ),
                            _react2.default.createElement(
                                'li',
                                null,
                                'SQL and NOSQL databases'
                            ),
                            _react2.default.createElement(
                                'li',
                                null,
                                'Kami menggunakan',
                                _react2.default.createElement(
                                    'i',
                                    null,
                                    'Firebase, Mailgun, Dlvrt, dsb'
                                ),
                                'sebagai ',
                                _react2.default.createElement(
                                    'i',
                                    null,
                                    '3th party '
                                ),
                                'yang diakses beberapa',
                                _react2.default.createElement(
                                    'i',
                                    null,
                                    'micro services '
                                ),
                                'KI'
                            ),
                            _react2.default.createElement(
                                'li',
                                null,
                                'Kami menggunakan',
                                _react2.default.createElement(
                                    'i',
                                    null,
                                    'git'
                                ),
                                'sebagai',
                                _react2.default.createElement(
                                    'i',
                                    null,
                                    'version control system'
                                )
                            )
                        ),
                        _react2.default.createElement(
                            'button',
                            { className: 'btn btn-gray btn-sm', disabled: 'true' },
                            'Pendaftaran Belum Dibuka'
                        )
                    )
                )
            ),
            _react2.default.createElement(
                'div',
                { className: 'col-md-12 m-t-b-10' },
                _react2.default.createElement('hr', null)
            ),
            _react2.default.createElement(
                'section',
                { className: 'col-md-12' },
                _react2.default.createElement(
                    'div',
                    { className: 'col-md-12' },
                    _react2.default.createElement(
                        'h2',
                        null,
                        'Technical Support'
                    )
                ),
                _react2.default.createElement(
                    'div',
                    { className: 'col-md-6 carrers-item' },
                    _react2.default.createElement(
                        'strong',
                        null,
                        'DevOops'
                    ),
                    _react2.default.createElement(
                        'ul',
                        { className: 'align-left' },
                        _react2.default.createElement(
                            'li',
                            null,
                            'Linux based server'
                        ),
                        _react2.default.createElement(
                            'li',
                            null,
                            'Docker '
                        ),
                        _react2.default.createElement(
                            'li',
                            null,
                            ' ',
                            _react2.default.createElement(
                                'i',
                                null,
                                '3th party '
                            ),
                            'seperti ',
                            _react2.default.createElement(
                                'i',
                                null,
                                'Gitlab Enterprise, Firebase, Heroku, dsb'
                            )
                        ),
                        _react2.default.createElement(
                            'li',
                            null,
                            'Remote, Monitoring, Standby '
                        )
                    ),
                    _react2.default.createElement(
                        'button',
                        { className: 'btn btn-gray btn-sm', disabled: 'true' },
                        'Pendaftaran Belum Dibuka '
                    )
                )
            ),
            _react2.default.createElement(
                'div',
                { className: 'col-md-12 m-t-b-10' },
                _react2.default.createElement('hr', null)
            ),
            _react2.default.createElement(
                'div',
                { className: 'col-md-12' },
                _react2.default.createElement('div', { className: 'col-md-12' }),
                _react2.default.createElement(
                    'h2',
                    null,
                    'Software Quality Assurances'
                ),
                _react2.default.createElement(
                    'div',
                    { className: 'col-md-6 carrers-item' },
                    _react2.default.createElement('div', { className: 'disabled' }),
                    _react2.default.createElement(
                        'strong',
                        null,
                        'Web QA Engineer'
                    )
                )
            ),
            _react2.default.createElement(
                'div',
                { className: 'col-md-12 m-t-b-10' },
                _react2.default.createElement('hr', null)
            ),
            _react2.default.createElement(
                'div',
                { className: 'col-md-12' },
                _react2.default.createElement('div', { className: 'col-md-12' }),
                _react2.default.createElement(
                    'h2',
                    null,
                    'Non Technical Support'
                ),
                _react2.default.createElement(
                    'div',
                    { className: 'col-md-6 carrers-item' },
                    _react2.default.createElement('div', { className: 'disabled' }),
                    _react2.default.createElement(
                        'strong',
                        null,
                        'Marketing Staff'
                    )
                ),
                _react2.default.createElement(
                    'div',
                    { className: 'col-md-6 carrers-item' },
                    _react2.default.createElement('div', { className: 'disabled' }),
                    _react2.default.createElement(
                        'strong',
                        null,
                        'Production Executive'
                    )
                )
            ),
            _react2.default.createElement(
                'div',
                { className: 'col-md-12 m-t-b-10' },
                _react2.default.createElement('hr', null)
            ),
            _react2.default.createElement(
                'div',
                { className: 'col-md-12' },
                _react2.default.createElement(
                    'div',
                    { className: 'co-md-12' },
                    _react2.default.createElement(
                        'h1',
                        null,
                        'Selengkapnya'
                    ),
                    _react2.default.createElement(
                        'h3',
                        { style: { fontWeight: 'normal' } },
                        'Ada pertanyaan lebih lanjut, jangan sungkan-sungkan sampaikan kepada kami.'
                    ),
                    _react2.default.createElement('br', null),
                    _react2.default.createElement(
                        'a',
                        { className: 'btn btn-green', href: 'https://goo.gl/forms/kMGGZQXJCjoyKThj1', target: '_blank' },
                        ' ',
                        _react2.default.createElement(
                            'strong',
                            null,
                            'Kontak Kami'
                        )
                    ),
                    _react2.default.createElement('br', null),
                    _react2.default.createElement(
                        'p',
                        { className: 'text-muted' },
                        'atau temui kami di'
                    ),
                    _react2.default.createElement(
                        'ul',
                        { className: 'horizontal-menu' },
                        _react2.default.createElement(
                            'li',
                            null,
                            _react2.default.createElement('a', { className: 'btn btn-socmed btn-gray btn-lg fa fa-facebook', href: 'https://facebook.com/kompetisiindo', target: '_blank' })
                        ),
                        _react2.default.createElement(
                            'li',
                            null,
                            _react2.default.createElement('a', { className: 'btn btn-socmed btn-gray btn-lg fa fa-twitter', href: 'https://twitter.com/kompetisiindo', target: '_blank' })
                        ),
                        _react2.default.createElement(
                            'li',
                            null,
                            _react2.default.createElement('a', { className: 'btn btn-socmed btn-gray btn-lg fa fa-instagram', href: 'https://instagram.com/kompetisiindo', target: '_blank' })
                        )
                    )
                )
            )
        )
    );
};

exports.default = Careers;