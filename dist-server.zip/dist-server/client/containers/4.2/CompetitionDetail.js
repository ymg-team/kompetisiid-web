'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _TabCompetition = require('../../components/4.2/navigations/TabCompetition');

var _TabCompetition2 = _interopRequireDefault(_TabCompetition);

var _Helmet = require('../../components/Helmet');

var _Helmet2 = _interopRequireDefault(_Helmet);

var _DefaultLoader = require('../../components/4.2/loaders/DefaultLoader');

var _DefaultLoader2 = _interopRequireDefault(_DefaultLoader);

var _CompetitionDetail = require('../../components/4.2/boxs/CompetitionDetail');

var _CompetitionDetail2 = _interopRequireDefault(_CompetitionDetail);

var _CompetitionBox = require('../../components/4.2/boxs/CompetitionBox');

var _CompetitionBox2 = _interopRequireDefault(_CompetitionBox);

var _Regulations = require('../../components/4.2/competition-detail/Regulations');

var _Regulations2 = _interopRequireDefault(_Regulations);

var _Prizes = require('../../components/4.2/competition-detail/Prizes');

var _Prizes2 = _interopRequireDefault(_Prizes);

var _Announcements = require('../../components/4.2/competition-detail/Announcements');

var _Announcements2 = _interopRequireDefault(_Announcements);

var _Contacts = require('../../components/4.2/competition-detail/Contacts');

var _Contacts2 = _interopRequireDefault(_Contacts);

var _Share = require('../../components/4.2/competition-detail/Share');

var _Share2 = _interopRequireDefault(_Share);

var _Discussions = require('../../components/4.2/competition-detail/Discussions');

var _Discussions2 = _interopRequireDefault(_Discussions);

var _reactRouter = require('react-router');

var _NextPrev = require('../../components/4.2/navigations/NextPrev');

var _NextPrev2 = _interopRequireDefault(_NextPrev);

var _ErrorCard = require('../../components/4.2/cards/ErrorCard');

var _ErrorCard2 = _interopRequireDefault(_ErrorCard);

var _host = require('../../../config/host');

var _host2 = _interopRequireDefault(_host);

var _DomEvents = require('../../helpers/DomEvents');

var _stringManager = require('string-manager');

var _actions = require('../../../store/kompetisi/actions');

var _reactRedux = require('react-redux');

var _Transtition = require('../../components/Transtition');

var _Transition = require('react-transition-group/Transition');

var _Transition2 = _interopRequireDefault(_Transition);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var CompetitionDetail = function (_Component) {
  _inherits(CompetitionDetail, _Component);

  _createClass(CompetitionDetail, null, [{
    key: 'fetchData',
    value: function fetchData(_ref) {
      var params = _ref.params,
          store = _ref.store;

      return store.dispatch((0, _actions.getDetail)(params.encid));
    }
  }]);

  function CompetitionDetail(props) {
    _classCallCheck(this, CompetitionDetail);

    var _this = _possibleConstructorReturn(this, (CompetitionDetail.__proto__ || Object.getPrototypeOf(CompetitionDetail)).call(this, props));

    _this.state = {
      ready: false,
      encid: _this.props.params.encid
    };
    return _this;
  }

  _createClass(CompetitionDetail, [{
    key: 'componentDidMount',
    value: function componentDidMount() {
      var _this2 = this;

      setTimeout(function () {
        _this2.setState({ ready: true });
      }, 10);
      if (this.props.route.active_tab == 1) window.scrollTo(0, 0);
      this.reqData(this.props);
      this.reqRelatedCompetitions(this.props);
      (0, _DomEvents.pushScript)('https://kompetisiindonesia.disqus.com/embed.js');
    }
  }, {
    key: 'componentWillReceiveProps',
    value: function componentWillReceiveProps(np) {
      this.setState({ encid: np.params.encid });
      if (this.props.params.encid != np.params.encid) {
        if (window != undefined) window.scrollTo(0, 0);
        this.reqData(np);
        this.reqRelatedCompetitions(np);
      }
    }
  }, {
    key: 'componentWillUnmount',
    value: function componentWillUnmount() {
      window.onscroll = null;
    }
  }, {
    key: 'reqData',
    value: function reqData(props) {
      var encid = props.params.encid;

      if (props.route.name != 'competition_regulation') window.scrollTo(0, 0);
      if (!props.kompetisi.detail[encid]) this.props.dispatch((0, _actions.getDetail)(encid));
    }
  }, {
    key: 'reqRelatedCompetitions',
    value: function reqRelatedCompetitions(props) {
      var encid = props.params.encid;

      if (!props.kompetisi.data['related_' + encid]) this.props.dispatch((0, _actions.getRelated)(encid, 'related_' + encid));
    }
  }, {
    key: 'render',
    value: function render() {
      var _this3 = this;

      var encid = this.state.encid;
      var _props$kompetisi = this.props.kompetisi,
          detail = _props$kompetisi.detail,
          related = _props$kompetisi.related,
          pengumuman = _props$kompetisi.pengumuman;
      var active_tab = this.props.route.active_tab;

      var NextPrevProps = {},
          helmetdata = { script: []

        // generate helmet data 
      };if (detail[encid] && detail[encid].meta && parseInt(detail[encid].meta.code) === 200) {
        setTimeout(function () {
          if (typeof window != 'undefined') {
            handleScrollNav();
          }
        }, 2000);
        helmetdata = Object.assign(helmetdata, {
          title: (0, _stringManager.toCamelCase)('' + (_TabCompetition.tab[this.props.route.active_tab - 1].name + ' ' || '') + detail[encid].data.title),
          description: detail[encid].data.sort,
          image: detail[encid].data.poster.original,
          url: _host2.default[process.env.NODE_ENV].front + '/competition/' + detail[encid].data.id_kompetisi + '/regulations/' + detail[encid].data.nospace_title
        });

        // add jsonld
        helmetdata.script.push({
          type: 'application/ld+json',
          innerHTML: generateJsonld(detail[encid].data, helmetdata.url)
        });

        // nextprev props 
        if (Object.keys(detail[encid].data.next).length > 0) {
          NextPrevProps.next = {
            title: detail[encid].data.next.title,
            link: '/competition/' + detail[encid].data.next.id_kompetisi + '/regulations/' + detail[encid].data.next.nospace_title
          };
        }

        if (Object.keys(detail[encid].data.prev).length > 0) {
          NextPrevProps.prev = {
            title: detail[encid].data.prev.title,
            link: '/competition/' + detail[encid].data.prev.id_kompetisi + '/regulations/' + detail[encid].data.prev.nospace_title
          };
        }
      }

      return _react2.default.createElement(
        _Transition2.default,
        { 'in': this.state.ready, timeout: _Transtition.duration },
        function (state) {
          return _react2.default.createElement(
            'div',
            { style: Object.assign({}, _Transtition.style.fade.default, _Transtition.style.fade[state]) },
            _react2.default.createElement(_Helmet2.default, helmetdata),
            detail[encid] && detail[encid].meta ? detail[encid].meta.code == 200 ? _react2.default.createElement(
              'div',
              { className: 'competition-detail' },
              _react2.default.createElement(_CompetitionDetail2.default, {
                data: detail[encid].data }),
              _react2.default.createElement(_TabCompetition2.default, {
                active: _this3.props.route.active_tab,
                data: detail[encid].data
              }),
              _react2.default.createElement(
                'div',
                { className: 'col-md-12' },
                _react2.default.createElement(
                  'div',
                  { className: 'container' },
                  _react2.default.createElement(
                    'div',
                    { className: 'row competition-detail--content' },
                    _react2.default.createElement(
                      'div',
                      { className: 'col-md-10 col-md-push-1' },
                      !detail[encid].data.is_mediapartner && !detail[encid].data.is_support ? _react2.default.createElement(
                        'div',
                        { style: { marginTop: 0 }, className: 'alert alert-warning' },
                        _react2.default.createElement(
                          'strong',
                          null,
                          'Perhatian\xA0'
                        ),
                        'Di kompetisi ini, ',
                        _react2.default.createElement(
                          'strong',
                          null,
                          'Kompetisi Indonesia '
                        ),
                        'hanya berlaku sebagai media publikasi. Jika ada pertanyaan lebih lanjut mengenai kompetisi ini silahkan sampaikan langsung ke kontak yang tersedia tab kontak.'
                      ) : null,
                      detail[encid].data.is_mediapartner && !detail[encid].data.is_support ? _react2.default.createElement(
                        'div',
                        { style: { marginTop: 0 }, className: 'alert alert-blue' },
                        _react2.default.createElement(
                          'strong',
                          null,
                          'Perhatian\xA0'
                        ),
                        'Di kompetisi ini, ',
                        _react2.default.createElement(
                          'strong',
                          null,
                          'Kompetisi Indonesia '
                        ),
                        'berlaku sebagai media partner, jika ada pertanyaan lebih lanjut mengenai kompetisi ini, bisa ditanyakan langsung ke penyelenggara atau melalui tab diskusi.'
                      ) : null,
                      detail[encid].data.is_support ? _react2.default.createElement(
                        'div',
                        { style: { marginTop: 0 }, className: 'alert alert-blue' },
                        _react2.default.createElement(
                          'strong',
                          null,
                          'Perhatian\xA0'
                        ),
                        'Kompetisi ini bisa diikuti langsung di ',
                        _react2.default.createElement(
                          'strong',
                          null,
                          'Kompetisi Indonesia'
                        ),
                        ', silahkan login dan klik tombol \'ikuti kompetisi\'.'
                      ) : null,
                      _react2.default.createElement('div', { className: 'm-20' }),
                      _react2.default.createElement(
                        'div',
                        { className: 'row' },
                        _react2.default.createElement(
                          'div',
                          { className: active_tab == 1 ? 'col-md-8' : 'col-md-12' },
                          function () {
                            switch (active_tab) {
                              case 1:
                                return _react2.default.createElement(_Regulations2.default, {
                                  encid: encid,
                                  nospace_title: detail[encid].data.nospace_title,
                                  sumber: detail[encid].data.sumber,
                                  tags: detail[encid].data.tags.split(','),
                                  html: detail[encid].data.konten });
                              case 2:
                                return _react2.default.createElement(_Prizes2.default, {
                                  html: detail[encid].data.hadiah });
                              case 3:
                                return _react2.default.createElement(_Announcements2.default, {
                                  data: JSON.parse(detail[encid].data.dataPengumuman) });
                              case 4:
                                return _react2.default.createElement(_Discussions2.default, {
                                  link: helmetdata.url });
                              case 5:
                                return _react2.default.createElement(_Contacts2.default, {
                                  data: JSON.parse(detail[encid].data.kontak) });
                              case 6:
                                return _react2.default.createElement(_Share2.default, {
                                  title: detail[encid].data.title,
                                  desc: detail[encid].data.sort,
                                  link: helmetdata.url });
                              default:
                                return null;
                            }
                          }()
                        ),
                        active_tab == 1 ? _react2.default.createElement(
                          'div',
                          { className: 'col-md-4' },
                          _react2.default.createElement(
                            'div',
                            { className: 'competition-detail--meta' },
                            _react2.default.createElement('progress', { value: 30, max: 100 }),
                            _react2.default.createElement(
                              'h3',
                              { className: 'total-prize' },
                              _react2.default.createElement(
                                'strong',
                                null,
                                detail[encid].data.total_hadiah
                              ),
                              _react2.default.createElement(
                                'small',
                                { className: 'text-muted' },
                                'total hadiah'
                              )
                            ),
                            _react2.default.createElement(
                              'h3',
                              { className: 'total-view' },
                              detail[encid].data.views,
                              _react2.default.createElement(
                                'small',
                                { className: 'text-muted' },
                                'kunjungan'
                              )
                            ),
                            _react2.default.createElement(
                              'h3',
                              { className: 'total-view' },
                              detail[encid].data.sisadeadline,
                              _react2.default.createElement(
                                'small',
                                { className: 'text-muted' },
                                'deadline (' + detail[encid].data.deadline + ')'
                              )
                            ),
                            _react2.default.createElement(
                              'h3',
                              { className: 'total-view' },
                              detail[encid].data.sisapengumuman,
                              _react2.default.createElement(
                                'small',
                                { className: 'text-muted' },
                                'pengumuman (' + detail[encid].data.pengumuman + ')'
                              )
                            )
                          ),
                          _react2.default.createElement('hr', null),
                          _react2.default.createElement(
                            'h4',
                            { className: 'text-muted' },
                            'Kompetisi ini bersifat'
                          ),
                          detail[encid].data.is_garansi ? _react2.default.createElement(
                            'span',
                            { title: 'kompetisi sudah diverifikasi keberadaannya oleh kru KI', className: 'label label-gray' },
                            'Garansi'
                          ) : null,
                          detail[encid].data.is_mediapartner ? _react2.default.createElement(
                            'span',
                            { title: 'KI berlaku sebagai media partner di kompetisi ini', className: 'label label-gray' },
                            'Media Partner'
                          ) : null,
                          detail[encid].data.is_support ? _react2.default.createElement(
                            'span',
                            { title: 'kompetisi ini bisa diikuti melelui KI', className: 'label label-gray' },
                            'Support'
                          ) : null,
                          _react2.default.createElement('br', null),
                          _react2.default.createElement('br', null),
                          _react2.default.createElement(
                            'a',
                            { target: '_blank', href: 'https://vip.bitcoin.co.id/ref/xyussanx/1' },
                            _react2.default.createElement('img', { style: { maxWidth: '100%' }, src: 'https://s3.amazonaws.com/bitcoin.co.id/banner/250x250.jpg', alt: 'Yuk berdagang Bitcoin dan dapatkan keuntungan jutaan rupiah' })
                          )
                        ) : null
                      )
                    )
                  )
                )
              ),
              _react2.default.createElement(_NextPrev2.default, NextPrevProps),
              related['related_' + encid] && related['related_' + encid].meta && related['related_' + encid].meta.code == 200 ? _react2.default.createElement(
                'div',
                { className: 'col-md-12 bg-gray-soft' },
                _react2.default.createElement('div', { className: 'm-20 row' }),
                _react2.default.createElement(_CompetitionBox2.default, _extends({ subtitle: false, size: 'small' }, related['related_' + encid]))
              ) : null
            ) : _react2.default.createElement(_ErrorCard2.default, detail[encid].meta) : _react2.default.createElement(
              'div',
              { className: 'fullheight' },
              _react2.default.createElement(_DefaultLoader2.default, null)
            )
          );
        }
      );
    }
  }]);

  return CompetitionDetail;
}(_react.Component);

function generateJsonld(n, url) {
  var start_date = n.created_at.split(' ');
  var end_date = n.deadline_at.split(' ');
  return '{\n    "@context": "http://schema.org",\n    "@type": "Event",\n    "name": "' + n.title.replace(/\"/g, "") + '",\n    "description": "' + n.sort.replace(/\"/g, "") + '",\n    "startDate": "' + start_date[0] + 'T' + start_date[1] + '.000Z",\n    "endDate": "' + end_date[0] + 'T' + end_date[1] + '.000Z",\n    "url": "' + url + '",\n    "sameAs": "' + n.sumber + '",\n    "image": {\n        "@type": "ImageObject",\n        "url": "' + n.poster.original + '",\n        "height": "500",\n        "width": "500"\n    },\n    "organizer": {\n      "@type": "Organization",\n      "name": "' + n.penyelenggara + '",\n      "logo": {\n          "@type": "ImageObject",\n          "url": "https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/21529_1680281178877316_3989323526762937427_n.png?oh=30d4cacd082cb9b7bffbd9abf01c1cb0&oe=5A01639C",\n          "height": "500",\n          "width": "500"\n      }\n    },\n    "location": {\n      "@type": "Place",\n      "name": "Indonesia",\n      "address": "Indonesia"\n    }\n  }';
}

function handleScrollNav() {
  window.onscroll = function () {
    var afterScroll = document.getElementById('competition-detail').offsetHeight + 40;
    var tabEl = document.getElementById('container-competition-tab');
    var joinEl = document.getElementById('btn-join');
    if (joinEl && afterScroll) {
      if (document.body.scrollTop > afterScroll) {
        addClass(tabEl, 'fixed');
        joinEl.style.opacity = 1;
      } else {
        removeClass(tabEl, 'fixed');
        joinEl.style.opacity = 0;
      }
    }
  };
}

function mapStateToProps(state) {
  var Kompetisi = state.Kompetisi;

  return {
    kompetisi: Kompetisi
  };
}

function mapDispatchToProps(dispatch) {
  return {
    dispatch: dispatch
  };
}

exports.default = (0, _reactRedux.connect)(mapStateToProps, mapDispatchToProps)(CompetitionDetail);