'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _Helmet = require('../../components/Helmet');

var _Helmet2 = _interopRequireDefault(_Helmet);

var _Subheader = require('../../components/4.2/Subheader');

var _Subheader2 = _interopRequireDefault(_Subheader);

var _NewsBox = require('../../components/4.2/boxs/NewsBox');

var _NewsBox2 = _interopRequireDefault(_NewsBox);

var _actions = require('../../../store/berita/actions');

var _reactRedux = require('react-redux');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Filter = 'list';
var Limit = 6;
var handleScroll = void 0;

var NewsList = function (_Component) {
    _inherits(NewsList, _Component);

    function NewsList() {
        _classCallCheck(this, NewsList);

        return _possibleConstructorReturn(this, (NewsList.__proto__ || Object.getPrototypeOf(NewsList)).apply(this, arguments));
    }

    _createClass(NewsList, [{
        key: 'componentDidMount',

        // static fetchData({store})
        // {
        //     return store.dispatch(fetchBerita({limit:Limit}, Filter))
        // }

        value: function componentDidMount() {
            var _this3 = this;

            this.reqData();
            window.scrollTo(0, 0);
            var _this = this;
            window.addEventListener('scroll', function (e) {
                return _this3.handleScroll(e);
            }, true);
        }
    }, {
        key: 'componentWillUnmount',
        value: function componentWillUnmount() {
            var _this4 = this;

            window.removeEventListener('scroll', function (e) {
                return _this4.handleScroll(e);
            }, true);
        }
    }, {
        key: 'handleScroll',
        value: function handleScroll() {
            if (document.getElementById('news-container')) {
                var ContainerHeight = document.getElementById('news-container').offsetHeight;
                if (window.pageYOffset >= ContainerHeight - 600) this.reqMore();
            }
        }
    }, {
        key: 'reqData',
        value: function reqData() {
            var Params = { limit: Limit };
            if (!this.props.berita.data[Filter]) this.props.dispatch((0, _actions.fetchBerita)(Params, Filter));
        }
    }, {
        key: 'reqMore',
        value: function reqMore() {
            var Params = { limit: Limit };
            var Berita = this.props.berita.data[Filter];
            if (Berita && Berita.data) {
                Params.lastid = Berita.data[Berita.data.length - 1].id;
                if (!Berita.is_loading && Berita.meta.code === 200) {
                    this.props.dispatch((0, _actions.fetchBeritaMore)(Params, Filter));
                }
            }
        }
    }, {
        key: 'render',
        value: function render() {
            return _react2.default.createElement(
                'div',
                null,
                _react2.default.createElement(_Helmet2.default, {
                    title: 'Berita - Kompetisi Indonesia',
                    description: 'Temukan berita seputar kompetisi di Indonesia'
                }),
                _react2.default.createElement(_Subheader2.default, {
                    title: 'Berita kompetisi',
                    desc: 'Berita seputar kompetisi di Indonesia dan Internasional'
                }),
                _react2.default.createElement(_NewsBox2.default, this.props.berita.data[Filter])
            );
        }
    }]);

    return NewsList;
}(_react.Component);

function mapStateToProps(state) {
    var Berita = state.Berita;

    return {
        berita: Berita
    };
}

function mapDispatchToProps(dispatch) {
    return {
        dispatch: dispatch
    };
}

module.exports = (0, _reactRedux.connect)(mapStateToProps, mapDispatchToProps)(NewsList);