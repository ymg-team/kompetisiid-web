'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.desc = exports.title = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactRouter = require('react-router');

var _Subheader = require('../../components/4.2/Subheader');

var _Subheader2 = _interopRequireDefault(_Subheader);

var _Helmet = require('../../components/Helmet');

var _Helmet2 = _interopRequireDefault(_Helmet);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var title = exports.title = 'Pasang Kompetisi';
var desc = exports.desc = 'Apakah kamu adalah penyelenggara kompetisi? jika iya, kamu bisa menggunakan fitur ini untuk mempulikasi kompetisimu di KompetisiIndonesia. Ada 2 cara untuk pasang kompetisi, yaitu "Kirim Kompetisi" dan "Pasang Kompetisi" untuk saat ini hanya "Kirim Kompetisi" yang bisa kamu coba.';

var AddCompetition = function (_Component) {
    _inherits(AddCompetition, _Component);

    function AddCompetition() {
        _classCallCheck(this, AddCompetition);

        return _possibleConstructorReturn(this, (AddCompetition.__proto__ || Object.getPrototypeOf(AddCompetition)).apply(this, arguments));
    }

    _createClass(AddCompetition, [{
        key: 'componentWillUnmount',
        value: function componentWillUnmount() {
            fullalert('close');
        }
    }, {
        key: 'render',
        value: function render() {
            return _react2.default.createElement(
                'div',
                null,
                _react2.default.createElement(_Helmet2.default, {
                    title: title,
                    description: desc
                }),
                _react2.default.createElement(_Subheader2.default, {
                    title: title,
                    desc: desc
                }),
                _react2.default.createElement(
                    'div',
                    { className: 'col-md-12' },
                    _react2.default.createElement(
                        'div',
                        { className: 'add-competition' },
                        _react2.default.createElement(
                            'div',
                            { className: 'container' },
                            _react2.default.createElement('div', { className: 'col-md-12 m-20' }),
                            _react2.default.createElement(
                                'div',
                                { className: 'col-md-10 col-md-push-1 m-20' },
                                _react2.default.createElement(
                                    'div',
                                    { className: 'row' },
                                    _react2.default.createElement(
                                        'div',
                                        { className: 'col-md-6 align-center' },
                                        _react2.default.createElement(
                                            'h2',
                                            null,
                                            'Kirim Kompetisi'
                                        ),
                                        _react2.default.createElement(
                                            'p',
                                            { className: 'text-muted' },
                                            'Kamu cukup upload poster dan link untuk kemudian dicek pihak "KI" dan akan diposting jika data tersebut valid.',
                                            _react2.default.createElement('br', null),
                                            _react2.default.createElement(
                                                'small',
                                                null,
                                                '*)waktu yang dibutuhkan untuk validasi lebih lama dari pasang sendiri'
                                            )
                                        ),
                                        _react2.default.createElement(
                                            _reactRouter.Link,
                                            { to: '/add/send', className: 'btn btn-white', title: 'klik untuk pasang cepat' },
                                            'Klik untuk kirim kompetisi'
                                        )
                                    ),
                                    _react2.default.createElement(
                                        'div',
                                        { className: 'col-md-6 align-center' },
                                        _react2.default.createElement(
                                            'h2',
                                            null,
                                            'Pasang Sendiri'
                                        ),
                                        _react2.default.createElement(
                                            'p',
                                            { className: 'text-muted' },
                                            'Login dan pasang sendiri kompetisimu melalui dashboard member. Kamu akan lebih mudah memanage kompetisi lainnya, diskusi dan memberikan pengumuman kepada para pengunjung. '
                                        ),
                                        _react2.default.createElement(
                                            'a',
                                            { href: 'javascript:;', onClick: function onClick() {
                                                    fullalert('warning', 'Login terlebih dahulu untuk menggunakan fitur ini');
                                                }, className: 'btn btn-white', title: 'klik untuk pasang cepat' },
                                            'Klik untuk pasang kompetisi'
                                        )
                                    )
                                )
                            ),
                            _react2.default.createElement('div', { className: 'col-md-12 m-20' })
                        )
                    )
                )
            );
        }
    }]);

    return AddCompetition;
}(_react.Component);

exports.default = AddCompetition;