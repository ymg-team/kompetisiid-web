'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _propTypes = require('prop-types');

var _propTypes2 = _interopRequireDefault(_propTypes);

var _Helmet = require('../../components/Helmet');

var _Helmet2 = _interopRequireDefault(_Helmet);

var _CompetitionBox = require('../../components/4.2/boxs/CompetitionBox');

var _CompetitionBox2 = _interopRequireDefault(_CompetitionBox);

var _actions = require('../../../store/kompetisi/actions');

var KompetisiActions = _interopRequireWildcard(_actions);

var _LocalStorage = require('../../../store/helpers/LocalStorage');

var _stringManager = require('string-manager');

var _reactRedux = require('react-redux');

var _redux = require('redux');

var _Transtition = require('../../components/Transtition');

var _Transition = require('react-transition-group/Transition');

var _Transition2 = _interopRequireDefault(_Transition);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var BrowseCompetition = function (_Component) {
    _inherits(BrowseCompetition, _Component);

    _createClass(BrowseCompetition, null, [{
        key: 'fetchData',
        value: function fetchData(_ref) {
            var store = _ref.store,
                params = _ref.params,
                query = _ref.query;

            var State = generateState(query, params);
            var Filter = generateFilter(State);
            var Params = generateParams(State);
            return store.dispatch(KompetisiActions.fetchJelajah(Params, Filter));
        }
    }]);

    function BrowseCompetition(props) {
        _classCallCheck(this, BrowseCompetition);

        var _this = _possibleConstructorReturn(this, (BrowseCompetition.__proto__ || Object.getPrototypeOf(BrowseCompetition)).call(this, props));

        _this.state = generateState(_this.props.location.query, _this.props.params);
        return _this;
    }

    _createClass(BrowseCompetition, [{
        key: 'componentDidMount',
        value: function componentDidMount() {
            var _this2 = this;

            window.scrollTo(0, 0);
            this.reqData();
            var Categories = (0, _LocalStorage.getStorage)('categories');
            if (Categories) {
                this.props.dispatch(KompetisiActions.setCategories(JSON.parse(Categories)));
            } else {
                this.props.dispatch(KompetisiActions.getCategories());
            }
            //scroll event listener
            window.addEventListener('scroll', function (e) {
                return _this2.handleScroll(e);
            }, true);
        }
    }, {
        key: 'componentWillReceiveProps',
        value: function componentWillReceiveProps(np) {
            var _this3 = this;

            this.setState(Object.assign(generateState(np.location.query, np.params), setCategories(np, this.state)), function () {
                _this3.reqData();
            });
        }
    }, {
        key: 'componentWillUnmount',
        value: function componentWillUnmount() {
            console.log('remove scroll listener');
            window.removeEventListener('scroll', this.handleScroll);
            // window.onscroll = null
        }
    }, {
        key: 'handleScroll',
        value: function handleScroll(e) {
            if (document.getElementById('browse-container')) {
                var ContainerHeight = document.getElementById('competition-container').offsetHeight;
                if (window.pageYOffset >= ContainerHeight - 600) this.reqMore();
            }
        }
    }, {
        key: 'reqData',
        value: function reqData() {
            var Filter = generateFilter(this.state);
            var Params = generateParams(this.state, this.props);
            if (!this.props.kompetisi.data[Filter]) {
                this.props.dispatch(KompetisiActions.fetchJelajah(Params, Filter));
            }
        }
    }, {
        key: 'reqMore',
        value: function reqMore() {
            var Filter = generateFilter(this.state);
            var Params = generateParams(this.state, this.props);
            var Kompetisi = this.props.kompetisi.data[Filter] ? this.props.kompetisi.data[Filter].data : null;
            if (Kompetisi) {
                if (!this.props.kompetisi.data[Filter].is_loading && this.props.kompetisi.data[Filter].meta.code === 200) {
                    Params.lastid = Kompetisi[Kompetisi.length - 1].id_kompetisi;
                    this.props.actions.getJelajahMore(Params, Filter);
                }
            }
        }
    }, {
        key: 'render',
        value: function render() {
            var _this4 = this;

            var _state = this.state,
                tag = _state.tag,
                username = _state.username,
                main_kat = _state.main_kat,
                sub_kat = _state.sub_kat,
                q = _state.q;
            var _props$kompetisi = this.props.kompetisi,
                data = _props$kompetisi.data,
                categories = _props$kompetisi.categories;

            var filter = generateFilter(this.state);
            var query = (0, _stringManager.queryToObj)(this.props.location.search.replace('?', '')) || {};

            var title = 'Jelajah Kompetisi';
            var description = 'Jelajahi kompetisi dari berbagai macam kategori di Kompetisi Indonesia';

            // jelajah kompetisi by kategori
            if (main_kat) {
                title += ' di Kategori "' + categories.data[main_kat].main_kat + '"';
            }

            // jelajah kompetisi by sub kategori
            if (sub_kat) {
                title += ' Subkategori "' + categories.data[main_kat].subkat[sub_kat].sub_kat + '"';
            }

            //jelajah kompetisi by tag
            if (tag) {
                title += ' dengan Tag "' + tag + '"';
                description = 'Jelajahi kompetisi berdasarkan tag ' + tag;
            }

            //jelajah kompetisi by username
            if (username) {
                title += ' Dipasang oleh "' + username + '"';
                description = 'Jelajahi kompetisi yang dipasang oleh "' + username + '"';
            }

            if (query.mediapartner == 1) {
                title += ' Media Partner';
                description = 'Jelajahi kompetisi yang menjadikan Kompetisi.id sebagai media partner';
            }

            return _react2.default.createElement(
                'div',
                { id: 'browse-container' },
                _react2.default.createElement(_Helmet2.default, {
                    title: title,
                    meta: [{ 'name': 'description', 'content': description }, { 'property': 'og:title', 'content': title }, { 'property': 'og:url', 'content': 'http://kompetisi.id/browse' }, { 'property': 'og:image', 'content': 'http://kompetisi.id/assets/images/wide-red-logo.png' }, { 'property': 'og:description', 'content': description }, { 'property': 'og:type', 'content': 'article' }]
                }),
                _react2.default.createElement(
                    'div',
                    { className: 'col-md-12 filter-jelajah' },
                    _react2.default.createElement(
                        'div',
                        { className: 'container' },
                        _react2.default.createElement(
                            'div',
                            { className: 'row no-margin' },
                            _react2.default.createElement(
                                'h1',
                                null,
                                ' Jelajah',
                                query.mediapartner == 1 ? ' Media Partner' : '',
                                ' ',
                                _react2.default.createElement(
                                    'a',
                                    { href: 'javascript:;', onClick: function onClick() {
                                            return modal('open', 'select-main-kat');
                                        } },
                                    parseInt(main_kat) >= 0 ? categories.data[main_kat].main_kat : 'Semua kategori',
                                    _react2.default.createElement('i', { className: 'fa fa-angle-down' })
                                ),
                                parseInt(main_kat) >= 0 ? _react2.default.createElement(
                                    'span',
                                    null,
                                    ' ',
                                    'dan',
                                    ' ',
                                    _react2.default.createElement(
                                        'a',
                                        { href: 'javascript:;', onClick: function onClick() {
                                                return modal('open', 'select-sub-kat');
                                            } },
                                        parseInt(sub_kat) >= 0 ? categories.data[main_kat].subkat[sub_kat].sub_kat : 'Semua subkategori',
                                        _react2.default.createElement('i', { className: 'fa fa-angle-down' })
                                    )
                                ) : null
                            )
                        ),
                        _react2.default.createElement(
                            'div',
                            { className: 'row no-margin' },
                            _react2.default.createElement(
                                'h1',
                                null,
                                'Sort by ',
                                _react2.default.createElement(
                                    'a',
                                    { href: 'javascript:;' },
                                    'Terbaru',
                                    _react2.default.createElement('i', { className: 'fa fa-angle-down' })
                                ),
                                tag ? ' Tag "' + tag + '"' : '',
                                q ? ' Pencarian "' + q + '"' : ''
                            )
                        ),
                        _react2.default.createElement(
                            'div',
                            { className: 'row no-margin' },
                            _react2.default.createElement(
                                'p',
                                { className: 'text-muted' },
                                'Gunakan filter ini untuk menemukan kompetisi yang sesuai dengan minat kamu'
                            )
                        )
                    )
                ),
                _react2.default.createElement(_CompetitionBox2.default, _extends({ subtitle: true }, data[filter])),
                _react2.default.createElement(
                    'div',
                    null,
                    _react2.default.createElement(
                        'div',
                        { className: 'modal', id: 'select-main-kat' },
                        _react2.default.createElement(
                            'div',
                            { className: 'container' },
                            _react2.default.createElement(
                                'h2',
                                { className: 'modal-title' },
                                'Pilih Kategori dibawah ini'
                            ),
                            _react2.default.createElement('a', { className: 'btn btn-white btn-close-modal btn-sm fa fa-close' }),
                            _react2.default.createElement('hr', null),
                            categories.meta && categories.meta.code == 200 ? _react2.default.createElement(
                                'ul',
                                { className: 'vertical-menu list-categories' },
                                _react2.default.createElement(
                                    'li',
                                    null,
                                    _react2.default.createElement(
                                        'a',
                                        {
                                            href: 'javascript:;',
                                            onClick: function onClick() {
                                                return _this4.setState({ main_kat: '' }, function () {
                                                    modal('close', 'select-main-kat');
                                                    _this4.context.router.push('/browse');
                                                });
                                            },
                                            className: 'text-muted' },
                                        'semua kategori'
                                    )
                                ),
                                categories.data.map(function (n, key) {
                                    return _react2.default.createElement(
                                        'li',
                                        { key: key },
                                        _react2.default.createElement(
                                            'a',
                                            {
                                                href: 'javascript:;',
                                                onClick: function onClick() {
                                                    modal('close', 'select-main-kat');
                                                    _this4.context.router.push('/browse/' + n.main_kat);
                                                },
                                                className: 'text-muted' },
                                            n.main_kat
                                        )
                                    );
                                })
                            ) : 'loading...'
                        )
                    ),
                    _react2.default.createElement(
                        'div',
                        { className: 'modal', id: 'select-sub-kat' },
                        _react2.default.createElement(
                            'div',
                            { className: 'container' },
                            _react2.default.createElement(
                                'h2',
                                { className: 'modal-title' },
                                'Pilih sub kategori dibawah ini'
                            ),
                            _react2.default.createElement(
                                'a',
                                { className: 'btn btn-white btn-close-modal btn-sm' },
                                _react2.default.createElement('i', { className: 'fa fa-close' })
                            ),
                            _react2.default.createElement('hr', null),
                            _react2.default.createElement(
                                'ul',
                                { className: 'vertical-menu list-categories' },
                                _react2.default.createElement(
                                    'li',
                                    null,
                                    _react2.default.createElement(
                                        'a',
                                        { href: 'javascript:;', onClick: function onClick() {
                                                return _this4.setState({ sub_kat: '' }, function () {
                                                    modal('close', 'select-sub-kat');
                                                });
                                            }, className: 'text-muted' },
                                        'Semua subkategori'
                                    )
                                ),
                                parseInt(main_kat) >= 0 ? categories.data[main_kat].subkat.map(function (n, key) {
                                    return _react2.default.createElement(
                                        'li',
                                        { key: key },
                                        _react2.default.createElement(
                                            'a',
                                            {
                                                href: 'javascript:;',
                                                onClick: function onClick() {
                                                    modal('close', 'select-sub-kat');
                                                    _this4.context.router.push('/browse/' + categories.data[main_kat].main_kat + '/' + n.sub_kat);
                                                },
                                                className: 'text-muted' },
                                            n.sub_kat
                                        )
                                    );
                                }) : null
                            )
                        )
                    )
                )
            );
        }
    }]);

    return BrowseCompetition;
}(_react.Component);

function setCategories(props, state) {
    var main_kat = void 0,
        sub_kat = void 0;
    if (props.kompetisi.categories.meta) {
        if (props.params.mainkat) {
            props.kompetisi.categories.data.map(function (n, key) {
                if (n.main_kat === props.params.mainkat) main_kat = key;
            });
        } else {
            main_kat = '';
        }

        if (props.params.subkat && props.kompetisi.categories.data[main_kat].subkat) {
            props.kompetisi.categories.data[main_kat].subkat.map(function (n, key) {
                if (n.sub_kat === props.params.subkat) sub_kat = key;
            });
        } else {
            sub_kat = '';
        }
    }
    return {
        main_kat: main_kat,
        sub_kat: sub_kat
    };
}

function generateState(query, params) {
    var tag = params.tag,
        username = params.username;
    var mediapartner = query.mediapartner,
        berakhir = query.berakhir,
        garansi = query.garansi,
        q = query.q;


    return {
        main_kat: '',
        sub_kat: '',
        q: q || '',
        tag: tag || '',
        username: username || '',
        is_mediapartner: mediapartner && mediapartner == 1,
        is_berakhir: berakhir && berakhir == 1,
        is_garansi: garansi && garansi == 1
    };
}

function generateParams(n) {
    var props = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
    var main_kat = n.main_kat,
        sub_kat = n.sub_kat,
        is_mediapartner = n.is_mediapartner,
        is_berakhir = n.is_berakhir,
        q = n.q,
        tag = n.tag,
        username = n.username,
        is_garansi = n.is_garansi;

    var Params = {};
    if (props) {
        var categories = props.kompetisi.categories;

        if (parseInt(main_kat) >= 0) Params.mainkat = categories.data[main_kat].main_kat;
        if (parseInt(sub_kat) >= 0) Params.subkat = categories.data[main_kat].subkat[sub_kat].sub_kat;
    }
    if (q && q != '') Params.q = q;
    if (username && username != '') Params.username = username;
    if (tag && tag != '') Params.tag = tag;
    if (is_mediapartner) Params.mediapartner = 1;
    if (is_berakhir) Params.berakhir = 1;
    if (is_garansi) Params.garansi = 1;
    Params.limit = 9;

    return Params;
}

function generateFilter(n) {
    var main_kat = n.main_kat,
        sub_kat = n.sub_kat,
        is_mediapartner = n.is_mediapartner,
        is_berakhir = n.is_berakhir,
        q = n.q,
        tag = n.tag,
        is_garansi = n.is_garansi;

    var Filter = 'jelajah';
    if (parseInt(main_kat) >= 0) Filter = Filter + '_' + main_kat;
    if (parseInt(sub_kat) >= 0) Filter = Filter + '_' + sub_kat;
    if (q != '') Filter = Filter + '_' + q;
    if (tag != '') Filter = Filter + '_' + tag;
    Filter = Filter + '_' + is_mediapartner + '_' + is_berakhir + '_' + is_garansi;

    return Filter;
}

function mapStateToProps(state) {
    var Kompetisi = state.Kompetisi;


    return {
        kompetisi: Kompetisi
    };
}

function mapDispatchToProps(dispatch) {
    return {
        actions: (0, _redux.bindActionCreators)(Object.assign({}, KompetisiActions), dispatch),
        dispatch: dispatch
    };
}

BrowseCompetition.contextTypes = {
    router: _propTypes2.default.func.isRequired
};

exports.default = (0, _reactRedux.connect)(mapStateToProps, mapDispatchToProps)(BrowseCompetition);