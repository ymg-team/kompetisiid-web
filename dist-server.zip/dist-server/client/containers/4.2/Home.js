'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _CompetitionBox = require('../../components/4.2/boxs/CompetitionBox');

var _CompetitionBox2 = _interopRequireDefault(_CompetitionBox);

var _MediapartnerBox = require('../../components/4.2/boxs/MediapartnerBox');

var _MediapartnerBox2 = _interopRequireDefault(_MediapartnerBox);

var _NewsBox = require('../../components/4.2/boxs/NewsBox');

var _NewsBox2 = _interopRequireDefault(_NewsBox);

var _Helmet = require('../../components/Helmet');

var _Helmet2 = _interopRequireDefault(_Helmet);

var _reactRouter = require('react-router');

var _HomeCount = require('../../components/4.2/cards/HomeCount');

var _HomeCount2 = _interopRequireDefault(_HomeCount);

var _HomeSlider = require('../../components/4.2/sliders/HomeSlider');

var _HomeSlider2 = _interopRequireDefault(_HomeSlider);

var _HomeCategories = require('../../components/4.2/cards/HomeCategories');

var _HomeCategories2 = _interopRequireDefault(_HomeCategories);

var _LocalStorage = require('../../../store/helpers/LocalStorage');

var _actions = require('../../../store/kompetisi/actions');

var _actions2 = require('../../../store/berita/actions');

var _reactRedux = require('react-redux');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Home = function (_Component) {
  _inherits(Home, _Component);

  function Home() {
    _classCallCheck(this, Home);

    return _possibleConstructorReturn(this, (Home.__proto__ || Object.getPrototypeOf(Home)).apply(this, arguments));
  }

  _createClass(Home, [{
    key: 'componentDidMount',

    // static fetchData({store})
    // {
    //   // load latest competitions
    //   const getLatestC = store.dispatch(fetchJelajah({limit:9}, 'home_latest'))
    //   const getMediaPartnerC = store.dispatch(fetchJelajah({limit:4,mediapartner:1}, 'home_mediapartner'))
    //   const getPopularC = store.dispatch(fetchJelajah({limit:4, popular: 1}, 'home_popular'))
    //   const getB = store.dispatch(fetchBerita({limit:6}, 'home_latest'))
    //   const getS = store.dispatch(getStats())

    //   return Promise.all([getMediaPartnerC, getLatestC,getPopularC, getB, getS])
    // }

    value: function componentDidMount() {
      if (!this.props.kompetisi.data.home_latest) this.props.dispatch((0, _actions.fetchJelajah)({ limit: 9 }, 'home_latest'));

      if (!this.props.kompetisi.data.home_popular) this.props.dispatch((0, _actions.fetchJelajah)({ limit: 4, popular: 1 }, 'home_popular'));

      if (!this.props.kompetisi.data.home_mediapartner) this.props.dispatch((0, _actions.fetchJelajah)({ limit: 4, mediapartner: 1 }, 'home_mediapartner'));

      if (!this.props.berita.data.home_latest) this.props.dispatch((0, _actions2.fetchBerita)({ limit: 6 }, 'home_latest'));

      this.reqCategories();
      this.props.dispatch((0, _actions.getStats)());
    }
  }, {
    key: 'componentWillReceiveProps',
    value: function componentWillReceiveProps(np) {
      if (np.kompetisi.categories.meta && np.kompetisi.categories.meta.code == 200) {
        // save categories to local storage
        (0, _LocalStorage.setStorage)('categories', JSON.stringify(np.kompetisi.categories));
      }
    }
  }, {
    key: 'reqCategories',
    value: function reqCategories() {
      var Categories = (0, _LocalStorage.getStorage)('categories');
      if (Categories) {
        this.props.dispatch((0, _actions.setCategories)(JSON.parse(Categories)));
      } else {
        this.props.dispatch((0, _actions.getCategories)());
      }
    }
  }, {
    key: 'render',
    value: function render() {
      var _props = this.props,
          kompetisi = _props.kompetisi,
          berita = _props.berita;

      return _react2.default.createElement(
        'div',
        null,
        _react2.default.createElement(_Helmet2.default, null),
        _react2.default.createElement(_HomeCount2.default, kompetisi.stats),
        _react2.default.createElement(_HomeSlider2.default, kompetisi.data['home_popular']),
        _react2.default.createElement(_HomeCategories2.default, kompetisi.categories),
        _react2.default.createElement(
          'div',
          { className: 'col-md-12' },
          _react2.default.createElement(
            'div',
            { className: 'container' },
            _react2.default.createElement(
              'div',
              { className: 'row' },
              _react2.default.createElement(
                'div',
                { className: 'subtitle-more' },
                _react2.default.createElement(
                  'h2',
                  { className: 'menu-title' },
                  'Kompetisi Terbaru'
                ),
                _react2.default.createElement(
                  _reactRouter.Link,
                  { to: '/browse', className: 'btn btn-white btn-sm' },
                  'Jelajah kompetisi'
                )
              )
            )
          ),
          _react2.default.createElement(_CompetitionBox2.default, _extends({
            subtitle: false
          }, kompetisi.data['home_latest']))
        ),
        _react2.default.createElement(
          'div',
          { className: 'col-md-12' },
          _react2.default.createElement(
            'div',
            { className: 'container' },
            _react2.default.createElement(
              'div',
              { className: 'row' },
              _react2.default.createElement(
                'div',
                { className: 'subtitle-more' },
                _react2.default.createElement(
                  'h2',
                  { className: 'menu-title' },
                  'Berita Terbaru'
                ),
                _react2.default.createElement(
                  _reactRouter.Link,
                  { to: '/news', className: 'btn btn-white btn-sm' },
                  'semua berita'
                )
              )
            )
          ),
          _react2.default.createElement(_NewsBox2.default, _extends({
            subtitle: false
          }, berita.data['home_latest']))
        ),
        _react2.default.createElement(_MediapartnerBox2.default, kompetisi.data['home_mediapartner'])
      );
    }
  }]);

  return Home;
}(_react.Component);

function mapStateToProps(state) {
  var Kompetisi = state.Kompetisi,
      Berita = state.Berita;

  return {
    kompetisi: Kompetisi,
    berita: Berita
  };
}

function mapDispatchToProps(dispatch) {
  return {
    dispatch: dispatch
  };
}

exports.default = (0, _reactRedux.connect)(mapStateToProps, mapDispatchToProps)(Home);