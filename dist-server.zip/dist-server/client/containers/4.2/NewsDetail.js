'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactRouter = require('react-router');

var _actions = require('../../../store/berita/actions');

var BeritaActions = _interopRequireWildcard(_actions);

var _Helmet = require('../../components/Helmet');

var _Helmet2 = _interopRequireDefault(_Helmet);

var _NewsAuthorCard = require('../../components/4.2/cards/NewsAuthorCard');

var _NewsAuthorCard2 = _interopRequireDefault(_NewsAuthorCard);

var _NewsBox = require('../../components/4.2/boxs/NewsBox');

var _NewsBox2 = _interopRequireDefault(_NewsBox);

var _DefaultLoader = require('../../components/4.2/loaders/DefaultLoader');

var _DefaultLoader2 = _interopRequireDefault(_DefaultLoader);

var _ErrorCard = require('../../components/4.2/cards/ErrorCard');

var _ErrorCard2 = _interopRequireDefault(_ErrorCard);

var _host = require('../../../config/host');

var _host2 = _interopRequireDefault(_host);

var _DomEvents = require('../../helpers/DomEvents');

var _reactRedux = require('react-redux');

var _DateTime = require('../../helpers/DateTime');

var _stringManager = require('string-manager');

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var NewsDetail = function (_Component) {
    _inherits(NewsDetail, _Component);

    function NewsDetail() {
        _classCallCheck(this, NewsDetail);

        return _possibleConstructorReturn(this, (NewsDetail.__proto__ || Object.getPrototypeOf(NewsDetail)).apply(this, arguments));
    }

    _createClass(NewsDetail, [{
        key: 'componentDidMount',
        value: function componentDidMount() {
            window.scrollTo(0, 0);
            (0, _DomEvents.pushScript)('https://kompetisiindonesia.disqus.com/embed.js');
            this.reqData(this.props);
        }
    }, {
        key: 'componentWillReceiveProps',
        value: function componentWillReceiveProps(np) {
            var encid = np.params.encid;

            if (encid != this.props.params.encid || np.berita.detail[encid].meta) {
                window.scrollTo(0, 0);
                this.resetDisquss(np);
            }
            this.reqData(np);
        }
    }, {
        key: 'resetDisquss',
        value: function resetDisquss(props) {
            var url = _host2.default[process.env.NODE_ENV].front + '/news/' + props.params.encid + '/' + props.params.title;
            // disquss reset after 1000ms
            if (window.DISQUS) DISQUS.reset({
                reload: true,
                config: function config() {
                    this.page.identifier = url;
                    this.page.url = url;
                }
            });
        }
    }, {
        key: 'reqData',
        value: function reqData(props) {
            var encid = props.params.encid;

            if (!this.props.berita.detail[encid]) {
                this.props.dispatch(BeritaActions.fetchBeritaDetail(encid));
            }
            if (!this.props.berita.data['related_' + encid]) {
                this.props.dispatch(BeritaActions.relatedBerita(encid));
            }
        }
    }, {
        key: 'generateTags',
        value: function generateTags() {
            var tags = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];

            tags = tags.split(',');
            if (tags && tags.length > 0) {
                return tags.map(function (n, key) {
                    return _react2.default.createElement(
                        'span',
                        { key: key },
                        _react2.default.createElement(
                            'a',
                            {
                                className: 'btn btn-white',
                                href: '/news/tag/' + n },
                            n
                        ),
                        ' '
                    );
                });
            }

            return null;
        }
    }, {
        key: 'render',
        value: function render() {
            var _props$params = this.props.params,
                encid = _props$params.encid,
                title = _props$params.title;
            var _props$berita = this.props.berita,
                detail = _props$berita.detail,
                data = _props$berita.data;

            var helmetdata = {
                title: 'Berita Kompetisi.id',
                description: 'Berita dari Kompetisi.id',
                url: _host2.default[process.env.NODE_ENV].front + '/news/' + encid + '/' + title,
                script: []
            };

            if (detail[encid] && detail[encid].meta && detail[encid].meta.code === 200) {
                helmetdata = Object.assign(helmetdata, {
                    title: detail[encid].data.title,
                    description: detail[encid].data.contenttext,
                    url: 'https://kompetisi.id/news/' + detail[encid].data.id + '/' + detail[encid].data.nospace_title,
                    image: detail[encid].data.image.original
                });

                //add jsonld
                helmetdata.script.push({
                    type: 'application/ld+json',
                    innerHTML: generateJsonld(detail[encid].data, helmetdata.url)
                });
            }

            return _react2.default.createElement(
                'div',
                null,
                _react2.default.createElement(_Helmet2.default, helmetdata),
                detail[encid] && detail[encid].meta ? parseInt(detail[encid].meta.code) === 200 ? _react2.default.createElement(
                    'div',
                    null,
                    _react2.default.createElement(
                        'div',
                        { className: 'col-md-6 col-md-push-3 col-md-pull-3' },
                        _react2.default.createElement(
                            'div',
                            { className: 'row' },
                            _react2.default.createElement(
                                'div',
                                { className: 'col-md-12' },
                                _react2.default.createElement(
                                    'div',
                                    { className: 'news-detail' },
                                    _react2.default.createElement(_NewsAuthorCard2.default, { data: detail[encid].data.author }),
                                    _react2.default.createElement(
                                        'div',
                                        { className: 'content' },
                                        _react2.default.createElement(
                                            'article',
                                            null,
                                            _react2.default.createElement(
                                                'h1',
                                                null,
                                                detail[encid].data.title
                                            ),
                                            _react2.default.createElement(
                                                'p',
                                                { className: 'meta text-muted' },
                                                _react2.default.createElement(
                                                    'span',
                                                    { className: 'meta--item' },
                                                    _react2.default.createElement('i', { className: 'fa fa-calendar-o' }),
                                                    ' ',
                                                    (0, _DateTime.datetimeToRelativeTime)(detail[encid].data.created_at)
                                                ),
                                                _react2.default.createElement(
                                                    'span',
                                                    { className: 'meta--item' },
                                                    _react2.default.createElement(
                                                        'a',
                                                        { href: 'javascript:;', title: 'komentar', onClick: function onClick() {
                                                                document.getElementById('comments').scrollIntoView({ behavior: 'smooth' });
                                                            } },
                                                        _react2.default.createElement('i', { className: 'fa fa-comment-o' }),
                                                        ' ',
                                                        _react2.default.createElement(
                                                            'span',
                                                            { className: 'fb-comments-count', 'data-href': helmetdata.url },
                                                            '0'
                                                        )
                                                    )
                                                )
                                            )
                                        )
                                    )
                                )
                            )
                        )
                    ),
                    _react2.default.createElement(
                        'div',
                        { className: 'col-md-12' },
                        _react2.default.createElement(
                            'div',
                            { className: 'row' },
                            _react2.default.createElement(
                                'div',
                                { className: 'news-detail' },
                                _react2.default.createElement(
                                    'div',
                                    { className: 'image' },
                                    _react2.default.createElement(
                                        'figure',
                                        null,
                                        _react2.default.createElement('img', { src: detail[encid].data.image.original })
                                    )
                                )
                            )
                        )
                    ),
                    _react2.default.createElement(
                        'div',
                        { className: 'col-md-6 col-md-push-3 col-md-pull-3' },
                        _react2.default.createElement(
                            'div',
                            { className: 'row' },
                            _react2.default.createElement(
                                'div',
                                { className: 'col-md-12' },
                                _react2.default.createElement(
                                    'div',
                                    { className: 'news-detail' },
                                    _react2.default.createElement(
                                        'article',
                                        { className: 'content' },
                                        _react2.default.createElement('p', { dangerouslySetInnerHTML: { __html: detail[encid].data.content } }),
                                        _react2.default.createElement(
                                            'div',
                                            { style: { margin: '1em 0' } },
                                            this.generateTags(detail[encid].data.tags)
                                        )
                                    )
                                )
                            )
                        )
                    ),
                    _react2.default.createElement(
                        'div',
                        { className: 'col-md-12 bg-gray-soft' },
                        _react2.default.createElement(_NewsBox2.default, data['related_' + encid])
                    )
                ) : _react2.default.createElement(_ErrorCard2.default, detail[encid].meta) : _react2.default.createElement(
                    'div',
                    { className: 'fullheight' },
                    _react2.default.createElement(_DefaultLoader2.default, null)
                ),
                detail[encid] && detail[encid].meta && detail[encid].is_loading ? _react2.default.createElement(_DefaultLoader2.default, null) : null,
                _react2.default.createElement(
                    'div',
                    { className: 'col-md-6 col-md-push-3 col-md-pull-3' },
                    _react2.default.createElement('div', { style: { padding: '50px 0' }, className: 'row comments', id: 'disqus_thread' })
                )
            );
        }
    }], [{
        key: 'fetchData',
        value: function fetchData(_ref) {
            var params = _ref.params,
                store = _ref.store;

            return store.dispatch(BeritaActions.fetchBeritaDetail(params.encid));
        }
    }]);

    return NewsDetail;
}(_react.Component);

exports.default = NewsDetail;


function generateJsonld(n, url) {
    var created_at = n.created_at.split(' ');
    var updated_at = n.updated_at.split(' ');
    return '{\n        "@context": "https://schema.org",\n        "@type": "Article",\n        "publisher": {\n            "@type": "Organization",\n            "name": "Id+More",\n            "logo": {\n                "@type": "ImageObject",\n                "url": "https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/21529_1680281178877316_3989323526762937427_n.png?oh=30d4cacd082cb9b7bffbd9abf01c1cb0&oe=5A01639C",\n                "height": "500",\n                "width": "500"\n            }\n        },\n        "author": {\n            "@type": "Person",\n            "name": "' + n.author.username + '",\n            "image": "http://kompetisi.id/assets/4.2/img/default-avatar.jpg",\n            "url": "http://kompetisi.id/' + n.author.username + '",\n            "sameAs": [\n                ""\n            ],\n            "description": "' + n.author.moto + '"\n        },\n        "headline": "' + n.title + '",\n        "url": "' + url + '",\n        "datePublished": "' + created_at[0] + 'T' + created_at[1] + '.000Z",\n        "dateModified": "' + updated_at[0] + 'T' + updated_at[1] + '.000Z",\n        "image": {\n            "@type": "ImageObject",\n            "url": "' + n.image.original + '",\n            "height": "500",\n            "width": "500"\n        },\n        "mainEntityOfPage": {\n            "@type": "WebPage",\n            "@id": "' + url + '"\n        },\n        "keywords": "' + n.tags + '",\n        "description": "' + (0, _stringManager.truncate)(n.contenttext, 300) + '"\n    }';
}

function mapStateToProps(state) {
    var Berita = state.Berita;

    return {
        berita: Berita
    };
}

function mapDispatchToProps(dispatch) {
    return {
        dispatch: dispatch
    };
}

module.exports = (0, _reactRedux.connect)(mapStateToProps, mapDispatchToProps)(NewsDetail);