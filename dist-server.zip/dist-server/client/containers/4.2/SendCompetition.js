'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactRouter = require('react-router');

var _Subheader = require('../../components/4.2/Subheader');

var _Subheader2 = _interopRequireDefault(_Subheader);

var _Helmet = require('../../components/Helmet');

var _Helmet2 = _interopRequireDefault(_Helmet);

var _AddCompetition = require('./AddCompetition');

var _InputText = require('../../components/4.2/form/InputText');

var _InputText2 = _interopRequireDefault(_InputText);

var _InputFile = require('../../components/4.2/form/InputFile');

var _InputFile2 = _interopRequireDefault(_InputFile);

var _Button = require('../../components/4.2/form/Button');

var _Button2 = _interopRequireDefault(_Button);

var _actions = require('../../../store/pasang/actions');

var _Validator = require('../../components/4.2/form/Validator');

var _reactRedux = require('react-redux');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var RecaptchaContainer = void 0;

var AddCompetitionFast = function (_Component) {
    _inherits(AddCompetitionFast, _Component);

    function AddCompetitionFast(props) {
        _classCallCheck(this, AddCompetitionFast);

        var _this = _possibleConstructorReturn(this, (AddCompetitionFast.__proto__ || Object.getPrototypeOf(AddCompetitionFast)).call(this, props));

        _this.state = {
            is_accept: false
        };
        return _this;
    }

    _createClass(AddCompetitionFast, [{
        key: 'componentDidMount',
        value: function componentDidMount() {
            addScript();
            setTimeout(function () {
                renderRecaptcha();
            }, 1500);
        }
    }, {
        key: 'componentWillReceiveProps',
        value: function componentWillReceiveProps() {
            renderRecaptcha();
        }
    }, {
        key: 'componentWillUnmount',
        value: function componentWillUnmount() {
            fullalert('close');
            grecaptcha.reset(RecaptchaContainer);
        }
    }, {
        key: 'handleSubmit',
        value: function handleSubmit() {
            if (!this.state.is_accept) {
                return fullalert('error', 'wajib menyetujui syarat dan ketentuan yang berlaku');
            } else if (grecaptcha.getResponse().length == 0) {
                return fullalert('error', 'Google Recaptcha belum valid');
            } else //start submit
                {
                    console.log('submit data...');
                    return this.props.dispatch((0, _actions.submitCepat)({
                        link: this.state.input_link,
                        nama: this.state.input_title,
                        email: this.state.input_email,
                        poster: this.state.input_poster
                    }));
                }
        }
    }, {
        key: 'render',
        value: function render() {
            var _this2 = this;

            var response = this.props.response;

            if (response.is_loading) fullalert('warning', 'mengirim kompetisi...');

            if (response.meta) {
                if (response.meta.code === 201) {
                    fullalert('success', response.meta.message);
                    setTimeout(function () {
                        location.href = '/add/send';
                    }, 500);
                } else {
                    fullalert('error', response.meta.message);
                }
            }

            return _react2.default.createElement(
                'div',
                null,
                _react2.default.createElement(_Helmet2.default, {
                    title: 'Kirim kompetisi',
                    description: _AddCompetition.desc
                }),
                _react2.default.createElement(_Subheader2.default, {
                    title: 'Kirim kompetisi',
                    desc: _AddCompetition.desc
                }),
                _react2.default.createElement(
                    'div',
                    { style: { marginTop: '20px' }, className: 'col-md-12' },
                    _react2.default.createElement(
                        'div',
                        { className: 'container' },
                        _react2.default.createElement(
                            'div',
                            { className: 'col-md-6 col-md-push-3 p-50-0' },
                            _react2.default.createElement(
                                'h2',
                                null,
                                'Kirim Kompetisi'
                            ),
                            _react2.default.createElement(
                                'p',
                                { className: 'text-muted' },
                                'Silahkan isi formulir dibawah ini secara komplit. Kami akan memberitahukan melalui email untuk memberikan jawaban seputar status kompetisi yang anda kirim ini.',
                                _react2.default.createElement('br', null),
                                _react2.default.createElement('br', null),
                                _react2.default.createElement(
                                    _reactRouter.Link,
                                    { to: '/add' },
                                    'kembali ke pasang'
                                )
                            ),
                            _react2.default.createElement('hr', null),
                            _react2.default.createElement(
                                'form',
                                { method: 'POST', className: 'form-ki', action: 'javascript:;' },
                                _react2.default.createElement(_InputText2.default, {
                                    label: 'email',
                                    name: 'input_email',
                                    setState: function setState(n, cb) {
                                        return _this2.setState(n, cb);
                                    },
                                    validate: this.state.input_email_validate || {},
                                    value: this.state.input_email || '',
                                    required: true,
                                    max: 50,
                                    type: 'email'
                                }),
                                _react2.default.createElement(_InputText2.default, {
                                    label: 'judul kompetisi',
                                    name: 'input_title',
                                    setState: function setState(n, cb) {
                                        return _this2.setState(n, cb);
                                    },
                                    validate: this.state.input_title_validate || {},
                                    value: this.state.input_title || '',
                                    required: true,
                                    max: 300
                                }),
                                _react2.default.createElement(_InputText2.default, {
                                    label: 'link sumber',
                                    name: 'input_link',
                                    setState: function setState(n, cb) {
                                        return _this2.setState(n, cb);
                                    },
                                    validate: this.state.input_link_validate || {},
                                    value: this.state.input_link || '',
                                    required: true,
                                    max: 300,
                                    type: 'link'
                                }),
                                _react2.default.createElement(_InputFile2.default, {
                                    label: 'poster',
                                    name: 'input_poster',
                                    max: '2000000' //max 2MB
                                    , setState: function setState(n, cb) {
                                        return _this2.setState(n, cb);
                                    },
                                    validate: this.state.input_poster_validate || {},
                                    value: this.state.input_poster || ''
                                }),
                                _react2.default.createElement(
                                    'div',
                                    { className: 'form-child' },
                                    _react2.default.createElement('input', {
                                        onClick: function onClick() {
                                            return _this2.setState({ is_accept: !_this2.state.is_accept });
                                        },
                                        type: 'checkbox' }),
                                    _react2.default.createElement(
                                        'span',
                                        { className: 'text-muted' },
                                        '\xA0 saya menyetujui syarat dan ketentuan yang berlaku'
                                    )
                                ),
                                _react2.default.createElement(
                                    'div',
                                    { className: 'form-child' },
                                    _react2.default.createElement('div', { id: 'g-recaptcha', className: 'g-recaptcha', 'data-sitekey': '6LcRCAQTAAAAANRlhWdxZvkj00Ee4aP_Zc2Q42Mi' })
                                ),
                                _react2.default.createElement(
                                    'div',
                                    { className: 'form-child' },
                                    _react2.default.createElement(_Button2.default, {
                                        text: 'kirim permintaan',
                                        disabled: response.is_loading,
                                        requiredInputs: ['input_email', 'input_title', 'input_link', 'input_poster'],
                                        setState: function setState(n, cb) {
                                            return _this2.setState(n, cb);
                                        },
                                        action: function action() {
                                            return _this2.handleSubmit();
                                        }
                                    })
                                )
                            )
                        )
                    )
                )
            );
        }
    }]);

    return AddCompetitionFast;
}(_react.Component);

function addScript() {
    if (!window.grecaptcha) {
        var script = document.createElement('script');
        script.setAttribute('src', 'https://www.google.com/recaptcha/api.js');
        document.head.appendChild(script);
    }
}

function renderRecaptcha() {
    if (window.grecaptcha && !document.getElementById('g-recaptcha')) {
        RecaptchaContainer = grecaptcha.render('g-recaptcha', {
            'sitekey': '6LcRCAQTAAAAANRlhWdxZvkj00Ee4aP_Zc2Q42Mi'
        });
    }
}

function mapStateToProps(state) {
    var Pasang = state.Pasang;

    return {
        response: Pasang.cepat
    };
}

function mapDispatchToProps(dispatch) {
    return {
        dispatch: dispatch
    };
}

module.exports = (0, _reactRedux.connect)(mapStateToProps, mapDispatchToProps)(AddCompetitionFast);