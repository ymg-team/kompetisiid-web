'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _InputText = require('../../components/4.2/form/InputText');

var _InputText2 = _interopRequireDefault(_InputText);

var _Button = require('../../components/4.2/form/Button');

var _Button2 = _interopRequireDefault(_Button);

var _Validator = require('../../components/4.2/form/Validator');

var _reactRouter = require('react-router');

var _Helmet = require('../../components/Helmet');

var _Helmet2 = _interopRequireDefault(_Helmet);

var _AuthFacebook = require('../../components/4.2/buttons/AuthFacebook');

var _AuthFacebook2 = _interopRequireDefault(_AuthFacebook);

var _AuthGoogle = require('../../components/4.2/buttons/AuthGoogle');

var _AuthGoogle2 = _interopRequireDefault(_AuthGoogle);

var _actions = require('../../../store/user/actions');

var _reactRedux = require('react-redux');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Login = function (_Component) {
    _inherits(Login, _Component);

    function Login(props) {
        _classCallCheck(this, Login);

        var _this = _possibleConstructorReturn(this, (Login.__proto__ || Object.getPrototypeOf(Login)).call(this, props));

        _this.state = {
            onprogress: false,
            profile: {}
        };
        return _this;
    }

    _createClass(Login, [{
        key: 'handleLogin',
        value: function handleLogin() {
            var _this2 = this;

            var _state = this.state,
                username = _state.username,
                password = _state.password;

            this.setState({
                onprogress: true
            }, function () {
                if (!password) //check username
                    {
                        //check username
                        if (username) _this2.props.dispatch((0, _actions.profile)(username));
                    } else {
                    //do login
                    _this2.props.dispatch((0, _actions.login)({ username: username, password: password }));
                }
            });
        }
    }, {
        key: 'componentWillReceiveProps',
        value: function componentWillReceiveProps(np) {
            var username = this.state.username;

            if (np.profile[username] && np.profile[username] != this.props.profile['username']) {
                this.setState({
                    onprogress: false,
                    profile: np.profile[username]
                });
            }

            if (np.login && np.login.meta) {
                this.setState({
                    onprogress: false
                });
            }
        }
    }, {
        key: 'render',
        value: function render() {
            var _this3 = this;

            var _state2 = this.state,
                username = _state2.username,
                password = _state2.password,
                onprogress = _state2.onprogress;
            var _props = this.props,
                profile = _props.profile,
                login = _props.login;

            var is_userfound = profile[username] && profile[username].meta && profile[username].meta.code == 200;

            //generate alert
            if (profile[username] && profile[username].meta) {
                if (profile[username].meta.code != 200) fullalert('error', 'user tidak terdaftar');else fullalert('close');
            }
            if (login && login.meta) {
                if (login.meta.code != 201) {
                    fullalert('error', 'password tidak cocok');
                } else {
                    fullalert('success', 'login berhasil');
                    setTimeout(function () {
                        location.href = '/dashboard/competition';
                    }, 500);
                }
            }
            return _react2.default.createElement(
                'section',
                { className: 'login' },
                _react2.default.createElement(_Helmet2.default, {
                    title: 'Masuk - Kompetisi Indonesia',
                    description: 'input username dan password kamu untuk mendapat akses lebih di Kompetisi Indonesia'
                }),
                _react2.default.createElement(
                    'div',
                    { className: 'login-box' },
                    _react2.default.createElement(
                        'div',
                        { className: 'login-box__title' },
                        _react2.default.createElement(
                            'h1',
                            { style: { textAlign: 'center', lineHeight: 1 } },
                            'Masuk ke KI  ',
                            _react2.default.createElement('br', null),
                            _react2.default.createElement(
                                'small',
                                { style: { fontWeight: 'normal' } },
                                'Mari ramaikan semangat kompetisi di Indonesia.'
                            )
                        )
                    ),
                    _react2.default.createElement(
                        'div',
                        { className: 'login-box__content' },
                        is_userfound ? _react2.default.createElement(
                            'div',
                            { className: 'login-box__content__avatar' },
                            _react2.default.createElement(
                                'p',
                                null,
                                'Halo ',
                                _react2.default.createElement(
                                    'strong',
                                    null,
                                    username
                                )
                            ),
                            _react2.default.createElement('img', { src: '/assets/4.2/img/default-avatar.jpg' })
                        ) : null,
                        _react2.default.createElement(
                            'form',
                            {
                                className: 'form-ki form-ki__white',
                                action: 'javascript:;',
                                method: 'post' },
                            _react2.default.createElement(
                                'div',
                                { className: 'form-child' },
                                is_userfound ? _react2.default.createElement(_InputText2.default, {
                                    label: 'Password',
                                    name: 'password',
                                    type: 'password',
                                    id: 'input-password',
                                    value: password || '',
                                    validate: this.state.password_validate || {},
                                    required: true,
                                    setState: function setState(n, cb) {
                                        return _this3.setState(n, cb);
                                    }
                                }) : _react2.default.createElement(_InputText2.default, {
                                    label: 'Email / username',
                                    name: 'username',
                                    type: 'text',
                                    id: 'input-username',
                                    value: username || '',
                                    validate: this.state.username_validate || {},
                                    required: true,
                                    setState: function setState(n, cb) {
                                        return _this3.setState(n, cb);
                                    }
                                })
                            ),
                            _react2.default.createElement(
                                'div',
                                { className: 'form-child' },
                                _react2.default.createElement(_Button2.default, {
                                    className: 'btn btn-borderwhite',
                                    disabled: onprogress,
                                    action: function action() {
                                        return _this3.handleLogin();
                                    },
                                    requiredInputs: ['username', 'password'],
                                    setState: function setState(n, cb) {
                                        return _this3.setState(n, cb);
                                    },
                                    type: 'submit',
                                    style: { fontWeight: 'bold', width: '100%', backgroundColor: '#FFF', color: '#292929' },
                                    text: onprogress ? 'loading...' : 'login'
                                })
                            )
                        ),
                        !is_userfound ? _react2.default.createElement(
                            'span',
                            null,
                            _react2.default.createElement(
                                'p',
                                null,
                                'Atau masuk menggunakan'
                            ),
                            _react2.default.createElement(
                                'div',
                                { className: 'login-box__content__auth' },
                                _react2.default.createElement(_AuthFacebook2.default, null),
                                _react2.default.createElement(_AuthGoogle2.default, null)
                            )
                        ) : _react2.default.createElement(
                            _reactRouter.Link,
                            { to: '/register' },
                            'Lupa password'
                        ),
                        _react2.default.createElement('hr', null),
                        _react2.default.createElement(
                            'p',
                            null,
                            'Belum punya akun, silahkan ',
                            _react2.default.createElement(
                                _reactRouter.Link,
                                { to: '/register' },
                                'Regiser Disini'
                            )
                        )
                    ),
                    _react2.default.createElement(
                        'div',
                        { className: 'login-box__footer' },
                        _react2.default.createElement(
                            'small',
                            null,
                            _react2.default.createElement(
                                _reactRouter.Link,
                                { to: '/' },
                                'Home'
                            )
                        ),
                        _react2.default.createElement(
                            'small',
                            null,
                            _react2.default.createElement(
                                'a',
                                { target: '_blank', href: 'https://goo.gl/forms/kMGGZQXJCjoyKThj1' },
                                'Kontak'
                            )
                        ),
                        _react2.default.createElement(
                            'small',
                            null,
                            _react2.default.createElement(
                                _reactRouter.Link,
                                { to: '#' },
                                'Privacy'
                            )
                        ),
                        _react2.default.createElement(
                            'small',
                            null,
                            _react2.default.createElement(
                                _reactRouter.Link,
                                { href: '/news/TXpVPQ/About' },
                                'About'
                            )
                        )
                    )
                )
            );
        }
    }]);

    return Login;
}(_react.Component);

function mapStateToProps(state) {
    var User = state.User;

    return {
        profile: User.profile,
        login: User.login
    };
}

function mapDispatchToProps(dispatch) {
    return {
        dispatch: dispatch
    };
}

exports.default = (0, _reactRedux.connect)(mapStateToProps, mapDispatchToProps)(Login);