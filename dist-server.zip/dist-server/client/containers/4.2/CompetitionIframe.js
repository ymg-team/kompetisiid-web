'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _Iframe = require('../../components/4.2/Iframe');

var _Iframe2 = _interopRequireDefault(_Iframe);

var _Redirect = require('../../components/4.2/Redirect');

var _Redirect2 = _interopRequireDefault(_Redirect);

var _DefaultLoader = require('../../components/4.2/loaders/DefaultLoader');

var _DefaultLoader2 = _interopRequireDefault(_DefaultLoader);

var _actions = require('../../../store/kompetisi/actions');

var _reactRedux = require('react-redux');

var _LinkGenerator = require('../../helpers/LinkGenerator');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var CompetitionIframe = function (_Component) {
    _inherits(CompetitionIframe, _Component);

    _createClass(CompetitionIframe, null, [{
        key: 'fetchData',
        value: function fetchData(_ref) {
            var params = _ref.params,
                store = _ref.store;

            return store.dispatch((0, _actions.getDetail)(params.encid));
        }
    }]);

    function CompetitionIframe(props) {
        _classCallCheck(this, CompetitionIframe);

        var _this = _possibleConstructorReturn(this, (CompetitionIframe.__proto__ || Object.getPrototypeOf(CompetitionIframe)).call(this, props));

        var state = {};
        var encid = props.params.encid;
        var iframe_type = props.route.iframe_type;
        var kompetisi = props.kompetisi;

        if (kompetisi.detail[encid] && kompetisi.detail[encid].meta && kompetisi.detail[encid].meta.code == 200) {
            state = {
                is_redirect: true
            };
        }

        _this.state = state;
        return _this;
    }

    _createClass(CompetitionIframe, [{
        key: 'render',
        value: function render() {
            var encid = this.props.params.encid;
            var iframe_type = this.props.route.iframe_type;
            var is_redirect = this.state.is_redirect;
            var kompetisi = this.props.kompetisi;

            return _react2.default.createElement(
                'div',
                null,
                typeof is_redirect != 'undefined' ? is_redirect === false ? _react2.default.createElement(_Iframe2.default, { src: kompetisi.detail[encid].data[iframe_type] }) : _react2.default.createElement(_Redirect2.default, { url: kompetisi.detail[encid].data[iframe_type] }) : _react2.default.createElement(_DefaultLoader2.default, null)
            );
        }
    }]);

    return CompetitionIframe;
}(_react.Component);

function mapStateToProps(state) {
    var Kompetisi = state.Kompetisi;

    return {
        kompetisi: Kompetisi
    };
}

function mapDispatchToProps(dispatch) {
    return {
        dispatch: dispatch
    };
}

exports.default = (0, _reactRedux.connect)(mapStateToProps, mapDispatchToProps)(CompetitionIframe);