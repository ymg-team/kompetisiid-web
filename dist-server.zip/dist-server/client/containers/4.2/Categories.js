'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _Helmet = require('../../components/Helmet');

var _Helmet2 = _interopRequireDefault(_Helmet);

var _Subheader = require('../../components/4.2/Subheader');

var _Subheader2 = _interopRequireDefault(_Subheader);

var _DefaultLoader = require('../../components/4.2/loaders/DefaultLoader');

var _DefaultLoader2 = _interopRequireDefault(_DefaultLoader);

var _actions = require('../../../store/kompetisi/actions');

var _reactRedux = require('react-redux');

var _reactRouter = require('react-router');

var _LocalStorage = require('../../../store/helpers/LocalStorage');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Categories = function (_Component) {
    _inherits(Categories, _Component);

    function Categories() {
        _classCallCheck(this, Categories);

        return _possibleConstructorReturn(this, (Categories.__proto__ || Object.getPrototypeOf(Categories)).apply(this, arguments));
    }

    _createClass(Categories, [{
        key: 'componentDidMount',
        value: function componentDidMount() {
            var Categories = (0, _LocalStorage.getStorage)('categories');
            if (Categories) {
                this.props.dispatch((0, _actions.setCategories)(JSON.parse(Categories)));
            } else {
                this.props.dispatch((0, _actions.getCategories)());
            }
        }
    }, {
        key: 'generateList',
        value: function generateList() {
            if (this.props.categories.meta.code == 200) {
                return _react2.default.createElement(
                    'div',
                    { className: 'col-md-12' },
                    _react2.default.createElement(
                        'div',
                        { className: 'container' },
                        this.props.categories.data.map(function (n, key) {
                            return _react2.default.createElement(
                                'div',
                                { key: key, className: 'categories' },
                                _react2.default.createElement(
                                    'h2',
                                    null,
                                    n.main_kat
                                ),
                                _react2.default.createElement(
                                    'div',
                                    { className: 'categories-child' },
                                    n.subkat.map(function (m, key) {
                                        return _react2.default.createElement(
                                            _reactRouter.Link,
                                            { key: key, to: '/browse/' + n.main_kat + '/' + m.sub_kat },
                                            m.sub_kat,
                                            _react2.default.createElement('i', { className: 'fa fa-angle-right' })
                                        );
                                    }),
                                    _react2.default.createElement(
                                        _reactRouter.Link,
                                        { to: '/browse/' + n.main_kat },
                                        'Semua ',
                                        n.main_kat,
                                        _react2.default.createElement('i', { className: 'fa fa-angle-right' })
                                    )
                                )
                            );
                        })
                    )
                );
            } else {
                return _react2.default.createElement(
                    'div',
                    { className: 'align-center text-muted' },
                    _react2.default.createElement(
                        'p',
                        null,
                        this.props.categories.meta.message
                    )
                );
            }
        }
    }, {
        key: 'render',
        value: function render() {
            return _react2.default.createElement(
                'div',
                null,
                _react2.default.createElement(_Helmet2.default, {
                    title: 'Kategori Kompetisi',
                    description: 'Ikuti kompetisi-kompetisi berdasarkan kategori dan minat kamu'
                }),
                _react2.default.createElement(_Subheader2.default, {
                    title: 'Kategori Kompetisi',
                    desc: 'Ikuti kompetisi-kompetisi berdasarkan kategori dan minat kamu'
                }),
                _react2.default.createElement(
                    'div',
                    { className: 'col-md-12' },
                    _react2.default.createElement('div', { className: 'm-30' })
                ),
                this.props.categories.meta ? this.generateList() : _react2.default.createElement(_DefaultLoader2.default, null),
                _react2.default.createElement(
                    'div',
                    { className: 'col-md-12' },
                    _react2.default.createElement('div', { className: 'm-30' })
                )
            );
        }
    }], [{
        key: 'fetchData',
        value: function fetchData(_ref) {
            var store = _ref.store;

            return store.dispatch((0, _actions.getCategories)());
        }
    }]);

    return Categories;
}(_react.Component);

function mapStateToProps(state) {
    var Kompetisi = state.Kompetisi;


    return {
        categories: Kompetisi.categories
    };
}

function mapDispatchToProps(dispatch) {
    return {
        dispatch: dispatch
    };
}

exports.default = (0, _reactRedux.connect)(mapStateToProps, mapDispatchToProps)(Categories);