'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _HeaderDashboard = require('../../../components/4.2/cards/HeaderDashboard');

var _HeaderDashboard2 = _interopRequireDefault(_HeaderDashboard);

var _Tab = require('../../../components/4.2/navigations/Tab');

var _Tab2 = _interopRequireDefault(_Tab);

var _CompetitionListCard = require('../../../components/4.2/cards/dashboard/CompetitionListCard');

var _CompetitionListCard2 = _interopRequireDefault(_CompetitionListCard);

var _DefaultLoader = require('../../../components/4.2/loaders/DefaultLoader');

var _DefaultLoader2 = _interopRequireDefault(_DefaultLoader);

var _Helmet = require('../../../components/Helmet');

var _Helmet2 = _interopRequireDefault(_Helmet);

var _actions = require('../../../../store/kompetisi/actions');

var _reactRedux = require('react-redux');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Filter = void 0,
    Params = void 0;
var Limit = 20;

var MyCompetition = function (_Component) {
    _inherits(MyCompetition, _Component);

    function MyCompetition() {
        _classCallCheck(this, MyCompetition);

        return _possibleConstructorReturn(this, (MyCompetition.__proto__ || Object.getPrototypeOf(MyCompetition)).apply(this, arguments));
    }

    _createClass(MyCompetition, [{
        key: 'componentDidMount',
        value: function componentDidMount() {
            Filter = generateFilter(this.props);
            Params = generateParams(this.props);
            this.props.dispatch((0, _actions.fetchJelajah)(Params, Filter));
        }
    }, {
        key: 'componentWillReceiveProps',
        value: function componentWillReceiveProps(np) {
            var NextFilter = generateFilter(np);
            if (Filter != NextFilter) {
                Filter = NextFilter;
                Params = generateParams(np);
                this.props.dispatch((0, _actions.fetchJelajah)(Params, Filter));
            }
        }
    }, {
        key: 'render',
        value: function render() {
            var tab_active = this.props.route.tab_active;
            var data = this.props.data;

            var tabcontent = [{
                text: 'berlangsung',
                is_active: tab_active == 1,
                count: 7,
                target: '/dashboard/competition/live'
            }, {
                text: 'berakhir',
                is_active: tab_active == 2,
                count: 12,
                target: '/dashboard/competition/end'
            }, {
                text: 'moderasi',
                is_active: tab_active == 3,
                count: 12,
                target: '/dashboard/competition/moderation'
            }, {
                text: 'ditolak',
                is_active: tab_active == 4,
                count: 2,
                target: '/dashboard/competition/reject'
            }];

            return _react2.default.createElement(
                'div',
                null,
                _react2.default.createElement(_Helmet2.default, {
                    title: 'kompetisi ' + tabcontent[tab_active - 1].text
                }),
                _react2.default.createElement(_HeaderDashboard2.default, {
                    title: 'Kompetisi Terpasang',
                    text: 'Berikut adalah kompetisi yang telah anda pasang di Kompetisi Indonesia.'
                }),
                _react2.default.createElement(_Tab2.default, {
                    tabs: tabcontent
                }),
                data[Filter] && data[Filter].is_loading ? _react2.default.createElement(
                    'div',
                    { className: 'row' },
                    _react2.default.createElement(_DefaultLoader2.default, null)
                ) : null,
                data[Filter] && data[Filter].meta ? _react2.default.createElement(
                    'div',
                    { className: 'p-b-50' },
                    data[Filter].meta.code == 200 ? _react2.default.createElement(
                        'p',
                        null,
                        'Menampilkan ',
                        _react2.default.createElement(
                            'strong',
                            null,
                            data[Filter].data.length
                        ),
                        ' dari ',
                        _react2.default.createElement(
                            'strong',
                            null,
                            'beberapa'
                        ),
                        ' kompetisi'
                    ) : null,
                    data[Filter].meta.code == 200 ? data[Filter].data.map(function (n, key) {
                        return _react2.default.createElement(_CompetitionListCard2.default, { key: key, n: n });
                    }) : _react2.default.createElement(
                        'p',
                        { className: 'text-muted' },
                        data[Filter].meta.message
                    ),
                    data[Filter].meta.code == 200 ? _react2.default.createElement(
                        'span',
                        null,
                        _react2.default.createElement(
                            'a',
                            { className: 'btn btn-white' },
                            _react2.default.createElement(
                                'i',
                                { className: 'fa fa-angle-left' },
                                '\xA0'
                            ),
                            'sebelumnya '
                        ),
                        data[Filter].data.length >= Limit ? _react2.default.createElement(
                            'a',
                            { className: 'btn btn-white' },
                            'berikutnya ',
                            _react2.default.createElement('i', { className: 'fa fa-angle-right' })
                        ) : null
                    ) : null
                ) : null
            );
        }
    }], [{
        key: 'fetchData',
        value: function fetchData(_ref) {
            var store = _ref.store,
                params = _ref.params,
                query = _ref.query;

            return new Promise(function (resolve) {
                return resolve();
            });
        }
    }]);

    return MyCompetition;
}(_react.Component);

function generateFilter(props) {
    var tab_active = props.route.tab_active;

    return props.session.username + '_' + tab_active + '_' + Limit;
}

function generateParams(props) {
    var tab_active = props.route.tab_active;

    var Params = {
        limit: Limit,
        username: props.session.username
    };
    if (tab_active == 1) Params.live = 1;
    if (tab_active == 2) Params.berakhir = 1;
    if (tab_active == 3) Params.waiting = 1;
    if (tab_active == 4) Params.reject = 1;

    return Params;
}

function mapStateToProps(state) {
    var Kompetisi = state.Kompetisi,
        User = state.User;

    return {
        data: Kompetisi.data,
        session: User.session.data
    };
}

function mapDispatchToProps(dispatch) {
    return {
        dispatch: dispatch
    };
}

module.exports = (0, _reactRedux.connect)(mapStateToProps, mapDispatchToProps)(MyCompetition);