'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _TabProfile = require('../../components/4.2/navigations/TabProfile');

var _TabProfile2 = _interopRequireDefault(_TabProfile);

var _Helmet = require('../../components/Helmet');

var _Helmet2 = _interopRequireDefault(_Helmet);

var _actions = require('../../../store/user/actions');

var _DateTime = require('../../helpers/DateTime');

var _reactRedux = require('react-redux');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var UserProfile = function (_Component) {
    _inherits(UserProfile, _Component);

    function UserProfile() {
        _classCallCheck(this, UserProfile);

        return _possibleConstructorReturn(this, (UserProfile.__proto__ || Object.getPrototypeOf(UserProfile)).apply(this, arguments));
    }

    _createClass(UserProfile, [{
        key: 'componentDidMount',
        value: function componentDidMount() {
            this.reqData(this.props);
        }
    }, {
        key: 'componentWillReceiveProps',
        value: function componentWillReceiveProps(np) {
            this.reqData(np);
        }
    }, {
        key: 'reqData',
        value: function reqData(props) {
            var username = props.params.username;

            if (!this.props.profile[username]) {
                var dispatch = props.dispatch;

                window.scrollTo(0, 0);
                dispatch((0, _actions.profile)(username));
            }
        }
    }, {
        key: 'render',
        value: function render() {
            var profile = this.props.profile;
            var username = this.props.params.username;

            var helmetdata = {};

            if (profile[username] && profile[username].meta) {
                if (profile[username].meta.code == 200) {
                    helmetdata = {
                        title: 'profil ' + username + ' - Kompetisi Indonesia',
                        description: 'halaman profil ' + username + ' - di Kompetisi Indonesia'
                    };
                } else {
                    helmetdata = {
                        title: 'profil ' + username + ' - Kompetisi Indonesia',
                        description: profile[username].meta.message
                    };
                }
            } else {
                helmetdata = {
                    title: 'user tidak ditemukan',
                    description: 'user tidak ditemukan'
                };
            }

            return _react2.default.createElement(
                'div',
                { className: 'profile' },
                _react2.default.createElement(_Helmet2.default, helmetdata),
                _react2.default.createElement(
                    'div',
                    { className: 'col-md-12 no-margin profile__cover' },
                    _react2.default.createElement(
                        'div',
                        { className: 'row' },
                        _react2.default.createElement(
                            'div',
                            { className: 'col-md-12 divider' },
                            ' '
                        )
                    ),
                    _react2.default.createElement(
                        'div',
                        { className: 'row meta-container' },
                        _react2.default.createElement(
                            'div',
                            { className: 'container' },
                            _react2.default.createElement(
                                'div',
                                { className: 'col-sm-1 col-sm-push-1 col-xs-3' },
                                _react2.default.createElement(
                                    'div',
                                    { className: 'avatar' },
                                    _react2.default.createElement('img', { src: '/assets/4.2/img/avatar-1.jpg' })
                                )
                            ),
                            _react2.default.createElement(
                                'div',
                                { className: 'col-sm-9 col-sm-push-1 col-xs-9' },
                                profile[username] && profile[username].meta ? profile[username].meta.code == 200 ? _react2.default.createElement(
                                    'h3',
                                    null,
                                    profile[username].data.username,
                                    '\xA0',
                                    _react2.default.createElement(
                                        'small',
                                        null,
                                        'terdaftar ',
                                        (0, _DateTime.epochToRelativeTime)(profile[username].data.register_date)
                                    )
                                ) : _react2.default.createElement(
                                    'h3',
                                    null,
                                    profile[username].meta.message
                                ) : _react2.default.createElement(
                                    'h3',
                                    null,
                                    _react2.default.createElement(
                                        'i',
                                        null,
                                        '...'
                                    )
                                )
                            )
                        )
                    )
                ),
                profile[username] && profile[username].meta && profile[username].meta.code == 200 ? _react2.default.createElement(_TabProfile2.default, { data: profile[username].data.competition_stats }) : null
            );
        }
    }], [{
        key: 'fetchData',
        value: function fetchData(_ref) {
            var params = _ref.params,
                store = _ref.store;

            return store.dispatch((0, _actions.profile)(params.username));
        }
    }]);

    return UserProfile;
}(_react.Component);

function mapStateToProps(state) {
    var User = state.User,
        Kompetisi = state.Kompetisi;

    return {
        profile: User.profile,
        kompetisi: Kompetisi.data
    };
}

function mapDispatchToProps(dispatch) {
    return {
        dispatch: dispatch
    };
}

exports.default = (0, _reactRedux.connect)(mapStateToProps, mapDispatchToProps)(UserProfile);