'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactHelmet = require('react-helmet');

var _reactHelmet2 = _interopRequireDefault(_reactHelmet);

var _stringManager = require('string-manager');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var Helmet = function Helmet(props) {
    var title = props.title,
        description = props.description,
        url = props.url,
        image = props.image,
        type = props.type,
        script = props.script,
        link = props.link;


    return _react2.default.createElement(_reactHelmet2.default, {
        title: (0, _stringManager.toCamelCase)(title) + ' - Kompetisi.id',
        meta: [{ 'name': 'description', 'content': description }, { 'property': 'og:type', 'content': type || 'article' }, { 'property': 'og:title', 'content': (0, _stringManager.toCamelCase)(title) + ' - Kompetisi.id' }, { 'property': 'og:url', 'content': url }, { 'property': 'og:image', 'content': image }, { 'property': 'og:description', 'content': description }, { 'property': 'twitter:card', 'content': type || 'summarry' }, { 'property': 'twitter:site', 'content': '@kompetisiindo' }, { 'property': 'twitter:title', 'content': title }, { 'property': 'twitter:description', 'content': description }, { 'property': 'twitter:image', 'content': image }],
        script: script,
        link: link
    });
};

Helmet.defaultProps = {
    title: 'Ada hadiah setiap hari',
    description: 'Platform Kompetisi online untuk warga Indonesia',
    image: 'http://kompetisi.id/assets/icons/icon-128x128.png'
};

exports.default = Helmet;