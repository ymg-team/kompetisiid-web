"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
var duration = exports.duration = 200;
var style = exports.style = {
  fade: {
    default: {
      transition: "opacity " + duration + "ms ease-in-out",
      opacity: 0
    },
    entering: { opacity: 0 },
    entered: { opacity: 1 }
  }
};