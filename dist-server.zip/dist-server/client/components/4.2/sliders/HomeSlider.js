'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var data = [{
    image: '/assets/4.2/img/slider/slider-1.png',
    title: 'Ikuti Kompetisinya dan Menangkan Hadiahnya',
    text: 'Temukan dan ikuti beragam kompetisi sesuai dengan minat kamu, dan berjuanglah untuk menjadi pemenang dan dapatkan hadiahnya.'
}, {
    image: '/assets/4.2/img/slider/slider-2.png',
    title: 'Kamu Seorang Penyelenggara Kompetisi',
    text: 'Pasang kompetisi disini untuk meramaikan kompetisi yang kamu adakan dan mempermudah peserta mengikuti kompetisi tersebut.'
}];

var HomeSlider = function (_Component) {
    _inherits(HomeSlider, _Component);

    function HomeSlider() {
        _classCallCheck(this, HomeSlider);

        return _possibleConstructorReturn(this, (HomeSlider.__proto__ || Object.getPrototypeOf(HomeSlider)).apply(this, arguments));
    }

    _createClass(HomeSlider, [{
        key: 'componentDidMount',
        value: function componentDidMount() {
            // init slidder
            (function () {
                var currentIndex = 0;
                var SliderItemEl = document.getElementsByClassName('slider--item');
                var BtnPrevEl = document.getElementById('btn-slider--prev');
                var BtnNextEl = document.getElementById('btn-slider--next');
                var totalIndex = SliderItemEl.length;

                // event listener
                BtnPrevEl.addEventListener('click', prev);
                BtnNextEl.addEventListener('click', cycle);

                //interval 
                var autoSlide = setInterval(cycle, 10000);

                function cycle() {
                    clearInterval(autoSlide);
                    autoSlide = setInterval(cycle, 10000);
                    if (currentIndex == 0) {
                        currentIndex++;
                    } else if (currentIndex == totalIndex - 1) {
                        currentIndex = 0;
                    } else {
                        currentIndex++;
                    }

                    return toggle();
                }

                function prev() {
                    clearInterval(autoSlide);
                    autoSlide = setInterval(cycle, 10000);
                    if (currentIndex == 0) {
                        currentIndex = totalIndex - 1;
                    } else if (currentIndex == totalIndex - 1) {
                        currentIndex = totalIndex - 2;
                    } else {
                        currentIndex--;
                    }

                    return toggle();
                }

                function toggle() {
                    Object.keys(SliderItemEl).map(function (n, key) {
                        var visibility = 'hidden';
                        var opacity = 0;
                        if (key == currentIndex) visibility = 'visible';
                        if (key == currentIndex) opacity = 1;
                        SliderItemEl[key].style.visibility = visibility;
                        SliderItemEl[key].style.opacity = opacity;
                    });
                }
            })();
        }
    }, {
        key: 'render',
        value: function render() {
            return _react2.default.createElement(
                'div',
                { className: 'col-md-12 slider' },
                _react2.default.createElement(
                    'div',
                    { className: 'slider-buttons' },
                    _react2.default.createElement(
                        'a',
                        { className: 'btn-nav btn-nav--left', id: 'btn-slider--prev', href: 'javascript:;' },
                        _react2.default.createElement('i', { className: 'fa fa-angle-left' })
                    ),
                    _react2.default.createElement(
                        'a',
                        { className: 'btn-nav btn-nav--right', id: 'btn-slider--next', href: 'javascript:;' },
                        _react2.default.createElement('i', { className: 'fa fa-angle-right' })
                    )
                ),
                _react2.default.createElement(
                    'div',
                    { className: 'slider-container' },
                    data.map(function (n, key) {
                        var style = {
                            backgroundImage: 'url(' + n.image + ')',
                            visibility: key == 0 ? 'visible' : 'hidden',
                            opacity: key == 0 ? 1 : 0,
                            marginTop: key == 0 ? '0' : '-700px'
                        };
                        return _react2.default.createElement(
                            'div',
                            { key: key, className: 'slider--item', style: style },
                            _react2.default.createElement(
                                'div',
                                { className: 'slider--item--text' },
                                _react2.default.createElement(
                                    'h2',
                                    null,
                                    n.title
                                ),
                                _react2.default.createElement(
                                    'p',
                                    null,
                                    n.text
                                )
                            )
                        );
                    })
                )
            );
        }
    }]);

    return HomeSlider;
}(_react.Component);

exports.default = HomeSlider;