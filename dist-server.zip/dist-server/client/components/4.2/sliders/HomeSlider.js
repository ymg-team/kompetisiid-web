'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _stringManager = require('string-manager');

var _reactRouter = require('react-router');

var _reactAddonsCssTransitionGroup = require('react-addons-css-transition-group');

var _reactAddonsCssTransitionGroup2 = _interopRequireDefault(_reactAddonsCssTransitionGroup);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var HomeSlider = function (_PureComponent) {
    _inherits(HomeSlider, _PureComponent);

    function HomeSlider() {
        _classCallCheck(this, HomeSlider);

        var _this = _possibleConstructorReturn(this, (HomeSlider.__proto__ || Object.getPrototypeOf(HomeSlider)).call(this));

        _this.state = {
            active: 0
        };
        return _this;
    }

    _createClass(HomeSlider, [{
        key: 'componentDidMount',
        value: function componentDidMount() {}
    }, {
        key: 'componentWillUnmount',
        value: function componentWillUnmount() {}
    }, {
        key: 'render',
        value: function render() {
            var _this2 = this;

            var _props = this.props,
                data = _props.data,
                meta = _props.meta;

            if (meta.code) {
                if (meta.code == 200) {
                    // success get data
                    return _react2.default.createElement(
                        'div',
                        { className: 'col-md-12 home-slider' },
                        _react2.default.createElement(
                            'div',
                            { className: 'container' },
                            _react2.default.createElement(
                                'div',
                                { className: 'row' },
                                _react2.default.createElement(
                                    _reactAddonsCssTransitionGroup2.default,
                                    {
                                        name: 'card',
                                        transitionEnterTimeout: 500,
                                        transitionLeaveTimeout: 500 },
                                    _react2.default.createElement(CardPreview, data[this.state.active])
                                ),
                                _react2.default.createElement(
                                    'div',
                                    { className: 'col-sm-12 home-slider-navigation' },
                                    data.map(function (n, key) {
                                        return _react2.default.createElement(CardSelector, _extends({
                                            handleClick: function handleClick() {
                                                return _this2.setState({ active: key });
                                            },
                                            is_active: _this2.state.active == key,
                                            key: key
                                        }, n));
                                    })
                                )
                            ),
                            _react2.default.createElement(
                                'div',
                                { className: 'row' },
                                _react2.default.createElement('div', { className: 'col-sm-12' })
                            )
                        )
                    );
                } else {
                    // failed get data
                    return null;
                }
            } else {
                return null;
            }
        }
    }]);

    return HomeSlider;
}(_react.PureComponent);

HomeSlider.defaultProps = {
    meta: {}
};
exports.default = HomeSlider;


var CardPreview = function CardPreview(props) {
    console.log(props);
    return _react2.default.createElement(
        'span',
        null,
        _react2.default.createElement(
            'div',
            { className: 'col-sm-6 home-slider-left' },
            _react2.default.createElement(
                'h2',
                null,
                props.title
            ),
            _react2.default.createElement(
                'h3',
                null,
                'Penyelenggara ',
                props.penyelenggara,
                _react2.default.createElement('br', null),
                'Total Hadiah Senilai ',
                props.total_hadiah,
                _react2.default.createElement('br', null),
                'Deadline ',
                props.sisadeadline
            ),
            _react2.default.createElement(
                'p',
                { style: { marginBottom: '1.5em' } },
                (0, _stringManager.truncate)(props.sort, 300, '...')
            ),
            _react2.default.createElement(
                _reactRouter.Link,
                { className: 'btn btn-bordergray', to: '/competition/' + props.id_kompetisi + '/regulations/' + props.nospace_title },
                'SYARAT KETENTUAN'
            )
        ),
        _react2.default.createElement(
            'div',
            { className: 'col-sm-6 home-slider-right' },
            _react2.default.createElement('div', { className: 'home-slider-poster', style: { backgroundImage: 'url(' + props.poster.original + ')' } })
        )
    );
};

var CardSelector = function CardSelector(props) {
    return _react2.default.createElement(
        'div',
        { className: 'col-sm-6 col-md-3 home-slider-item ' + (props.is_active ? 'active' : '') },
        _react2.default.createElement(
            'a',
            { href: 'javascript:;', onClick: function onClick() {
                    return props.handleClick();
                } },
            props.title,
            _react2.default.createElement('br', null),
            _react2.default.createElement(
                'small',
                null,
                props.mainkategori,
                ' - ',
                props.subkategori,
                ' ',
                _react2.default.createElement('br', null),
                _react2.default.createElement(
                    'strong',
                    null,
                    props.total_hadiah
                )
            )
        )
    );
};