'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _DefaultLoader = require('../loaders/DefaultLoader');

var _DefaultLoader2 = _interopRequireDefault(_DefaultLoader);

var _reactRouter = require('react-router');

var _CompetitionListCard = require('../cards/CompetitionListCard');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var CategoriesOnHome = function (_Component) {
    _inherits(CategoriesOnHome, _Component);

    function CategoriesOnHome(props) {
        _classCallCheck(this, CategoriesOnHome);

        var _this = _possibleConstructorReturn(this, (CategoriesOnHome.__proto__ || Object.getPrototypeOf(CategoriesOnHome)).call(this, props));

        _this.state = {
            active: 0,
            categories: props.categories
        };
        return _this;
    }

    _createClass(CategoriesOnHome, [{
        key: 'componentDidMount',
        value: function componentDidMount() {
            this.reqData();
        }
    }, {
        key: 'reqData',
        value: function reqData() {
            var dispatch = this.props.dispatch;
            var active = this.state.active;

            var params = {
                limit: 1,
                mainkat: this.props.categories.data.find(function (n, key) {
                    return active == key;
                }).main_kat
            };
            return this.props.fetchJelajah(params, 'home_category_' + active);
        }
    }, {
        key: 'render',
        value: function render() {
            var _this2 = this;

            var kompetisi = this.props.kompetisi;
            var _state = this.state,
                active = _state.active,
                categories = _state.categories;

            var Filter = 'home_category_' + active;
            return _react2.default.createElement(
                'div',
                { className: 'col-md-12', style: { borderBottom: '1px solid #969696' } },
                _react2.default.createElement(
                    'div',
                    { className: 'container' },
                    _react2.default.createElement(
                        'div',
                        { className: 'row' },
                        _react2.default.createElement(
                            'div',
                            { className: 'subtitle-more' },
                            _react2.default.createElement(
                                'h2',
                                { className: 'menu-title' },
                                'Kompetisi Utama'
                            ),
                            _react2.default.createElement(
                                _reactRouter.Link,
                                {
                                    to: '/browse/' + categories.data[active].main_kat,
                                    className: 'btn btn-white btn-sm',
                                    style: { marginTop: '-72px', float: 'right' } },
                                'Lihat ' + categories.data[active].main_kat
                            )
                        )
                    ),
                    _react2.default.createElement(
                        'div',
                        { className: 'row' },
                        kompetisi.data[Filter] && kompetisi.data[Filter].meta ? kompetisi.data[Filter].meta.code == 200 ? _react2.default.createElement(
                            'div',
                            null,
                            _react2.default.createElement(
                                'div',
                                { className: 'col-md-5' },
                                _react2.default.createElement(
                                    'div',
                                    { className: 'main-competition--left' },
                                    _react2.default.createElement(
                                        _reactRouter.Link,
                                        { to: '/competition/' + kompetisi.data[Filter].data[0].id_kompetisi + '/regulations/' + kompetisi.data[Filter].data[0].nospace_title },
                                        _react2.default.createElement('img', {
                                            alt: kompetisi.data[Filter].data[0].title,
                                            src: kompetisi.data[Filter].data[0].poster.small })
                                    )
                                )
                            ),
                            _react2.default.createElement(
                                'div',
                                { className: 'col-md-5' },
                                _react2.default.createElement(
                                    'article',
                                    { className: 'main-competition--right' },
                                    _react2.default.createElement(
                                        'div',
                                        { className: 'categories' },
                                        _react2.default.createElement(
                                            _reactRouter.Link,
                                            { className: 'text-muted', to: '/browse/' + kompetisi.data[Filter].data[0].mainkategori },
                                            _react2.default.createElement(
                                                'strong',
                                                null,
                                                kompetisi.data[Filter].data[0].mainkategori
                                            )
                                        ),
                                        ',\xA0',
                                        _react2.default.createElement(
                                            _reactRouter.Link,
                                            { className: 'text-muted', to: '/browse/' + kompetisi.data[Filter].data[0].mainkategori + '/' + kompetisi.data[Filter].data[0].subkategori },
                                            _react2.default.createElement(
                                                'strong',
                                                null,
                                                kompetisi.data[Filter].data[0].subkategori
                                            )
                                        )
                                    ),
                                    _react2.default.createElement('br', null),
                                    _react2.default.createElement(
                                        _reactRouter.Link,
                                        { to: '/competition/' + kompetisi.data[Filter].data[0].id_kompetisi + '/regulations/' + kompetisi.data[Filter].data[0].nospace_title },
                                        _react2.default.createElement(
                                            'h3',
                                            { className: 'title' },
                                            kompetisi.data[Filter].data[0].title
                                        )
                                    ),
                                    _react2.default.createElement(
                                        'small',
                                        null,
                                        'Dipasang \xA0',
                                        _react2.default.createElement(
                                            _reactRouter.Link,
                                            { to: '/' + kompetisi.data[Filter].data[0].author.username },
                                            kompetisi.data[Filter].data[0].author.username
                                        )
                                    ),
                                    _react2.default.createElement(
                                        'p',
                                        null,
                                        kompetisi.data[Filter].data[0].sort
                                    ),
                                    _react2.default.createElement('progress', { value: (0, _CompetitionListCard.setProgressBar)(kompetisi.data[Filter].data[0].deadline_at), max: 100 }),
                                    _react2.default.createElement(
                                        'div',
                                        { className: 'meta' },
                                        _react2.default.createElement(
                                            'div',
                                            { className: 'text-1' },
                                            _react2.default.createElement(
                                                'div',
                                                { className: 'count' },
                                                kompetisi.data[Filter].data[0].total_hadiah
                                            ),
                                            _react2.default.createElement(
                                                'div',
                                                { className: 'text-muted' },
                                                'total hadiah'
                                            )
                                        ),
                                        _react2.default.createElement(
                                            'div',
                                            { className: 'text-2' },
                                            _react2.default.createElement(
                                                'div',
                                                { className: 'count' },
                                                kompetisi.data[Filter].data[0].sisadeadline
                                            ),
                                            _react2.default.createElement(
                                                'div',
                                                { className: 'text-muted' },
                                                'deadline'
                                            )
                                        ),
                                        _react2.default.createElement(
                                            'div',
                                            { className: 'text-2' },
                                            _react2.default.createElement(
                                                'div',
                                                { className: 'count' },
                                                kompetisi.data[Filter].data[0].sisapengumuman
                                            ),
                                            _react2.default.createElement(
                                                'div',
                                                { className: 'text-muted' },
                                                'kunjungan'
                                            )
                                        )
                                    )
                                )
                            )
                        ) : _react2.default.createElement(
                            'div',
                            { className: 'col-md-10' },
                            _react2.default.createElement('p', null)
                        ) : _react2.default.createElement(
                            'div',
                            { className: 'col-md-10' },
                            _react2.default.createElement(_DefaultLoader2.default, null)
                        ),
                        _react2.default.createElement(
                            'div',
                            { className: 'col-md-2' },
                            _react2.default.createElement(
                                'div',
                                { className: 'home-categories-list' },
                                _react2.default.createElement(
                                    'ul',
                                    null,
                                    categories.data.map(function (n, key) {
                                        return _react2.default.createElement(
                                            'li',
                                            {
                                                key: key,
                                                className: active === key ? 'active' : '',
                                                onClick: function onClick() {
                                                    return _this2.setState({ active: key }, function () {
                                                        _this2.reqData();
                                                    });
                                                } },
                                            _react2.default.createElement(
                                                'a',
                                                { href: 'javascript:;' },
                                                n.main_kat
                                            )
                                        );
                                    })
                                )
                            )
                        )
                    )
                )
            );
        }
    }]);

    return CategoriesOnHome;
}(_react.Component);

exports.default = CategoriesOnHome;