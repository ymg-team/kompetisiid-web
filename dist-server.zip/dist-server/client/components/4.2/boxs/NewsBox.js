'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _NewsListCard = require('../cards/NewsListCard');

var _NewsListCard2 = _interopRequireDefault(_NewsListCard);

var _NewsLoader = require('../loaders/NewsLoader');

var _NewsLoader2 = _interopRequireDefault(_NewsLoader);

var _Transition = require('react-transition-group/Transition');

var _Transition2 = _interopRequireDefault(_Transition);

var _Transtition = require('../../Transtition');

var _reactRouter = require('react-router');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var NewsBox = function (_Component) {
    _inherits(NewsBox, _Component);

    function NewsBox() {
        _classCallCheck(this, NewsBox);

        return _possibleConstructorReturn(this, (NewsBox.__proto__ || Object.getPrototypeOf(NewsBox)).apply(this, arguments));
    }

    _createClass(NewsBox, [{
        key: 'generateList',
        value: function generateList(n) {
            return n.map(function (n, key) {
                return _react2.default.createElement(_NewsListCard2.default, { key: key, n: n });
            });
        }
    }, {
        key: 'render',
        value: function render() {
            var _this2 = this;

            var _props = this.props,
                data = _props.data,
                meta = _props.meta,
                is_loading = _props.is_loading;

            return _react2.default.createElement(
                'div',
                { id: 'news-container' },
                _react2.default.createElement(
                    'div',
                    { className: 'container' },
                    _react2.default.createElement(
                        'div',
                        { className: 'row no-margin' },
                        this.props.subtitle && meta && meta.code == 200 ? _react2.default.createElement(
                            'span',
                            { style: { display: 'table' } },
                            _react2.default.createElement('br', null),
                            'menampilkan\xA0',
                            _react2.default.createElement(
                                'strong',
                                null,
                                ' ',
                                data.length,
                                '\xA0'
                            ),
                            'dari\xA0',
                            _react2.default.createElement(
                                'strong',
                                null,
                                'beberapa\xA0'
                            ),
                            'berita',
                            _react2.default.createElement('br', null)
                        ) : null
                    ),
                    _react2.default.createElement('div', { className: 'row m-10' }),
                    _react2.default.createElement(
                        'div',
                        { className: 'row' },
                        _react2.default.createElement(
                            _Transition2.default,
                            { 'in': data && data.length > 0, timeout: _Transtition.duration },
                            function (state) {
                                return _react2.default.createElement(
                                    'div',
                                    { style: Object.assign({}, _Transtition.style.fade.default, _Transtition.style.fade[state]) },
                                    meta && meta.code ? !data ? _react2.default.createElement(
                                        'p',
                                        { className: 'text-muted' },
                                        meta.message
                                    ) : _this2.generateList(data) : null
                                );
                            }
                        )
                    ),
                    is_loading || !meta ? _react2.default.createElement(_NewsLoader2.default, null) : null,
                    _react2.default.createElement('div', { className: 'row m-10' })
                )
            );
        }
    }]);

    return NewsBox;
}(_react.Component);

exports.default = NewsBox;


NewsBox.defaultProps = {
    subtitle: true
};