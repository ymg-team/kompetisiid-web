'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _CompetitionListCard = require('../../../components/4.2/cards/CompetitionListCard');

var _CompetitionListCard2 = _interopRequireDefault(_CompetitionListCard);

var _CompetitionLoader = require('../loaders/CompetitionLoader');

var _CompetitionLoader2 = _interopRequireDefault(_CompetitionLoader);

var _Transition = require('react-transition-group/Transition');

var _Transition2 = _interopRequireDefault(_Transition);

var _Transtition = require('../../Transtition');

var _reactRouter = require('react-router');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function generateList(size, n) {
    return n.map(function (n, key) {
        return _react2.default.createElement(_CompetitionListCard2.default, { size: size, key: key, n: n });
    });
}

var CompetitionBox = function CompetitionBox(props) {
    var data = props.data,
        meta = props.meta,
        is_loading = props.is_loading,
        subtitle = props.subtitle,
        size = props.size;

    if (typeof subtitle == 'undefined') subtitle = true;
    if (typeof size == 'undefined') size = 'large';

    return _react2.default.createElement(
        'div',
        { id: 'competition-container' },
        _react2.default.createElement(
            'div',
            { className: 'container' },
            _react2.default.createElement(
                'div',
                { className: 'row no-margin' },
                meta && meta.code == 200 && subtitle ? _react2.default.createElement(
                    'span',
                    { style: { display: 'table' } },
                    _react2.default.createElement('br', null),
                    'menampilkan ',
                    _react2.default.createElement(
                        'strong',
                        null,
                        ' ',
                        data.length,
                        '\xA0'
                    ),
                    'dari\xA0',
                    _react2.default.createElement(
                        'strong',
                        null,
                        'beberapa\xA0'
                    ),
                    'kompetisi',
                    _react2.default.createElement('br', null)
                ) : null,
                subtitle ? _react2.default.createElement('div', { className: 'row m-10' }) : null,
                _react2.default.createElement(
                    _Transition2.default,
                    { 'in': data && data.length > 0, timeout: _Transtition.duration },
                    function (state) {
                        return _react2.default.createElement(
                            'div',
                            { className: 'row', style: Object.assign({}, _Transtition.style.fade.default, _Transtition.style.fade[state]) },
                            meta && meta.code ? !data ? _react2.default.createElement(
                                'p',
                                { className: 'text-muted' },
                                meta.message
                            ) : generateList(size, data) : null
                        );
                    }
                ),
                is_loading || !meta ? _react2.default.createElement(_CompetitionLoader2.default, { size: props.size, total: props.total }) : null,
                _react2.default.createElement('div', { className: 'row m-10' })
            )
        )
    );
};

exports.default = CompetitionBox;