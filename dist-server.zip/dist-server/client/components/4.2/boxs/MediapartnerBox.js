'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactRouter = require('react-router');

var _stringManager = require('string-manager');

var _DefaultLoader = require('../loaders/DefaultLoader');

var _DefaultLoader2 = _interopRequireDefault(_DefaultLoader);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var MediapartnerBox = function (_Component) {
  _inherits(MediapartnerBox, _Component);

  function MediapartnerBox() {
    _classCallCheck(this, MediapartnerBox);

    return _possibleConstructorReturn(this, (MediapartnerBox.__proto__ || Object.getPrototypeOf(MediapartnerBox)).apply(this, arguments));
  }

  _createClass(MediapartnerBox, [{
    key: 'generateList',
    value: function generateList() {
      var data = this.props.data;

      return data.map(function (n, key) {
        return _react2.default.createElement(
          'div',
          { key: key, className: 'row' },
          _react2.default.createElement(
            'div',
            { className: 'col-md-12' },
            _react2.default.createElement(
              'div',
              { className: 'card-mediapartner' },
              _react2.default.createElement(
                'div',
                { className: 'thumbnails' },
                _react2.default.createElement('img', { src: n.poster.small })
              ),
              _react2.default.createElement(
                'div',
                { className: 'details' },
                _react2.default.createElement(
                  'span',
                  { className: 'categories' },
                  _react2.default.createElement(
                    'a',
                    { className: 'muted', href: '#' },
                    n.mainkategori
                  ),
                  ',\xA0',
                  _react2.default.createElement(
                    'a',
                    { className: 'muted', href: '#' },
                    n.subkategori
                  )
                ),
                _react2.default.createElement(
                  _reactRouter.Link,
                  { to: '/competition/' + n.id_kompetisi + '/regulations/' + n.nospace_title },
                  _react2.default.createElement(
                    'h3',
                    null,
                    n.title
                  )
                ),
                _react2.default.createElement(
                  'small',
                  null,
                  'Dipasang ',
                  _react2.default.createElement(
                    _reactRouter.Link,
                    { href: '/' + n.author.username },
                    n.author.username
                  )
                ),
                _react2.default.createElement('br', null),
                _react2.default.createElement(
                  'span',
                  null,
                  (0, _stringManager.truncate)(n.sort, 300, '...')
                )
              )
            )
          )
        );
      });
    }
  }, {
    key: 'render',
    value: function render() {
      var meta = this.props.meta;

      return _react2.default.createElement(
        'div',
        null,
        _react2.default.createElement(
          'div',
          { className: 'col-md-12' },
          _react2.default.createElement(
            'div',
            { className: 'col-md-8 col-md-push-2 col-lg-6 col-lg-push-3' },
            _react2.default.createElement(
              'div',
              { className: 'row' },
              _react2.default.createElement(
                'div',
                { className: 'media-partner' },
                _react2.default.createElement(
                  'h2',
                  { className: 'big-text' },
                  'Media Partner KI'
                ),
                _react2.default.createElement(
                  'span',
                  null,
                  'KI juga ikut berperan sebagai media partner berbagai kompetisi di Indonesia. '
                )
              )
            ),
            meta ? meta.code == 200 ? this.generateList() : _react2.default.createElement(
              'p',
              { className: 'text-muted' },
              meta.message
            ) : _react2.default.createElement(_DefaultLoader2.default, null)
          )
        ),
        _react2.default.createElement(
          'div',
          { className: 'col-md-12' },
          _react2.default.createElement(
            'div',
            { className: 'col-md-8 col-md-push-2 col-lg-6 col-lg-push-3' },
            _react2.default.createElement(
              _reactRouter.Link,
              { className: 'btn btn-black btn-fullwidth', style: { marginBottom: 40 }, to: '/browse?mediapartner=1' },
              _react2.default.createElement(
                'strong',
                null,
                'Selengkapnya'
              )
            )
          )
        )
      );
    }
  }]);

  return MediapartnerBox;
}(_react.Component);

exports.default = MediapartnerBox;