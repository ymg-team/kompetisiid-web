'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactRouter = require('react-router');

var _LinkGenerator = require('../../../helpers/LinkGenerator');

var _DomEvents = require('../../../helpers/DomEvents');

var _copyToClipboard = require('copy-to-clipboard');

var _copyToClipboard2 = _interopRequireDefault(_copyToClipboard);

var _BtnJoin = require('../buttons/BtnJoin');

var _BtnJoin2 = _interopRequireDefault(_BtnJoin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var CompetitionDetailBox = function CompetitionDetailBox(props) {
    var data = props.data;

    var link_competition = 'https://kompetisi.id/competition/' + data.id_kompetisi + '/regulations/' + data.nospace_title;
    return _react2.default.createElement(
        'div',
        { id: 'competition-detail', className: 'row no-margin p-50-0' },
        _react2.default.createElement(
            'div',
            { className: 'col-md-12' },
            _react2.default.createElement(
                'div',
                { className: 'container' },
                _react2.default.createElement(
                    'div',
                    { className: 'competition-author' },
                    _react2.default.createElement(
                        _reactRouter.Link,
                        { to: '/' + data.author.username, title: 'ke profil ' + data.author.username },
                        _react2.default.createElement('img', { style: { float: 'left', marginRight: '10px' }, src: '/assets/4.2/img/default-avatar.jpg' })
                    ),
                    _react2.default.createElement(
                        'p',
                        null,
                        'dipasang oleh ',
                        _react2.default.createElement(
                            _reactRouter.Link,
                            { className: 'text-muted', to: '/' + data.author.username },
                            data.author.username
                        ),
                        _react2.default.createElement('br', null),
                        _react2.default.createElement(
                            'small',
                            { className: 'text-muted' },
                            data.created_in,
                            ' di',
                            ' ',
                            _react2.default.createElement(
                                'a',
                                { className: 'text-muted', href: '/browse/' + data.mainkategori },
                                _react2.default.createElement(
                                    'strong',
                                    null,
                                    '' + data.mainkategori
                                )
                            ),
                            ',',
                            _react2.default.createElement(
                                'a',
                                { className: 'text-muted', href: '/browse/' + data.subkategori },
                                _react2.default.createElement(
                                    'strong',
                                    null,
                                    '' + data.subkategori
                                )
                            )
                        )
                    )
                ),
                _react2.default.createElement('div', { className: 'row m-20' }),
                _react2.default.createElement(
                    'div',
                    { className: 'row competition-detail--meta' },
                    _react2.default.createElement(
                        'div',
                        { className: 'col-md-6 align-center poster' },
                        _react2.default.createElement('img', { alt: data.title, className: 'poster', src: data.poster.original })
                    ),
                    _react2.default.createElement(
                        'div',
                        { className: 'col-md-6 count' },
                        _react2.default.createElement('div', { className: 'only-mobile m-30' }),
                        _react2.default.createElement(
                            'div',
                            { style: { marginBottom: '20px' } },
                            data.sisadeadline == 'berakhir' && data.sisapengumuman == 'berakhir' ? _react2.default.createElement(
                                'span',
                                { className: 'label label-red label-lg' },
                                _react2.default.createElement('i', { className: 'fa fa-check' }),
                                ' Kompetisi telah berakhir'
                            ) : data.sisadeadline == 'berakhir' && data.sisapengumuman != 'berakhir' ? _react2.default.createElement(
                                'span',
                                { title: 'Pengumuan pemenang dalam ' + data.sisapengumuman, className: 'label label-orange label-lg' },
                                _react2.default.createElement('i', { className: 'fa fa-flag' }),
                                ' Kompetisi sedang berlangsung'
                            ) : _react2.default.createElement(
                                'span',
                                { className: 'label label-gray label-lg' },
                                _react2.default.createElement('i', { className: 'fa fa-wpforms' }),
                                ' Batas pendaftaran ',
                                data.sisadeadline
                            )
                        ),
                        _react2.default.createElement(
                            'div',
                            { className: 'competition-detail--title' },
                            _react2.default.createElement(
                                'h1',
                                null,
                                data.title
                            ),
                            _react2.default.createElement('div', { className: 'm-20' }),
                            _react2.default.createElement(
                                'p',
                                { className: 'text-muted' },
                                'Diselenggarakan oleh ',
                                _react2.default.createElement(
                                    'strong',
                                    null,
                                    data.penyelenggara
                                )
                            ),
                            _react2.default.createElement('div', { className: 'm-20' }),
                            _react2.default.createElement(
                                'p',
                                { className: 'text-muted' },
                                data.sort
                            )
                        ),
                        _react2.default.createElement('div', { className: 'm-30' }),
                        _react2.default.createElement(_BtnJoin2.default, { data: data }),
                        _react2.default.createElement(
                            'a',
                            { style: { marginRight: '10px' }, onClick: function onClick() {
                                    return fullalert('warning', 'login terlebih dahulu untuk menyimpan');
                                }, className: 'btn btn-white', href: 'javascript:;', title: 'simpan ke akun' },
                            _react2.default.createElement('i', { className: 'fa fa-save' })
                        ),
                        _react2.default.createElement(
                            'a',
                            { style: { marginRight: '10px' }, onClick: function onClick() {
                                    modal('open', 'save-to-calendar');
                                }, className: 'btn btn-white', href: 'javascript:;', title: 'simpan ke kalender' },
                            _react2.default.createElement('i', { className: 'fa fa-calendar' })
                        ),
                        _react2.default.createElement(
                            'div',
                            { className: 'dropdown' },
                            _react2.default.createElement('a', { className: 'fa fa-ellipsis-v btn btn-gray dropdown-button', 'data-target': 'action-competition' }),
                            _react2.default.createElement(
                                'div',
                                { className: 'dropdown-items', id: 'action-competition' },
                                _react2.default.createElement(
                                    'ul',
                                    null,
                                    _react2.default.createElement(
                                        'li',
                                        null,
                                        _react2.default.createElement(
                                            'a',
                                            { className: 'scopy-button', onClick: function onClick() {
                                                    return handleCopyLink(link_competition);
                                                }, target: '_blank', href: 'javascript:;' },
                                            'Copy Link'
                                        )
                                    ),
                                    _react2.default.createElement(
                                        'li',
                                        null,
                                        _react2.default.createElement(
                                            'a',
                                            { target: '_blank', href: 'https://docs.google.com/forms/d/e/1FAIpQLSdmsHkJdGctVkWYFhhLC10YYVbtNIi5IF8X0mbdd2DjS-N1eQ/viewform?entry.559533126=' + link_competition },
                                            'Laporkan Kompetisi'
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            )
        ),
        _react2.default.createElement(
            'div',
            { className: 'modal', id: 'save-to-calendar' },
            _react2.default.createElement(
                'div',
                { className: 'container' },
                _react2.default.createElement(
                    'h2',
                    { className: 'modal-title' },
                    'Simpan ke kalender'
                ),
                _react2.default.createElement('a', { className: 'btn btn-white btn-close-modal btn-sm fa fa-close', href: 'javascript:;' }),
                _react2.default.createElement('hr', null),
                _react2.default.createElement(
                    'a',
                    { target: '_blank', href: addCalendar.google(data) },
                    _react2.default.createElement('img', { style: { 'width': 'inherit' }, src: '/assets/4.2/img/google-calendar-icon.fullwidth.png' })
                ),
                _react2.default.createElement(
                    'a',
                    { target: '_blank', href: addCalendar.yahoo(data) },
                    _react2.default.createElement('img', { style: { 'width': 'inherit' }, src: '/assets/4.2/img/yahoo-calendar-icon.fullwidth.png' })
                ),
                _react2.default.createElement(
                    'a',
                    { onClick: function onClick() {
                            return fullalert('warning', 'untuk sekarang, kalender Microsoft untuk saat ini belum tersedia');
                        }, href: 'javascript:;' },
                    _react2.default.createElement('img', { style: { 'width': 'inherit' }, src: '/assets/4.2/img/microsoft-calendar-icon.fullwidth.png' })
                )
            )
        )
    );
};

var addCalendar = {
    google: function google(n, url) {
        var d = n.deadline_at.split(' ');
        return 'https://calendar.google.com/calendar/render?action=TEMPLATE&text=deadline ' + n.title + '&dates=' + d[0].replace(/-/g, '') + 'T000000Z/' + d[0].replace(/-/g, '') + 'T240000Z&details=' + (n.sort + '\n' + n.hadiah) + '&location=http://kompetisi.id/competition/' + n.id_kompetisi + '/regulations/' + n.nospace_title + '&sf=true&output=xml#eventpage_6';
    },
    yahoo: function yahoo(n, url) {
        var d = n.deadline_at.split(' ');
        return 'https://calendar.yahoo.com/?v=60&view=d&type=20&title=deadline ' + n.title + '&st=' + d[0].replace(/-/g, '') + 'T000000Z&dur=0600&desc=' + (n.sort + '\n' + n.hadiah) + '&in_loc=http://kompetisi.id/competition/' + n.id_kompetisi + '/regulations/' + n.nospace_title;
    },
    microsoft: function microsoft() {}
};

// function to handle copy link
function handleCopyLink(link) {
    // trigger to click body
    (0, _DomEvents.eventFire)(document.getElementsByTagName('body')[0], 'click');
    // copy
    (0, _copyToClipboard2.default)(link);
    // alert if link has copied
    fullalert('success', 'Link telah berhasil di copy.');
}

exports.default = CompetitionDetailBox;