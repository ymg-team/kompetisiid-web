'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactRouter = require('react-router');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var Footer = function Footer() {
    return _react2.default.createElement(
        'span',
        null,
        _react2.default.createElement(
            'div',
            { className: 'col-md-12 footer' },
            _react2.default.createElement(
                'footer',
                null,
                _react2.default.createElement(
                    'div',
                    { className: 'container' },
                    _react2.default.createElement(
                        'div',
                        { className: 'row' },
                        _react2.default.createElement(
                            'div',
                            { className: 'col-md-6' },
                            _react2.default.createElement(
                                'p',
                                null,
                                _react2.default.createElement(
                                    'strong',
                                    { className: 'title' },
                                    'Tentang Kami'
                                )
                            ),
                            'Kami adalah sebuah platform kompetisi untuk berbagai macam kompetisi yang diadakan di Indonesia untuk selanjutnya dipanggil \'KI\'. Dipersembahkan oleh ID More. Penyelenggara dapat menggunakan KI sebagai media publikasi, media partner ataupun kerja sama untuk kompetisi yang mereka adakan. Peserta dapat menjelajahi dan mengikuti berbagai kategori kompetisi di KI dan semoga menjadi pemenang.'
                        ),
                        _react2.default.createElement(
                            'div',
                            { className: 'col-md-3' },
                            _react2.default.createElement(
                                'p',
                                null,
                                ' ',
                                _react2.default.createElement(
                                    'strong',
                                    { className: 'title' },
                                    'Lebih Lengkap'
                                )
                            ),
                            _react2.default.createElement(
                                'ul',
                                { className: 'vertical-menu' },
                                _react2.default.createElement(
                                    'li',
                                    null,
                                    _react2.default.createElement(
                                        _reactRouter.Link,
                                        { to: '/news/TXpVPQ/About' },
                                        'Apa itu KompetisiIndonesia'
                                    )
                                ),
                                _react2.default.createElement(
                                    'li',
                                    null,
                                    _react2.default.createElement(
                                        _reactRouter.Link,
                                        { to: '/news' },
                                        'Berita terbaru'
                                    )
                                ),
                                _react2.default.createElement(
                                    'li',
                                    null,
                                    _react2.default.createElement(
                                        'a',
                                        { target: '_blank', href: 'https://goo.gl/forms/kMGGZQXJCjoyKThj1' },
                                        'Hubungi kami'
                                    )
                                ),
                                _react2.default.createElement(
                                    'li',
                                    null,
                                    _react2.default.createElement(
                                        _reactRouter.Link,
                                        { to: '/careers' },
                                        'Karir'
                                    )
                                )
                            ),
                            _react2.default.createElement('p', null)
                        ),
                        _react2.default.createElement(
                            'div',
                            { className: 'col-md-3' },
                            _react2.default.createElement(
                                'p',
                                null,
                                ' ',
                                _react2.default.createElement(
                                    'strong',
                                    { className: 'title' },
                                    'Navigasi'
                                )
                            ),
                            _react2.default.createElement(
                                'ul',
                                { className: 'vertical-menu' },
                                _react2.default.createElement(
                                    'li',
                                    null,
                                    _react2.default.createElement(
                                        _reactRouter.Link,
                                        { to: '/add' },
                                        'Pasang kompetisi'
                                    )
                                ),
                                _react2.default.createElement(
                                    'li',
                                    null,
                                    _react2.default.createElement(
                                        _reactRouter.Link,
                                        { to: '/news' },
                                        'Berita'
                                    )
                                ),
                                _react2.default.createElement(
                                    'li',
                                    null,
                                    _react2.default.createElement(
                                        _reactRouter.Link,
                                        { to: '/browse' },
                                        'Jelajah kompetisi'
                                    )
                                ),
                                _react2.default.createElement(
                                    'li',
                                    null,
                                    _react2.default.createElement(
                                        _reactRouter.Link,
                                        { to: '/categories' },
                                        'Kategori'
                                    )
                                ),
                                _react2.default.createElement(
                                    'li',
                                    null,
                                    _react2.default.createElement(
                                        _reactRouter.Link,
                                        { to: '/login' },
                                        'Login / register'
                                    )
                                )
                            ),
                            _react2.default.createElement('p', null)
                        )
                    ),
                    _react2.default.createElement('hr', { style: { borderTop: '1px solid #656565' } }),
                    _react2.default.createElement(
                        'div',
                        { className: 'row vertical-center' },
                        _react2.default.createElement(
                            'div',
                            { className: 'col-md-6 footer-copyright' },
                            _react2.default.createElement('img', { className: 'footer-copyright-logo', src: '/assets/4.2/img/icon-128x128.png', title: 'kompetisi indonesia icon' }),
                            _react2.default.createElement(
                                'small',
                                { className: 'footer-copyright-text' },
                                '\xA9 2017 - now by Kompetisi Indonesia',
                                _react2.default.createElement('br', null),
                                'DIY, Indonesia'
                            )
                        ),
                        _react2.default.createElement(
                            'div',
                            { className: 'col-md-6' },
                            _react2.default.createElement(
                                'ul',
                                { className: 'horizontal-menu pull-right social-media' },
                                _react2.default.createElement(
                                    'li',
                                    null,
                                    _react2.default.createElement(
                                        'a',
                                        { href: 'https://facebook.com/kompetisiid', target: '_blank' },
                                        _react2.default.createElement('i', { className: 'fa fa-facebook' })
                                    )
                                ),
                                _react2.default.createElement(
                                    'li',
                                    null,
                                    _react2.default.createElement(
                                        'a',
                                        { href: 'https://twitter.com/_kompetisiid', target: '_blank' },
                                        _react2.default.createElement('i', { className: 'fa fa-twitter' })
                                    )
                                ),
                                _react2.default.createElement(
                                    'li',
                                    null,
                                    _react2.default.createElement(
                                        'a',
                                        { href: 'https://instagram.com/kompetisiid', target: '_blank' },
                                        _react2.default.createElement('i', { className: 'fa fa-instagram' })
                                    )
                                ),
                                _react2.default.createElement(
                                    'li',
                                    null,
                                    _react2.default.createElement(
                                        'a',
                                        { href: '/feed', target: '_blank' },
                                        _react2.default.createElement('i', { className: 'fa fa-rss' })
                                    )
                                )
                            )
                        )
                    )
                )
            )
        ),
        _react2.default.createElement(
            'div',
            { className: 'col-md-12 poweredby' },
            _react2.default.createElement(
                'div',
                { className: 'container' },
                _react2.default.createElement(
                    'div',
                    { className: 'row' },
                    _react2.default.createElement(
                        'div',
                        { className: 'col-md-12' },
                        'Powered by ',
                        _react2.default.createElement(
                            'a',
                            { href: 'https://byidmore.com', target: '_blank' },
                            _react2.default.createElement('img', { src: '/assets/4.2/img/icon-byidmore.png', title: 'idmore icon' })
                        )
                    )
                )
            )
        )
    );
};

exports.default = Footer;