'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactRouter = require('react-router');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var NewsListCard = function NewsListCard(props) {
    var n = props.n;

    var target = '/news/' + n.id + '/' + n.nospace_title;
    console.log(n.image);
    return _react2.default.createElement(
        'div',
        { className: 'col-md-4' },
        _react2.default.createElement(
            'div',
            { className: 'card-competition no-border' },
            _react2.default.createElement(
                _reactRouter.Link,
                { to: target },
                _react2.default.createElement(
                    'div',
                    { className: 'card-competition--poster' },
                    _react2.default.createElement('img', { src: n.image ? n.image.small : '/assets/4.2/img/slider/slider-2.png' })
                )
            ),
            _react2.default.createElement(
                'div',
                { className: 'card-competition--inside' },
                _react2.default.createElement(
                    _reactRouter.Link,
                    { to: target },
                    _react2.default.createElement(
                        'h3',
                        null,
                        n.title
                    ),
                    _react2.default.createElement(
                        'small',
                        { className: 'text-muted' },
                        n.created_at
                    )
                ),
                _react2.default.createElement('br', null),
                _react2.default.createElement(
                    'small',
                    null,
                    'diposting oleh',
                    ' ',
                    _react2.default.createElement(
                        _reactRouter.Link,
                        { to: '/' + n.username },
                        n.username
                    )
                ),
                _react2.default.createElement('br', null),
                _react2.default.createElement(
                    'a',
                    { className: 'muted', href: '#' },
                    _react2.default.createElement('img', { className: 'avatar', src: '/assets/4.2/img/default-avatar.jpg' })
                )
            )
        )
    );
};

exports.default = NewsListCard;