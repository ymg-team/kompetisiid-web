'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactRouter = require('react-router');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var NewsAuthorCard = function NewsAuthorCard(props) {
    return _react2.default.createElement(
        'div',
        { className: 'author' },
        _react2.default.createElement(
            _reactRouter.Link,
            { to: '/' + props.data.username },
            _react2.default.createElement('img', { className: 'avatar', src: '/assets/4.2/img/default-avatar.jpg' }),
            'diposting oleh ',
            _react2.default.createElement(
                'strong',
                null,
                props.data.username
            )
        ),
        _react2.default.createElement('br', null),
        _react2.default.createElement(
            'span',
            { className: 'text-muted' },
            props.data.moto
        )
    );
};

exports.default = NewsAuthorCard;