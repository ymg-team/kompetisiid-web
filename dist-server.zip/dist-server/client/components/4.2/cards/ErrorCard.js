'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactRouter = require('react-router');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function (props) {
  return _react2.default.createElement(
    'div',
    { className: 'fullheight' },
    _react2.default.createElement(
      'div',
      { className: 'container error' },
      _react2.default.createElement(
        'div',
        { className: 'col-md-4 col-md-push-4 col-sm-12' },
        _react2.default.createElement(
          'h1',
          null,
          props.code || 500
        ),
        _react2.default.createElement(
          'h2',
          null,
          props.message || 'Telah Terjadi Masalah'
        ),
        _react2.default.createElement(
          'p',
          null,
          'Jika anda tersesat, silahkan masuk ke ',
          _react2.default.createElement(
            _reactRouter.Link,
            { to: '/browse' },
            'Jelajah Kompetisi'
          ),
          'untuk menemukan kompetisi lainnya atau kembali ke ',
          _react2.default.createElement(
            _reactRouter.Link,
            { to: '/' },
            'Halaman Utama'
          )
        )
      )
    )
  );
};