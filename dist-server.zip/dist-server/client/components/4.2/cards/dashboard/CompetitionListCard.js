'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactRouter = require('react-router');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var CompetitionListCard = function (_Component) {
    _inherits(CompetitionListCard, _Component);

    function CompetitionListCard() {
        _classCallCheck(this, CompetitionListCard);

        return _possibleConstructorReturn(this, (CompetitionListCard.__proto__ || Object.getPrototypeOf(CompetitionListCard)).apply(this, arguments));
    }

    _createClass(CompetitionListCard, [{
        key: 'handleDelete',
        value: function handleDelete(id) {}
    }, {
        key: 'render',
        value: function render() {
            var _this2 = this;

            var n = this.props.n;

            return _react2.default.createElement(
                'div',
                { className: 'competition-items' },
                _react2.default.createElement(
                    'div',
                    { className: 'item' },
                    _react2.default.createElement(
                        'div',
                        { className: 'item__left' },
                        _react2.default.createElement(
                            'h4',
                            null,
                            _react2.default.createElement(
                                _reactRouter.Link,
                                { to: '/dashboard/competition/' + n.id_kompetisi },
                                n.title
                            )
                        ),
                        _react2.default.createElement(
                            'p',
                            { className: 'text-muted', style: { margin: 0 } },
                            _react2.default.createElement(
                                'span',
                                { title: n.created_at },
                                'dipost ',
                                n.created_in
                            ),
                            ' ',
                            'oleh ',
                            _react2.default.createElement(
                                _reactRouter.Link,
                                { title: n.username, to: '/dashboard/user/' + n.username },
                                n.username
                            ),
                            _react2.default.createElement('br', null),
                            'di',
                            ' ',
                            _react2.default.createElement(
                                'a',
                                { href: '/browse/' + n.mainkategori, target: '_blank' },
                                n.mainkategori
                            ),
                            '-',
                            _react2.default.createElement(
                                'a',
                                { href: '/browse/' + n.mainkategori + '/' + n.subkategori, target: '_blank' },
                                n.subkategori
                            )
                        ),
                        n.is_garansi ? _react2.default.createElement(
                            'span',
                            { className: 'label label-blue' },
                            'garansi'
                        ) : null,
                        n.is_mediapartner ? _react2.default.createElement(
                            'span',
                            { className: 'label label-green' },
                            'media partner '
                        ) : null,
                        n.is_support ? _react2.default.createElement(
                            'span',
                            { className: 'label label-green' },
                            'support '
                        ) : null,
                        _react2.default.createElement(
                            'span',
                            { className: 'label label-red' },
                            n.is_berakhir ? n.sisapengumuman != 'berakhir' ? 'pengumuman ' + n.sisapengumuman : 'berakhir' : 'deadline ' + n.sisadeadline
                        )
                    ),
                    _react2.default.createElement(
                        'div',
                        { className: 'item__right' },
                        _react2.default.createElement(
                            'div',
                            { className: 'item__right-item' },
                            _react2.default.createElement(
                                'h4',
                                { className: 'text-muted', style: { color: n.contenttext.split(' ').length < 300 ? '#cf3030' : 'inherit' }, title: 'total kata dalam deskripsi' },
                                _react2.default.createElement(
                                    'i',
                                    { className: 'fa fa-file-text-o' },
                                    n.contenttext.split(' ').length
                                )
                            )
                        ),
                        ' ',
                        _react2.default.createElement(
                            'div',
                            { className: 'item__right-item' },
                            _react2.default.createElement(
                                'h4',
                                { className: 'text-muted', title: 'total views' },
                                _react2.default.createElement(
                                    'i',
                                    { className: 'fa fa-eye' },
                                    n.views
                                )
                            )
                        ),
                        _react2.default.createElement(
                            'div',
                            { className: 'item__right-item' },
                            _react2.default.createElement(
                                'div',
                                { className: 'dropdown' },
                                _react2.default.createElement(
                                    'a',
                                    { className: 'btn btn-sm dropdown-button text-muted', title: 'options', href: 'javascript:;', 'data-target': 'menu-2' },
                                    _react2.default.createElement('i', { className: 'fa fa-ellipsis-v' })
                                ),
                                _react2.default.createElement(
                                    'div',
                                    { className: 'dropdown-items', id: 'menu-2' },
                                    _react2.default.createElement(
                                        'ul',
                                        null,
                                        _react2.default.createElement(
                                            'li',
                                            null,
                                            _react2.default.createElement(
                                                'a',
                                                { target: '_blank', href: '/competition/' + n.id_kompetisi + '/regulations/' + n.nospace_title },
                                                'Preview'
                                            )
                                        ),
                                        _react2.default.createElement(
                                            'li',
                                            null,
                                            _react2.default.createElement(
                                                _reactRouter.Link,
                                                { to: '/dashboard/competition/' + n.id_kompetisi },
                                                'Ubah'
                                            )
                                        ),
                                        _react2.default.createElement(
                                            'li',
                                            null,
                                            _react2.default.createElement(
                                                'a',
                                                { onClick: function onClick() {
                                                        return _this2.handleDelete(n.id);
                                                    }, href: 'javascript:;' },
                                                'Hapus'
                                            )
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            );
        }
    }]);

    return CompetitionListCard;
}(_react.Component);

exports.default = CompetitionListCard;