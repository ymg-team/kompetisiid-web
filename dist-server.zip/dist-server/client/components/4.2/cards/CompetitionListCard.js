'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.setProgressBar = setProgressBar;

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactRouter = require('react-router');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var LabelEnd = function LabelEnd() {
  return _react2.default.createElement(
    'div',
    { style: { 'position': 'absolute', 'background': '#e64b3b', 'top': '85px', 'margin': '0 auto', 'padding': '10px', 'color': '#FFF', 'opacity': '1', 'left': '-25%', 'marginLeft': '50%', 'fontWeight': 'bold', 'textTransform': 'uppercase', 'letterSpacing': '1.1px', zIndex: 1 } },
    'kompetisi berakhir'
  );
};

var CompetitionListCard = function CompetitionListCard(props) {
  var n = props.n,
      size = props.size;

  var target = '/competition/' + n.id_kompetisi + '/regulations/' + n.nospace_title;
  var is_berakhir = n.sisadeadline == 'berakhir' && n.sisapengumuman == 'berakhir';
  return _react2.default.createElement(
    'div',
    { className: size === 'large' ? 'col-md-4' : 'col-md-3' },
    is_berakhir ? _react2.default.createElement(LabelEnd, null) : null,
    _react2.default.createElement(
      'div',
      { style: { opacity: is_berakhir ? 0.5 : 1 }, className: 'card-competition' },
      _react2.default.createElement(
        _reactRouter.Link,
        { to: target },
        _react2.default.createElement(
          'div',
          { className: 'card-competition--poster' },
          _react2.default.createElement('img', { src: n.poster.small, alt: n.title })
        )
      ),
      _react2.default.createElement(
        'div',
        { className: 'card-competition--inside' },
        _react2.default.createElement(
          'div',
          { className: 'categories' },
          _react2.default.createElement(
            _reactRouter.Link,
            { className: 'muted', to: '/browse/' + n.mainkategori },
            n.mainkategori
          ),
          ',\xA0',
          _react2.default.createElement(
            _reactRouter.Link,
            { className: 'muted', to: '/browse/' + n.mainkategori + '/' + n.subkategori },
            n.subkategori
          )
        ),
        _react2.default.createElement(
          _reactRouter.Link,
          { to: target },
          _react2.default.createElement(
            'h3',
            null,
            n.title
          )
        ),
        _react2.default.createElement(
          'span',
          null,
          'dipasang'
        ),
        ' ',
        _react2.default.createElement(
          _reactRouter.Link,
          { className: 'muted', to: '/' + n.author.username },
          n.author.username
        ),
        _react2.default.createElement('progress', { value: setProgressBar(n.deadline_at), max: 100 }),
        _react2.default.createElement(
          'div',
          { className: 'types' },
          n.is_garansi ? _react2.default.createElement(
            'span',
            { title: 'kompetisi sudah diverifikasi keberadaannya oleh kru KI', className: 'label label-green' },
            'Garansi'
          ) : null,
          n.is_mediapartner ? _react2.default.createElement(
            'span',
            { title: 'KI berlaku sebagai media partner di kompetisi ini', className: 'label label-blue' },
            'Media Partner'
          ) : null,
          n.is_support ? _react2.default.createElement(
            'span',
            { title: 'kompetisi ini bisa diikuti melelui KI', className: 'label label-blue' },
            'Support'
          ) : null,
          is_berakhir ? _react2.default.createElement(
            'span',
            { title: 'kompetisi ini telah berakhir', className: 'label label-red' },
            'Berakhir'
          ) : null,
          n.sisadeadline == 'berakhir' && n.sisapengumuman != 'berakhir' ? _react2.default.createElement(
            'span',
            { title: 'kompetisi ini telah berakhir', className: 'label label-orange' },
            _react2.default.createElement('i', { className: 'fa fa-flag' }),
            ' ',
            'Sedang berlangsung'
          ) : null
        ),
        _react2.default.createElement(
          'div',
          { className: 'meta' },
          _react2.default.createElement(
            'p',
            null,
            _react2.default.createElement(
              'strong',
              null,
              n.total_hadiah
            ),
            _react2.default.createElement(
              'span',
              { className: 'text-muted' },
              '\xA0total hadiah'
            )
          ),
          n.sisadeadline == 'berakhir' && n.sisapengumuman == 'berakhir' ? _react2.default.createElement(
            'p',
            null,
            _react2.default.createElement(
              'strong',
              null,
              'Kompetisi telah berakhir'
            )
          ) : n.sisadeadline == 'berakhir' && n.sisapengumuman != 'berakhir' ? _react2.default.createElement(
            'p',
            null,
            _react2.default.createElement(
              'strong',
              null,
              n.sisapengumuman,
              ' lagi'
            ),
            ' ',
            _react2.default.createElement(
              'span',
              { className: 'text-muted' },
              'Pengumuman pemenang'
            )
          ) : _react2.default.createElement(
            'p',
            null,
            _react2.default.createElement(
              'strong',
              null,
              n.sisadeadline,
              ' lagi'
            ),
            ' ',
            _react2.default.createElement(
              'span',
              { className: 'text-muted' },
              'Deadline pendaftaran'
            )
          )
        )
      )
    )
  );
};

function setProgressBar(deadline) {
  var today = void 0,
      interval = void 0,
      progress = void 0;

  // set interval days
  today = new Date();
  deadline = new Date(deadline);
  interval = deadline.getTime() - today.getTime();
  interval = Math.ceil(interval / (1000 * 3600 * 24));

  //set progress precentage
  if (interval > 0 && interval <= 100) {
    progress = 100 - interval;
  } else if (interval > 100) {
    progress = 1;
  } else {
    progress = 100;
  }

  return progress;
}

exports.default = CompetitionListCard;