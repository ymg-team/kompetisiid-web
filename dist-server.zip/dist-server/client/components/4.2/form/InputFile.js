'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _Validator = require('./Validator');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var InputFile = function (_Component) {
    _inherits(InputFile, _Component);

    function InputFile() {
        _classCallCheck(this, InputFile);

        return _possibleConstructorReturn(this, (InputFile.__proto__ || Object.getPrototypeOf(InputFile)).apply(this, arguments));
    }

    _createClass(InputFile, [{
        key: 'handleChange',
        value: function handleChange(e) {
            var _this2 = this;

            var files = e.target.files;

            if (files[0]) {
                this.props.setState(_defineProperty({}, this.props.name, files[0]), function () {
                    _this2.validateInput();
                });
            }
        }
    }, {
        key: 'validateInput',
        value: function validateInput() {
            var result = (0, _Validator.validate)(this.props);
            this.props.setState(_defineProperty({}, this.props.name + '_validate', result));
        }
    }, {
        key: 'render',
        value: function render() {
            var _this3 = this;

            var _props = this.props,
                max = _props.max,
                label = _props.label,
                name = _props.name,
                validate = _props.validate;

            var is_valid = !(!validate.is_valid && validate.message);
            return _react2.default.createElement(
                'div',
                { className: 'form-child ' + (!is_valid ? 'error' : '') },
                _react2.default.createElement(
                    'label',
                    { htmlFor: name },
                    label
                ),
                _react2.default.createElement('input', {
                    name: name,
                    type: 'file',
                    id: name,
                    onChange: function onChange(e) {
                        return _this3.handleChange(e);
                    },
                    onBlur: function onBlur(e) {
                        return _this3.handleChange(e);
                    }
                }),
                _react2.default.createElement(
                    'small',
                    null,
                    'maks ',
                    max / 1000000,
                    'MB'
                ),
                !is_valid ? _react2.default.createElement(
                    'small',
                    null,
                    _react2.default.createElement('br', null),
                    validate.message
                ) : null
            );
        }
    }]);

    return InputFile;
}(_react.Component);

exports.default = InputFile;


InputFile.defaultProps = {
    type: 'file'
};