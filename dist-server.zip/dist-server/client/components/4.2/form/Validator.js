'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.validate = validate;
exports.validationChecker = validationChecker;
exports.validationSeter = validationSeter;
var validator = exports.validator = {};

function validate(props) {
    var name = props.name,
        max = props.max,
        value = props.value,
        required = props.required,
        type = props.type;

    if (required && !value) {
        return generateResult(props, false, 'wajib diisi');
    } else if (max && value.length > max) //handle max character
        {
            return generateResult(props, false, 'input melebihi batas maksimal karakter');
        } else if (type == 'number' && parseInt(value)) //handle input type number
        {
            return generateResult(props, false, 'inputan bukan angka');
        } else if (type == 'link' && !value.includes('http')) //handle input type link
        {
            return generateResult(props, false, 'harus link valid yang dilengkapi dengan, http:// atau https://');
        } else if (type == 'email' && !value.includes('@')) //handle input type email
        {
            return generateResult(props, false, 'harus email valid');
        } else if (type == 'file') //handle input type file
        {
            return handleFileValidator(props);
        }

    return generateResult(props, true);
}

function validationChecker() {
    var is_valid = true;
    Object.keys(validator).map(function (n) {
        is_valid = is_valid && validator[n].is_valid;
    });
    return is_valid;
}

function validationSeter(keys) {
    keys.map(function (n) {
        validator[n + '_validate'] = generateResult({ name: n }, false, 'wajib diisi');
    });

    return validator;
}

function handleFileValidator(props) {
    var max = props.max,
        value = props.value;

    if (value.size > max) //melebihi max size
        {
            return generateResult(props, false, 'ukuran maksimum adalah ' + max / 1000000 + ' MB');
        }
    return generateResult(props, true);
}

function generateResult(props) {
    var is_valid = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
    var message = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '';
    var name = props.name;

    var result = {
        is_valid: is_valid,
        message: message
    };
    validator[name + '_validate'] = result;
    return result;
}