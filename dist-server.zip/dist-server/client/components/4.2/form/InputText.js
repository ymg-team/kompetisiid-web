'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _Validator = require('./Validator');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var InputText = function (_Component) {
    _inherits(InputText, _Component);

    function InputText() {
        _classCallCheck(this, InputText);

        return _possibleConstructorReturn(this, (InputText.__proto__ || Object.getPrototypeOf(InputText)).apply(this, arguments));
    }

    _createClass(InputText, [{
        key: 'handleChange',
        value: function handleChange(e) {
            var _this2 = this;

            this.props.setState(_defineProperty({}, this.props.name, e.target.value), function () {
                _this2.validateInput();
            });
        }
    }, {
        key: 'validateInput',
        value: function validateInput() {
            var result = (0, _Validator.validate)(this.props);
            this.props.setState(_defineProperty({}, this.props.name + '_validate', result));
        }
    }, {
        key: 'render',
        value: function render() {
            var _this3 = this;

            var _props = this.props,
                min = _props.min,
                max = _props.max,
                value = _props.value,
                label = _props.label,
                name = _props.name,
                type = _props.type,
                validate = _props.validate,
                autofocus = _props.autofocus;

            var is_valid = !(!validate.is_valid && validate.message);
            return _react2.default.createElement(
                'div',
                { className: 'form-child ' + (!is_valid ? 'error' : '') },
                _react2.default.createElement(
                    'label',
                    { htmlFor: name },
                    label
                ),
                _react2.default.createElement('input', {
                    onChange: function onChange(e) {
                        return _this3.handleChange(e);
                    },
                    onBlur: function onBlur(e) {
                        return _this3.handleChange(e);
                    },
                    type: type,
                    name: name,
                    id: name,
                    value: value.replace(/[\u200B-\u200D\uFEFF]|\s\s/g, ' '),
                    autoFocus: autofocus }),
                max ? _react2.default.createElement(
                    'small',
                    null,
                    value.length || 0,
                    '/',
                    max,
                    ' karakter ',
                    _react2.default.createElement('br', null)
                ) : null,
                !is_valid ? _react2.default.createElement(
                    'small',
                    null,
                    validate.message
                ) : null
            );
        }
    }]);

    return InputText;
}(_react.Component);

exports.default = InputText;


InputText.defaultProps = {
    type: 'text',
    required: false
};