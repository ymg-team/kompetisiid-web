'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactRouter = require('react-router');

var _reactRedux = require('react-redux');

var _actions = require('../../../store/user/actions');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Header = function (_Component) {
    _inherits(Header, _Component);

    function Header() {
        _classCallCheck(this, Header);

        return _possibleConstructorReturn(this, (Header.__proto__ || Object.getPrototypeOf(Header)).apply(this, arguments));
    }

    _createClass(Header, [{
        key: 'handleSearch',
        value: function handleSearch(e) {
            if (e.keyCode == 13) {
                return window.location.href = '/browse?q=' + this.props.q;
            }
        }
    }, {
        key: 'handleLogout',
        value: function handleLogout() {
            fullalert('warning', 'logout...');
            this.props.dispatch((0, _actions.logout)());
        }
    }, {
        key: 'componentWillReceiveProps',
        value: function componentWillReceiveProps(np) {
            var logout = np.logout;

            if (logout.meta) {
                if (logout.meta.code === 201) {
                    setTimeout(function () {
                        window.location.href = '/';
                    }, 1500);
                    fullalert('success', logout.meta.message, false);
                } else {
                    fullalert('error', logout.meta.message, false);
                }
            }
        }
    }, {
        key: 'render',
        value: function render() {
            var _this2 = this;

            var _props = this.props,
                q = _props.q,
                session = _props.session;

            return _react2.default.createElement(
                'nav',
                null,
                _react2.default.createElement(
                    'div',
                    { style: { top: q ? '-50px' : '0px' }, className: 'nav-header' },
                    _react2.default.createElement(
                        'a',
                        { id: 'btn-menu', href: 'javascript:;' },
                        ' ',
                        _react2.default.createElement('span', { className: 'fa fa-bars' })
                    ),
                    _react2.default.createElement(
                        'div',
                        { className: 'nav-left' },
                        _react2.default.createElement(
                            'a',
                            { className: 'only-mobile', href: 'javascript:;', id: 'btn-show-nav' },
                            _react2.default.createElement('i', { className: 'fa fa-bars' })
                        ),
                        _react2.default.createElement(
                            'ul',
                            { className: 'top-menu', id: 'top-menu' },
                            _react2.default.createElement('a', { style: { position: 'absolute', top: '0.5em', right: '0.5em' }, id: 'btn-hide-nav', className: ' btn-close-nav only-mobile fa fa-close', href: 'javascript:;' }),
                            _react2.default.createElement(
                                'li',
                                null,
                                _react2.default.createElement(
                                    _reactRouter.Link,
                                    { onClick: function onClick() {
                                            return toggleNavTop();
                                        }, to: '/browse' },
                                    'jelajah'
                                )
                            ),
                            _react2.default.createElement(
                                'li',
                                null,
                                _react2.default.createElement(
                                    _reactRouter.Link,
                                    { onClick: function onClick() {
                                            return toggleNavTop();
                                        }, to: '/add' },
                                    'pasang'
                                )
                            ),
                            _react2.default.createElement(
                                'li',
                                null,
                                _react2.default.createElement(
                                    _reactRouter.Link,
                                    { onClick: function onClick() {
                                            return toggleNavTop();
                                        }, to: '/news' },
                                    'berita'
                                )
                            )
                        )
                    ),
                    _react2.default.createElement(
                        'div',
                        { className: 'logo' },
                        _react2.default.createElement(
                            _reactRouter.Link,
                            { to: '/' },
                            _react2.default.createElement('img', { src: '/assets/4.2/img/icon-128x128.png' })
                        )
                    ),
                    _react2.default.createElement(
                        'div',
                        { className: 'nav-right' },
                        _react2.default.createElement(
                            'ul',
                            { className: 'top-menu' },
                            _react2.default.createElement(
                                'li',
                                null,
                                _react2.default.createElement(
                                    'a',
                                    { id: 'btn-search', href: 'javascript:;', title: 'click untuk melakukan pencarian' },
                                    ' ',
                                    _react2.default.createElement('span', { className: 'fa fa-search' })
                                )
                            ),
                            session && session.meta && session.meta.code == 201 ? _react2.default.createElement(
                                'li',
                                null,
                                _react2.default.createElement(
                                    'div',
                                    { className: 'dropdown' },
                                    _react2.default.createElement(
                                        'a',
                                        { className: 'avatar', href: 'javascript:;' },
                                        _react2.default.createElement('img', { className: 'dropdown-button', src: '/assets/4.2/img/avatar-default.jpg', 'data-target': 'avatar-menu' })
                                    ),
                                    _react2.default.createElement(
                                        'div',
                                        { className: 'dropdown-items', id: 'avatar-menu' },
                                        _react2.default.createElement(
                                            'ul',
                                            null,
                                            _react2.default.createElement(
                                                'li',
                                                null,
                                                _react2.default.createElement(
                                                    _reactRouter.Link,
                                                    { to: '/' + session.data.username },
                                                    'Profil saya'
                                                )
                                            ),
                                            _react2.default.createElement(
                                                'li',
                                                null,
                                                _react2.default.createElement(
                                                    _reactRouter.Link,
                                                    { to: '/dashboard/competition/live' },
                                                    'Dashboard'
                                                )
                                            ),
                                            _react2.default.createElement(
                                                'li',
                                                null,
                                                _react2.default.createElement(
                                                    _reactRouter.Link,
                                                    { to: '/settings' },
                                                    'Setelan'
                                                )
                                            ),
                                            _react2.default.createElement(
                                                'li',
                                                null,
                                                _react2.default.createElement(
                                                    'a',
                                                    { href: 'javascript:;', onClick: function onClick() {
                                                            return _this2.handleLogout();
                                                        } },
                                                    'Logout'
                                                )
                                            )
                                        )
                                    )
                                )
                            ) : _react2.default.createElement(
                                'li',
                                { style: { display: 'none' }, className: 'hide-mobile' },
                                _react2.default.createElement(
                                    _reactRouter.Link,
                                    { to: '/login' },
                                    'login'
                                )
                            )
                        )
                    )
                ),
                _react2.default.createElement(
                    'div',
                    { className: 'nav-search' },
                    _react2.default.createElement(
                        'label',
                        { htmlFor: 'search' },
                        'Pencarian '
                    ),
                    _react2.default.createElement('input', {
                        type: 'text',
                        value: q || '',
                        placeholder: 'tekan enter untuk submit',
                        onChange: function onChange(e) {
                            return _this2.props.setState({ q: e.target.value });
                        },
                        onKeyDown: function onKeyDown(e) {
                            return _this2.handleSearch(e);
                        } }),
                    _react2.default.createElement(
                        'a',
                        { id: 'btn-closesearch', onClick: function onClick() {
                                if (q != '') return window.location.href = '/browse';
                            }, href: 'javascript:;', title: 'tutup pencarian' },
                        ' ',
                        _react2.default.createElement('span', { className: 'fa fa-close' })
                    )
                )
            );
        }
    }]);

    return Header;
}(_react.Component);

function mapStateToProps(state) {
    var User = state.User;

    return {
        session: User.session,
        logout: User.logout
    };
}

function mapDispatchToProps(dispatch) {
    return {
        dispatch: dispatch
    };
}

exports.default = (0, _reactRedux.connect)(mapStateToProps, mapDispatchToProps)(Header);