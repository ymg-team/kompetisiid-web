'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _CompetitionTags = require('../buttons/CompetitionTags');

var _CompetitionTags2 = _interopRequireDefault(_CompetitionTags);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var Regulations = function Regulations(props) {
    var html = props.html,
        encid = props.encid,
        nospace_title = props.nospace_title;

    return _react2.default.createElement(
        'div',
        null,
        _react2.default.createElement(
            'h2',
            null,
            'Peraturan kompetisi'
        ),
        _react2.default.createElement(
            'p',
            { className: 'text-muted' },
            'Sebelum mengikuti kompetisi ini, wajib untuk membaca dan mentaati setiap peraturan yang berlaku'
        ),
        _react2.default.createElement('hr', null),
        _react2.default.createElement('article', { dangerouslySetInnerHTML: { __html: html } }),
        _react2.default.createElement('br', null),
        _react2.default.createElement(
            'a',
            { href: '/competition/' + encid + '/source/' + nospace_title, target: '_blank' },
            'kunjungi website kompetisi'
        ),
        _react2.default.createElement('hr', null),
        _react2.default.createElement(_CompetitionTags2.default, { tags: props.tags })
    );
};

exports.default = Regulations;