"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _react = require("react");

var _react2 = _interopRequireDefault(_react);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var Prizes = function Prizes(props) {
    return _react2.default.createElement(
        "div",
        null,
        _react2.default.createElement(
            "h2",
            null,
            "Hadiah kompetisi"
        ),
        _react2.default.createElement(
            "p",
            { className: "text-muted" },
            "Berikut adalah hadiah-hadiah yang bisa dimenangkan para pemenang, semoga beruntung"
        ),
        _react2.default.createElement("hr", null),
        _react2.default.createElement("article", { dangerouslySetInnerHTML: { __html: props.html } })
    );
};

exports.default = Prizes;