'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Share = function (_Component) {
    _inherits(Share, _Component);

    function Share() {
        _classCallCheck(this, Share);

        return _possibleConstructorReturn(this, (Share.__proto__ || Object.getPrototypeOf(Share)).apply(this, arguments));
    }

    _createClass(Share, [{
        key: 'render',
        value: function render() {
            var _props = this.props,
                title = _props.title,
                desc = _props.desc,
                link = _props.link;

            return _react2.default.createElement(
                'div',
                null,
                _react2.default.createElement(
                    'h2',
                    null,
                    'Share kompetisi'
                ),
                _react2.default.createElement(
                    'p',
                    { className: 'text-muted' },
                    'Bagikan ke teman-temanmu untuk meramaikan kompetisi ini.'
                ),
                _react2.default.createElement('hr', null),
                _react2.default.createElement(
                    'a',
                    {
                        href: 'javascript:;',
                        className: 'share share-facebook',
                        title: 'share ke Facebook',
                        onClick: function onClick() {
                            window.open('http://www.facebook.com/sharer/sharer.php?u=' + link + '&title=' + title + '&desc=' + desc, 'MsgWindow', 'width=500,height=400');
                        } },
                    _react2.default.createElement(
                        'div',
                        { className: 'share__icon' },
                        _react2.default.createElement('i', { className: 'fa fa-facebook' })
                    ),
                    _react2.default.createElement(
                        'div',
                        { className: 'share__count' },
                        _react2.default.createElement(
                            'strong',
                            null,
                            'Facebook '
                        ),
                        '456787'
                    )
                ),
                _react2.default.createElement(
                    'a',
                    {
                        href: 'javascript:;',
                        className: 'share share-twitter',
                        title: 'share ke Twitter',
                        onClick: function onClick() {
                            window.open('http://twitter.com/intent/tweet?status=' + title + '+' + link, 'MsgWindow', 'width=500,height=400');
                        } },
                    _react2.default.createElement(
                        'div',
                        { className: 'share__icon' },
                        _react2.default.createElement('i', { className: 'fa fa-twitter' })
                    ),
                    _react2.default.createElement(
                        'div',
                        { className: 'share__count' },
                        _react2.default.createElement(
                            'strong',
                            null,
                            'Twitter '
                        ),
                        '420879'
                    )
                ),
                _react2.default.createElement(
                    'a',
                    {
                        href: 'javascript:;',
                        className: 'share share-linkedin',
                        title: 'share ke Linkedin',
                        onClick: function onClick() {
                            window.open('http://www.linkedin.com/shareArticle?mini=true&url=' + link + '&title=' + title, 'MsgWindow', 'width=500,height=400');
                        } },
                    _react2.default.createElement(
                        'div',
                        { className: 'share__icon' },
                        _react2.default.createElement('i', { className: 'fa fa-linkedin' })
                    ),
                    _react2.default.createElement(
                        'div',
                        { className: 'share__count' },
                        _react2.default.createElement(
                            'strong',
                            null,
                            'Linkedin '
                        ),
                        '345'
                    )
                ),
                _react2.default.createElement(
                    'a',
                    {
                        href: 'javascript:;',
                        className: 'share share-sebangsa',
                        title: 'share ke Sebangsa',
                        onClick: function onClick() {
                            window.open('https://sebangsa.com/post/create?text=' + link + ' ' + title, 'MsgWindow', 'width=500,height=400');
                        } },
                    _react2.default.createElement(
                        'div',
                        { className: 'share__icon' },
                        _react2.default.createElement('i', { className: 'fa fa-sebangsa' })
                    ),
                    _react2.default.createElement(
                        'div',
                        { className: 'share__count' },
                        _react2.default.createElement(
                            'strong',
                            null,
                            'Sebangsa '
                        ),
                        '12879'
                    )
                )
            );
        }
    }]);

    return Share;
}(_react.Component);

exports.default = Share;