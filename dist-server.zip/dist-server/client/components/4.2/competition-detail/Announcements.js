"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _react = require("react");

var _react2 = _interopRequireDefault(_react);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var Announcements = function Announcements(props) {
    return _react2.default.createElement(
        "div",
        null,
        _react2.default.createElement(
            "h2",
            null,
            "Pengumuman kompetisi"
        ),
        _react2.default.createElement(
            "p",
            { className: "text-muted" },
            "Berisi pengumuman jika terjadi perubahan peraturan, detail hadiah, atau hal penting lainnya pada kompetisi ini."
        ),
        _react2.default.createElement("hr", null),
        props.data && props.data.length > 0 ? props.data.map(function (n, key) {
            return _react2.default.createElement(
                "div",
                { key: key, className: "announcements-list" },
                key > 0 ? _react2.default.createElement("hr", null) : null,
                _react2.default.createElement(
                    "small",
                    { className: "text-muted" },
                    n.tgl,
                    " oleh ",
                    n.by
                ),
                _react2.default.createElement("br", null),
                n.data
            );
        }) : _react2.default.createElement(
            "p",
            null,
            "saat ini tidak ada pengumuman"
        )
    );
};

exports.default = Announcements;