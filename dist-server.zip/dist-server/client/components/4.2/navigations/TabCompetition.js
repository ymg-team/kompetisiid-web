'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.tab = undefined;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactRouter = require('react-router');

var _BtnJoin = require('../buttons/BtnJoin');

var _BtnJoin2 = _interopRequireDefault(_BtnJoin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var TabCompetition = function TabCompetition(props) {
  var n_pengumuman = props.data && props.data.dataPengumuman ? JSON.parse(props.data.dataPengumuman).length : 0;
  var n_kontak = props.data && props.data.kontak ? JSON.parse(props.data.kontak).length : 0;
  console.log(n_pengumuman);
  return _react2.default.createElement(
    'div',
    { id: 'container-competition-tab', className: 'row no-margin container-competition-tab' },
    _react2.default.createElement(
      'div',
      { className: 'col-md-12' },
      _react2.default.createElement(
        'div',
        { className: 'container' },
        _react2.default.createElement(
          'div',
          { className: 'row' },
          _react2.default.createElement(
            'div',
            { className: 'col-md-10 col-md-push-1' },
            _react2.default.createElement(
              'div',
              { className: 'tab-competition' },
              _react2.default.createElement(
                'ul',
                { className: 'horizontal-menu' },
                tab.map(function (n, key) {
                  return _react2.default.createElement(
                    'li',
                    { key: key, className: props.active - 1 == key ? 'active' : '' },
                    _react2.default.createElement(
                      _reactRouter.Link,
                      { to: '/competition/' + props.data.id_kompetisi + '/' + tab[key].link + '/' + props.data.nospace_title },
                      n.name,
                      ' ',
                      n.name == 'pengumuman' && n_pengumuman > 0 ? _react2.default.createElement(
                        'div',
                        { className: 'label label-small ' + (props.active - 1 == key ? 'label-red' : 'label-white') },
                        n_pengumuman
                      ) : null,
                      n.name == 'kontak' && n_kontak > 0 ? _react2.default.createElement(
                        'div',
                        { className: 'label label-small ' + (props.active - 1 == key ? 'label-red' : 'label-white') },
                        n_kontak
                      ) : null
                    )
                  );
                })
              ),
              _react2.default.createElement(_BtnJoin2.default, _extends({
                id: 'btn-join'
              }, props))
            )
          )
        )
      )
    )
  );
};

exports.default = TabCompetition;
var tab = exports.tab = [{
  name: 'peraturan',
  link: 'regulations'
}, {
  name: 'hadiah',
  link: 'prizes'
}, {
  name: 'pengumuman',
  link: 'annoucements'
}, {
  name: 'diskusi',
  link: 'discussions'
}, {
  name: 'kontak',
  link: 'contacts'
}, {
  name: 'share',
  link: 'share'
}];