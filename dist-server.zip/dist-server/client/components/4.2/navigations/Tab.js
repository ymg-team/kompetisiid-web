'use strict';

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactRouter = require('react-router');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var Tab = function Tab(props) {
    return _react2.default.createElement(
        'div',
        { className: 'container-competition-tab', style: { margin: '20px 0 20px' } },
        _react2.default.createElement(
            'ul',
            { className: 'horizontal-menu' },
            props.tabs.map(function (n, key) {
                return _react2.default.createElement(
                    'li',
                    { key: key,
                        className: n.is_active ? 'active' : '' },
                    _react2.default.createElement(
                        _reactRouter.Link,
                        { to: n.target },
                        n.text,
                        ' ',
                        n.count ? _react2.default.createElement(
                            'span',
                            { className: 'label label-gray' },
                            n.count
                        ) : null
                    )
                );
            })
        )
    );
};