'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var TabProfile = function TabProfile(props) {
    return _react2.default.createElement(
        'div',
        { className: 'col-md-12' },
        _react2.default.createElement(
            'div',
            { className: 'container' },
            _react2.default.createElement(
                'div',
                { className: 'col-md-10 col-md-push-1' },
                _react2.default.createElement(
                    'div',
                    { className: 'row' },
                    _react2.default.createElement(
                        'nav',
                        { className: 'profile-nav' },
                        _react2.default.createElement(
                            'ul',
                            null,
                            _react2.default.createElement(
                                'li',
                                null,
                                _react2.default.createElement(
                                    'a',
                                    { href: 'javascript:;' },
                                    _react2.default.createElement(
                                        'h3',
                                        null,
                                        props.data.dipasang
                                    ),
                                    'kompetisi dipasang'
                                )
                            ),
                            _react2.default.createElement(
                                'li',
                                null,
                                _react2.default.createElement(
                                    'a',
                                    { href: 'javascript:;' },
                                    _react2.default.createElement(
                                        'h3',
                                        null,
                                        props.data.diikuti
                                    ),
                                    'kompetisi diikuti'
                                )
                            ),
                            _react2.default.createElement(
                                'li',
                                null,
                                _react2.default.createElement(
                                    'a',
                                    { href: 'javascript:;' },
                                    _react2.default.createElement(
                                        'h3',
                                        null,
                                        props.data.menang
                                    ),
                                    'kompetisi dimenangkan'
                                )
                            ),
                            _react2.default.createElement(
                                'li',
                                null,
                                _react2.default.createElement(
                                    'a',
                                    { href: 'javascript:;' },
                                    _react2.default.createElement(
                                        'h3',
                                        null,
                                        props.data.dikunjungi
                                    ),
                                    'kompetisi dikunjungi'
                                )
                            ),
                            _react2.default.createElement(
                                'li',
                                null,
                                _react2.default.createElement(
                                    'a',
                                    { href: 'javascript:;' },
                                    _react2.default.createElement(
                                        'h3',
                                        null,
                                        props.data.langganan
                                    ),
                                    'kompetisi langganan'
                                )
                            ),
                            _react2.default.createElement(
                                'li',
                                null,
                                _react2.default.createElement(
                                    'a',
                                    { href: 'javascript:;' },
                                    _react2.default.createElement(
                                        'h3',
                                        null,
                                        props.data.favorit
                                    ),
                                    'kompetisi favorit'
                                )
                            )
                        )
                    )
                )
            )
        )
    );
};

exports.default = TabProfile;