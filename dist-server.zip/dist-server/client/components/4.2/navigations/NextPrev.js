'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactRouter = require('react-router');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var NextPrev = function NextPrev(props) {
    var next = props.next,
        prev = props.prev;

    return _react2.default.createElement(
        'div',
        { className: 'col-md-12' },
        _react2.default.createElement(
            'div',
            { className: 'container' },
            _react2.default.createElement(
                'div',
                { className: 'row' },
                _react2.default.createElement(
                    'div',
                    { className: 'col-md-10 col-md-push-1 m-t-b-20' },
                    _react2.default.createElement(
                        'div',
                        { className: 'competition-nextprev' },
                        _react2.default.createElement(
                            'div',
                            { className: 'col-md-4 align-left ' + (next ? 'btn-nextprev' : '') },
                            next ? _react2.default.createElement(
                                _reactRouter.Link,
                                { to: next.link },
                                _react2.default.createElement(
                                    'h4',
                                    null,
                                    'sebelumnya'
                                ),
                                next.title
                            ) : _react2.default.createElement('p', null)
                        ),
                        _react2.default.createElement(
                            'div',
                            { className: 'col-md-4' },
                            _react2.default.createElement('p', null)
                        ),
                        _react2.default.createElement(
                            'div',
                            { className: 'col-md-4 align-right ' + (prev ? 'btn-nextprev' : '') },
                            prev ? _react2.default.createElement(
                                _reactRouter.Link,
                                { to: prev.link },
                                _react2.default.createElement(
                                    'h4',
                                    null,
                                    'sebelumnya'
                                ),
                                prev.title
                            ) : _react2.default.createElement('p', null)
                        )
                    )
                )
            )
        )
    );
};

exports.default = NextPrev;