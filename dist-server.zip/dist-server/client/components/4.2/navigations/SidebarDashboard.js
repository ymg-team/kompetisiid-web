'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var SidebarDashboard = function SidebarDashboard() {
    return _react2.default.createElement(
        'div',
        { className: 'col-md-2' },
        _react2.default.createElement(
            'div',
            { className: 'dashboard-sidebar' },
            _react2.default.createElement(
                'ul',
                null,
                _react2.default.createElement(
                    'li',
                    { className: 'active' },
                    ' ',
                    _react2.default.createElement(
                        'a',
                        { href: '#' },
                        'Pasang Kompetisi'
                    )
                ),
                _react2.default.createElement(
                    'li',
                    null,
                    ' ',
                    _react2.default.createElement(
                        'a',
                        { href: '#' },
                        'Kompetisi Saya',
                        _react2.default.createElement(
                            'span',
                            { className: 'label label-blue' },
                            '23'
                        )
                    )
                ),
                _react2.default.createElement('hr', null),
                _react2.default.createElement(
                    'li',
                    null,
                    ' ',
                    _react2.default.createElement(
                        'strong',
                        null,
                        'Manajemen Kompetisi'
                    )
                ),
                _react2.default.createElement(
                    'li',
                    null,
                    _react2.default.createElement(
                        'a',
                        { href: '#' },
                        'Semua Kompetisi',
                        _react2.default.createElement(
                            'span',
                            { className: 'label label-blue' },
                            '245'
                        )
                    )
                ),
                _react2.default.createElement(
                    'li',
                    null,
                    _react2.default.createElement(
                        'a',
                        { href: '#' },
                        'Request Pasang Cepat',
                        _react2.default.createElement(
                            'span',
                            { className: 'label label-blue' },
                            '245'
                        ),
                        _react2.default.createElement(
                            'span',
                            { className: 'label label-red' },
                            '56'
                        )
                    )
                ),
                _react2.default.createElement(
                    'li',
                    null,
                    _react2.default.createElement(
                        'a',
                        { href: '#' },
                        'Request Pasang Komplit',
                        _react2.default.createElement(
                            'span',
                            { className: 'label label-blue' },
                            '245'
                        ),
                        _react2.default.createElement(
                            'span',
                            { className: 'label label-red' },
                            '12'
                        )
                    )
                ),
                _react2.default.createElement('hr', null),
                _react2.default.createElement(
                    'li',
                    null,
                    _react2.default.createElement(
                        'strong',
                        null,
                        'Manajemen Berita      '
                    )
                ),
                _react2.default.createElement(
                    'li',
                    null,
                    _react2.default.createElement(
                        'a',
                        { href: '#' },
                        'Semua Berita',
                        _react2.default.createElement(
                            'span',
                            { className: 'label label-blue' },
                            '24'
                        )
                    )
                )
            )
        )
    );
};

exports.default = SidebarDashboard;