'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactRouter = require('react-router');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var CompetitionTags = function CompetitionTags(props) {
    return _react2.default.createElement(
        'span',
        null,
        props.tags ? props.tags.map(function (n, key) {
            return _react2.default.createElement(
                _reactRouter.Link,
                { className: 'btn btn-white', to: '/browse/tag/' + n, key: key, href: 'javascript:;' },
                n
            );
        }) : _react2.default.createElement(
            'small',
            { className: 'text-muted' },
            'tidak ada tags tersedia'
        )
    );
};

exports.default = CompetitionTags;