'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var DefaultLoader = function DefaultLoader() {
    return _react2.default.createElement(
        'div',
        { className: 'col-md-12', style: { padding: '4em 0' } },
        _react2.default.createElement(
            'div',
            { className: 'row no-margin' },
            _react2.default.createElement(
                'div',
                { className: 'loader' },
                _react2.default.createElement('img', { src: '/assets/4.2/img/loader.gif' })
            )
        )
    );
};

exports.default = DefaultLoader;