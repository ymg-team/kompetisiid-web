'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var Loader = function Loader(props) {
    var childs = [];
    for (var n = 0; n < props.total; n++) {
        childs.push(_react2.default.createElement(
            'div',
            { key: n, className: (props.size == 'large' ? 'col-md-4' : 'col-md-3') + ' ' + (n > 0 ? 'hide-mobile' : '') },
            _react2.default.createElement(
                'div',
                { className: 'news-loader' },
                _react2.default.createElement(
                    'div',
                    { className: 'animated-background' },
                    _react2.default.createElement('div', { className: 'background-masker background-masker-1' }),
                    _react2.default.createElement('div', { className: 'background-masker background-masker-1-1' }),
                    _react2.default.createElement('div', { className: 'background-masker background-masker-1-2' }),
                    _react2.default.createElement('div', { className: 'background-masker background-masker-2' }),
                    _react2.default.createElement('div', { className: 'background-masker background-masker-2-1' }),
                    _react2.default.createElement('div', { className: 'background-masker background-masker-2-2' }),
                    _react2.default.createElement('div', { className: 'background-masker background-masker-3' }),
                    _react2.default.createElement('div', { className: 'background-masker background-masker-3-1' }),
                    _react2.default.createElement('div', { className: 'background-masker background-masker-3-2' })
                )
            )
        ));
    }

    return _react2.default.createElement(
        'div',
        { className: 'row' },
        childs
    );
};

Loader.defaultProps = {
    total: 3,
    size: 'large'
};

exports.default = Loader;