"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.findStr = findStr;
/**
 * Created by yussan on 18/12/16.
 */
function findStr(needle, haystack) {
  return needle.indexOf(haystack) !== -1;
}