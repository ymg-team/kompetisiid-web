'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.eventFire = eventFire;
exports.copyText = copyText;
// event to fire to valid DOM
function eventFire(el, evType) {
    if (el.fireEvent) {
        el.fireEvent('on' + eventType);
    } else {
        var evObj = document.createEvent('Event');
        evObj.initEvent(evType, true, false);
        el.dispatchEvent(evObj);
    }
}

// copy to clipboard
function copyText(str) {}