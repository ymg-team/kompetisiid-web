'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.eventFire = eventFire;
exports.pushScript = pushScript;
// event to fire to valid DOM
function eventFire(el, evType) {
    if (el.fireEvent) {
        el.fireEvent('on' + eventType);
    } else {
        var evObj = document.createEvent('Event');
        evObj.initEvent(evType, true, false);
        el.dispatchEvent(evObj);
    }
}

function pushScript(src, cb) {
    if (!isScriptLoaded()) {
        var s = document.createElement('script');
        s.setAttribute('src', src);
        if (cb) s.onload = cb;
        document.body.appendChild(s);
    }
}

function isScriptLoaded(src) {
    var scripts = document.getElementsByTagName('script');
    // is script available
    for (var i = scripts.length; i--;) {
        if (scripts[i].src == src) return true;
    }

    return false;
}