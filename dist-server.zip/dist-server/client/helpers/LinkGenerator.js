'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.singleLink = singleLink;
exports.generateLink = generateLink;
exports.isHttps = isHttps;
exports.openInNewTab = openInNewTab;

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Created by yussan on 21/10/16.
 */
function singleLink(id, title, prefix) {
    return '/' + prefix + '/' + id + '/' + title;
}

function generateLink(link) {
    var target = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '_self';

    if (link.search('http') > -1) {
        return _react2.default.createElement(
            'a',
            { href: link, target: target },
            link
        );
    } else {
        return link;
    }
}

function isHttps(link) {
    if (link.search('https') > -1) {
        return true;
    } else {
        return false;
    }
}

function openInNewTab(url) {
    return window.open(url, '_blank').focus();
}