'use strict';

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactDom = require('react-dom');

var _reactDom2 = _interopRequireDefault(_reactDom);

var _reactRouter = require('react-router');

var _routes = require('./routes');

var _routes2 = _interopRequireDefault(_routes);

var _reactRedux = require('react-redux');

var _store = require('../config/store');

var _store2 = _interopRequireDefault(_store);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_reactRouter.browserHistory.listen(function (location) {
    if (window.ga) window.ga('send', 'pageview', location.pathname);
});

var App = function App() {
    return _react2.default.createElement(
        _reactRedux.Provider,
        { store: _store2.default },
        _react2.default.createElement(_reactRouter.Router, { children: _routes2.default, history: _reactRouter.browserHistory })
    );
};

_reactDom2.default.render(_react2.default.createElement(App, { title: 'Judul' }), document.getElementById('root'));