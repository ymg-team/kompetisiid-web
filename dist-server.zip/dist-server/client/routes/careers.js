'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _Careers = require('../containers/4.2/Careers');

var _Careers2 = _interopRequireDefault(_Careers);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function handleOther() {
    if (typeof window != 'undefined') window.scrollTo(0, 0);
}

exports.default = {
    childRoutes: [{
        path: 'careers',
        onEnter: function onEnter() {
            return handleOther();
        },
        component: _Careers2.default
    }]
};