'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _AddCompetition = require('../containers/4.2/AddCompetition');

var _AddCompetition2 = _interopRequireDefault(_AddCompetition);

var _SendCompetition = require('../containers/4.2/SendCompetition');

var _SendCompetition2 = _interopRequireDefault(_SendCompetition);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    childRoutes: [{
        path: 'add',
        indexRoute: {
            component: _AddCompetition2.default
        },
        childRoutes: [{
            path: 'send',
            component: _SendCompetition2.default
        }]
    }, {
        path: 'pasang',
        indexRoute: {
            component: _AddCompetition2.default
        }
    }]
};