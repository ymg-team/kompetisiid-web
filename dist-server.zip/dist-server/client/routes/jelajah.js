'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _BrowseCompetition = require('../containers/4.2/BrowseCompetition');

var _BrowseCompetition2 = _interopRequireDefault(_BrowseCompetition);

var _Error = require('../containers/4.2/Error');

var _Error2 = _interopRequireDefault(_Error);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    childRoutes: [{
        path: 'jelajah',
        indexRoute: {
            component: _BrowseCompetition2.default
        },
        childRoutes: [{
            path: 'tag',
            error_code: 404,
            error_msg: 'Halaman yang anda kunjungi tidak ditemukan',
            component: _Error2.default
        }, {
            path: 'tag/:tag',
            component: _BrowseCompetition2.default
        }, {

            path: ':mainkat(/:subkat)',
            component: _BrowseCompetition2.default
        }]
    }, {
        path: 'browse',
        indexRoute: {
            component: _BrowseCompetition2.default
        },
        childRoutes: [{
            path: 'tag',
            error_code: 404,
            error_msg: 'Halaman yang anda kunjungi tidak ditemukan',
            component: _Error2.default
        }, {
            path: 'tag/:tag',
            component: _BrowseCompetition2.default
        }, {

            path: ':mainkat(/:subkat)',
            component: _BrowseCompetition2.default
        }]
    }]
};