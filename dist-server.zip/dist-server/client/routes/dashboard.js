'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _CompetitionList = require('../containers/4.2/Dashboard/CompetitionList');

var _CompetitionList2 = _interopRequireDefault(_CompetitionList);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    childRoutes: [{
        path: 'dashboard',
        childRoutes: [{
            path: 'competition/live',
            tab_active: 1,
            component: _CompetitionList2.default
        }, {
            path: 'competition/end',
            tab_active: 2,
            component: _CompetitionList2.default
        }, {
            path: 'competition/moderation',
            tab_active: 3,
            component: _CompetitionList2.default
        }, {
            path: 'competition/reject',
            tab_active: 4,
            component: _CompetitionList2.default
        }]
    }]
};