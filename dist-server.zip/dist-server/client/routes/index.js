'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _berita = require('./berita');

var _berita2 = _interopRequireDefault(_berita);

var _categories = require('./categories');

var _categories2 = _interopRequireDefault(_categories);

var _jelajah = require('./jelajah');

var _jelajah2 = _interopRequireDefault(_jelajah);

var _kompetisi = require('./kompetisi');

var _kompetisi2 = _interopRequireDefault(_kompetisi);

var _account = require('./account');

var _account2 = _interopRequireDefault(_account);

var _pasang = require('./pasang');

var _pasang2 = _interopRequireDefault(_pasang);

var _profile = require('./profile');

var _profile2 = _interopRequireDefault(_profile);

var _dashboard = require('./dashboard');

var _dashboard2 = _interopRequireDefault(_dashboard);

var _careers = require('./careers');

var _careers2 = _interopRequireDefault(_careers);

var _Login = require('../containers/4.2/Login');

var _Login2 = _interopRequireDefault(_Login);

var _Home = require('../containers/4.2/Home');

var _Home2 = _interopRequireDefault(_Home);

var _Error = require('../containers/4.2/Error');

var _Error2 = _interopRequireDefault(_Error);

var _Home3 = require('../layouts/4.2/Home');

var _Home4 = _interopRequireDefault(_Home3);

var _Error3 = require('../layouts/4.2/Error');

var _Error4 = _interopRequireDefault(_Error3);

var _Dashboard = require('../layouts/4.2/Dashboard');

var _Dashboard2 = _interopRequireDefault(_Dashboard);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    path: '/',
    childRoutes: [{
        component: _Error4.default,
        childRoutes: [{
            path: 'dashboard',
            error_code: 404,
            error_msg: 'Halaman yang anda kunjungi tidak ditemukan',
            component: _Error2.default
        }]
    }, {
        component: _Error4.default,
        childRoutes: [{
            path: 'login',
            component: _Login2.default
        }]
    }, {
        component: _Dashboard2.default,
        childRoutes: [_dashboard2.default]
    }, {
        component: _Home4.default,
        indexRoute: {
            isRed: true,
            component: _Home2.default
        },
        childRoutes: [_berita2.default, _categories2.default, _jelajah2.default, _kompetisi2.default, _account2.default, _pasang2.default, _careers2.default, _profile2.default]
    }, {
        path: '*',
        component: _Error4.default,
        indexRoute: {
            error_code: 404,
            error_msg: 'Halaman yang anda kunjungi tidak ditemukan',
            component: _Error2.default
        }
    }]
}; /**
    * Created by yussan on 06/10/16.
    *  الرَّحْمَنِالرَّحِيم اللَّهِ بِسْمِ
    */