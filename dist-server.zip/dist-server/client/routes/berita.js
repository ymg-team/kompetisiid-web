'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _NewsDetail = require('../containers/4.2/NewsDetail');

var _NewsDetail2 = _interopRequireDefault(_NewsDetail);

var _NewsList = require('../containers/4.2/NewsList');

var _NewsList2 = _interopRequireDefault(_NewsList);

var _Error = require('../containers/4.2/Error');

var _Error2 = _interopRequireDefault(_Error);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    childRoutes: [{
        path: 'news',
        indexRoute: {
            component: _NewsList2.default
        },
        childRoutes: [{
            path: 'tag',
            error_code: 404,
            error_msg: 'Halaman yang anda kunjungi tidak ditemukan',
            component: _Error2.default
        }, {
            path: 'tag/:tag',
            component: _NewsList2.default
        }, {
            path: ':encid(/:title)',
            component: _NewsDetail2.default
        }]
    }, {
        path: 'berita',
        indexRoute: {
            component: _NewsList2.default
        },
        childRoutes: [{
            path: 'tag',
            error_code: 404,
            error_msg: 'Halaman yang anda kunjungi tidak ditemukan',
            component: _Error2.default
        }, {
            path: 'tag/:tag',
            component: _NewsList2.default
        }, {
            path: 'baca/:encid(/:title)',
            component: _NewsDetail2.default
        }, {
            path: ':encid(/:title)',
            component: _NewsDetail2.default
        }]
    }]
};