'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _Categories = require('../containers/4.2/Categories');

var _Categories2 = _interopRequireDefault(_Categories);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function handleEnter() {
    if (typeof window != 'undefined') window.scrollTo(0, 0);
}

exports.default = {
    path: 'categories',
    indexRoute: {
        onEnter: function onEnter() {
            return handleEnter();
        },
        component: _Categories2.default
    }
};