"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
// import NotFound from '../containers/NotFound'
// import EmailVerify from '../containers/EmailVerify'

// export default {
//     path: 'account',
//     indexRoute: {
//         component: NotFound,
//         fullscreen: true
//     },
//     childRoutes: [
//         {
//             path: 'email-verify',
//             component: EmailVerify,
//             fullscreen: true
//         }
//     ]
// }

exports.default = {};