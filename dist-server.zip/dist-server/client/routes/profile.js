'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _UserProfile = require('../containers/4.2/UserProfile');

var _UserProfile2 = _interopRequireDefault(_UserProfile);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    path: ':username',
    indexRoute: {
        component: _UserProfile2.default
    }
    // childRoutes: [
    //     {
    //         path: 'kompetisi/dipasang',
    //         component: Jelajah
    //     }       
    // ]
};