'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _CompetitionDetail = require('../containers/4.2/CompetitionDetail');

var _CompetitionDetail2 = _interopRequireDefault(_CompetitionDetail);

var _CompetitionIframe = require('../containers/4.2/CompetitionIframe');

var _CompetitionIframe2 = _interopRequireDefault(_CompetitionIframe);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    childRoutes: [{
        path: 'kompetisi',
        childRoutes: [{
            path: 'peraturan/:encid(/:title)',
            name: 'competition_regulation',
            active_tab: 1,
            component: _CompetitionDetail2.default
        }, {
            path: 'detail/:encid(/:title)',
            name: 'competition_regulation',
            active_tab: 1,
            component: _CompetitionDetail2.default
        }, {
            path: 'hadiah/:encid(/:title)',
            active_tab: 2,
            component: _CompetitionDetail2.default
        }, {
            path: 'diskusi/:encid(/:title)',
            active_tab: 3,
            component: _CompetitionDetail2.default
        }, {
            path: 'pengumuman/:encid(/:title)',
            active_tab: 4,
            component: _CompetitionDetail2.default
        }, {
            path: 'kontak/:encid(/:title)',
            active_tab: 5,
            component: _CompetitionDetail2.default
        }, {
            path: 'share/:encid(/:title)',
            active_tab: 6,
            component: _CompetitionDetail2.default
        }, {
            path: 'sumber/:encid(/:title)',
            iframe_type: 'sumber',
            component: _CompetitionIframe2.default
        }, {
            path: 'ikuti/:encid(/:title)',
            iframe_type: 'ikuti',
            component: _CompetitionIframe2.default
        }]
    }, {
        path: 'competition',
        childRoutes: [{
            path: ':encid/regulations(/:title)',
            name: 'competition_regulation',
            active_tab: 1,
            component: _CompetitionDetail2.default
        }, {
            path: ':encid/detail(/:title)',
            name: 'competition_regulation',
            active_tab: 1,
            component: _CompetitionDetail2.default
        }, {
            path: ':encid/prizes(/:title)',
            active_tab: 2,
            component: _CompetitionDetail2.default
        }, {
            path: ':encid/annoucements(/:title)',
            active_tab: 3,
            component: _CompetitionDetail2.default
        }, {
            path: ':encid/discussions(/:title)',
            active_tab: 4,
            component: _CompetitionDetail2.default
        }, {
            path: ':encid/contacts(/:title)',
            active_tab: 5,
            component: _CompetitionDetail2.default
        }, {
            path: ':encid/share(/:title)',
            active_tab: 6,
            component: _CompetitionDetail2.default
        }, {
            path: ':encid/source(/:title)',
            iframe_type: 'sumber',
            component: _CompetitionIframe2.default
        }, {
            path: ':encid/join(/:title)',
            iframe_type: 'ikuti',
            component: _CompetitionIframe2.default
        }, {
            path: ':encid',
            active_tab: 1,
            component: _CompetitionDetail2.default
        }]
    }]
};