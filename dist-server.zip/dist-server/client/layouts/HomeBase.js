'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _Header = require('../components/Header');

var _Header2 = _interopRequireDefault(_Header);

var _Footer = require('../components/Footer');

var _Footer2 = _interopRequireDefault(_Footer);

var _TopAds = require('../components/ads/TopAds');

var _TopAds2 = _interopRequireDefault(_TopAds);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var HomeBase = function (_React$Component) {
    _inherits(HomeBase, _React$Component);

    function HomeBase() {
        _classCallCheck(this, HomeBase);

        return _possibleConstructorReturn(this, (HomeBase.__proto__ || Object.getPrototypeOf(HomeBase)).apply(this, arguments));
    }

    _createClass(HomeBase, [{
        key: 'componentDidMount',
        value: function componentDidMount() {
            topProgress.progress = $('#top-progress-bar');
        }
    }, {
        key: 'componentDidUpdate',
        value: function componentDidUpdate() {
            document.addEventListener('fb_init', function (e) {
                return FB.XFBML.parse();
            });
        }
    }, {
        key: 'render',
        value: function render() {
            var _props$children$props = this.props.children.props.route,
                fullscreen = _props$children$props.fullscreen,
                ads = _props$children$props.ads,
                isRed = _props$children$props.isRed;

            return _react2.default.createElement(
                'div',
                null,
                _react2.default.createElement(
                    'div',
                    { className: 'progress-container' },
                    _react2.default.createElement('div', { id: 'top-progress-bar', className: 'progress-bar' })
                ),
                _react2.default.createElement('div', { id: 'darkmasking' }),
                !fullscreen ? _react2.default.createElement(
                    'div',
                    null,
                    typeof window != 'undefined' ? __data__.User.session.data && __data__.User.session.data.is_verified != 1 ? _react2.default.createElement(
                        'div',
                        { style: { margin: 0 }, className: 'alert alert-warning' },
                        _react2.default.createElement(
                            'div',
                            { className: 'container' },
                            _react2.default.createElement(
                                'strong',
                                null,
                                'Satu langkah lagi'
                            ),
                            ' anda belum melakukan konfirmasi email, silahkan cek email untuk melanjutkan'
                        )
                    ) : null : null,
                    ads ? _react2.default.createElement(_TopAds2.default, null) : null,
                    _react2.default.createElement(_Header2.default, { isRed: isRed, query: this.props.location.query })
                ) : null,
                this.props.children,
                _react2.default.createElement(
                    'div',
                    { style: { display: 'none' }, id: 'fullalert-success', className: 'fullalert fullalert-success' },
                    _react2.default.createElement(
                        'strong',
                        null,
                        'sukses '
                    ),
                    ' ',
                    _react2.default.createElement('span', { className: 'fullalert-text' }),
                    ' ',
                    _react2.default.createElement(
                        'a',
                        { onClick: function onClick() {
                                return fullalert.close();
                            }, href: 'javascript:;' },
                        '(x)'
                    )
                ),
                _react2.default.createElement(
                    'div',
                    { style: { display: 'none' }, id: 'fullalert-error', className: 'fullalert fullalert-error' },
                    _react2.default.createElement(
                        'strong',
                        null,
                        'maaf '
                    ),
                    ' ',
                    _react2.default.createElement('span', { className: 'fullalert-text' }),
                    ' ',
                    _react2.default.createElement(
                        'a',
                        { onClick: function onClick() {
                                return fullalert.close();
                            }, href: 'javascript:;' },
                        '(x)'
                    )
                ),
                _react2.default.createElement(
                    'div',
                    { style: { display: 'none' }, id: 'fullalert-loading', className: 'fullalert fullalert-loading' },
                    _react2.default.createElement(
                        'strong',
                        null,
                        'tunggu sebentar '
                    ),
                    ' ',
                    _react2.default.createElement('span', { className: 'fullalert-text' })
                ),
                !fullscreen ? _react2.default.createElement(_Footer2.default, null) : null,
                _react2.default.createElement(
                    'button',
                    { id: 'btn-up', style: { display: 'none', position: 'fixed', bottom: '10px', zIndex: 10, right: '10px' }, className: 'btn btn-lg' },
                    _react2.default.createElement('i', { className: 'glyphicon glyphicon-chevron-up' })
                )
            );
        }
    }]);

    return HomeBase;
}(_react2.default.Component);

exports.default = HomeBase;