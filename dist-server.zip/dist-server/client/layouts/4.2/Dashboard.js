'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _Footer = require('../../components/4.2/Footer');

var _Footer2 = _interopRequireDefault(_Footer);

var _Header = require('../../components/4.2/Header');

var _Header2 = _interopRequireDefault(_Header);

var _SidebarDashboard = require('../../components/4.2/navigations/SidebarDashboard');

var _SidebarDashboard2 = _interopRequireDefault(_SidebarDashboard);

var _reactRouter = require('react-router');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dashboard = function (_Component) {
    _inherits(Dashboard, _Component);

    function Dashboard(props) {
        _classCallCheck(this, Dashboard);

        var _this = _possibleConstructorReturn(this, (Dashboard.__proto__ || Object.getPrototypeOf(Dashboard)).call(this, props));

        _this.state = {
            q: _this.props.children.props.location.query.q || ''
        };
        return _this;
    }

    _createClass(Dashboard, [{
        key: 'componentDidMount',
        value: function componentDidMount() {
            var q = this.props.children.props.location.query.q;

            if (q) this.setState({ q: q });
        }
    }, {
        key: 'render',
        value: function render() {
            var _this2 = this;

            var q = this.state.q;

            return _react2.default.createElement(
                'div',
                null,
                _react2.default.createElement(_Header2.default, {
                    q: q,
                    setState: function setState(obj) {
                        return _this2.setState(obj);
                    }
                }),
                _react2.default.createElement(
                    'div',
                    { className: 'col-md-12' },
                    _react2.default.createElement(
                        'div',
                        { className: 'row m-t-2em' },
                        _react2.default.createElement(_SidebarDashboard2.default, null),
                        _react2.default.createElement(
                            'div',
                            { className: 'col-md-10' },
                            this.props.children
                        )
                    )
                ),
                _react2.default.createElement(_Footer2.default, null),
                _react2.default.createElement('div', { id: 'fullalert' })
            );
        }
    }]);

    return Dashboard;
}(_react.Component);

exports.default = Dashboard;