'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _redux = require('redux');

var _consts = require('../consts');

var _Normalizer = require('../helpers/Normalizer');

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function data() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var action = arguments[1];

    var nextstate = {};
    switch (action.type) {
        case _consts.REQUEST_DATA:
            if (action.target === 'berita_list') {
                nextstate = state;
                if (!nextstate[action.filter]) nextstate[action.filter] = {};
                nextstate[action.filter].is_loading = true;
                return Object.assign({}, state, nextstate);
            }

        case _consts.RECEIVE_DATA:
            if (action.target === 'berita_list') {
                state[action.filter].is_loading = false;
                return Object.assign({}, state, _defineProperty({}, action.filter, action.json));
            }

        case _consts.RECEIVE_MORE_DATA:
            if (action.target === 'berita_list') {
                state[action.filter].is_loading = false;
                nextstate = state;
                nextstate[action.filter].meta = action.json.meta;
                if (parseInt(action.json.meta.code) === 200) {
                    nextstate.data = (0, _Normalizer.pushData)(nextstate[action.filter].data, action.json.data);
                }
                return Object.assign({}, state, nextstate);
            }

        default:
            return state;
    }
}

function detail() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var action = arguments[1];

    var nextstate = {};
    var target = action.target;

    switch (action.type) {
        case _consts.REQUEST_DATA:
            if (target === 'berita_detail') {
                nextstate = state;
                if (!nextstate[action.filter]) nextstate[action.filter] = {};
                nextstate[action.filter].is_loading = true;
                return Object.assign({}, state, nextstate);
            }
            return state;

        case _consts.RECEIVE_DATA:
            if (target === 'berita_detail') {
                state[action.filter] = action.json;
                state[action.filter].is_loading = false;
                return Object.assign({}, state);
            }
            return state;

        default:
            return state;
    }
}

var reducer = (0, _redux.combineReducers)({
    data: data,
    detail: detail
});
exports.default = reducer;