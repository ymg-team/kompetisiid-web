'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.fetchBeritaDetail = fetchBeritaDetail;
exports.fetchBerita = fetchBerita;
exports.fetchBeritaMore = fetchBeritaMore;
exports.relatedBerita = relatedBerita;

var _url = require('../../server/helpers/url');

var _api = require('../middlewares/api');

var _consts = require('../consts');

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; } /**
                                                                                                                                                                                                                   * الرَّحِيم الرَّحْمَنِ اللَّهِ بِسْمِ
                                                                                                                                                                                                                   * created by yussan 23 Oct 2016 18:29
                                                                                                                                                                                                                   */

function fetchBeritaDetail(id) {
    return _defineProperty({}, _api.CALL_API, {
        method: 'get',
        url: '/api/news/' + id,
        target: 'berita_detail',
        typeWaiting: _consts.REQUEST_DATA,
        typeSuccess: _consts.RECEIVE_DATA,
        filter: id
    });
}

function fetchBerita() {
    var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var filter = arguments[1];

    return _defineProperty({}, _api.CALL_API, {
        method: 'get',
        url: '/api/news?' + (0, _url.serialize)(params),
        target: 'berita_list',
        filter: filter,
        typeSuccess: _consts.RECEIVE_DATA,
        typeWaiting: _consts.REQUEST_DATA
    });
}

function fetchBeritaMore() {
    var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var filter = arguments[1];

    return _defineProperty({}, _api.CALL_API, {
        method: 'get',
        url: '/api/news?' + (0, _url.serialize)(params),
        target: 'berita_list',
        filter: filter,
        typeSuccess: _consts.RECEIVE_MORE_DATA,
        typeWaiting: _consts.REQUEST_DATA
    });
}

function relatedBerita(encid) {
    return _defineProperty({}, _api.CALL_API, {
        method: 'get',
        url: '/api/news/related/' + encid,
        target: 'berita_list',
        filter: 'related_' + encid,
        typeSuccess: _consts.RECEIVE_DATA,
        typeWaiting: _consts.REQUEST_DATA
    });
}