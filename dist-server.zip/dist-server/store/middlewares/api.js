'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.CALL_API = undefined;

var _bluebird = require('bluebird');

var _bluebird2 = _interopRequireDefault(_bluebird);

var _ApiCaller = require('../helpers/ApiCaller');

var _host = require('../../config/host');

var _host2 = _interopRequireDefault(_host);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var CALL_API = exports.CALL_API = Symbol('CALL_API'); /**
                                                       * Created by yussan on 27/10/16.
                                                       */

exports.default = function (store) {
    return function (next) {
        return function (action) {
            if (!action[CALL_API]) return next(action);

            var request = action[CALL_API];
            var typeSuccess = request.typeSuccess,
                typeWaiting = request.typeWaiting,
                method = request.method,
                url = request.url,
                params = request.params,
                filter = request.filter,
                target = request.target,
                _request$formdata = request.formdata,
                formdata = _request$formdata === undefined ? {} : _request$formdata,
                _request$token = request.token,
                token = _request$token === undefined ? '' : _request$token,
                _request$extradata = request.extradata,
                extradata = _request$extradata === undefined ? {} : _request$extradata;


            return new _bluebird2.default(function (resolve, reject) {
                //on request
                if (typeWaiting) {
                    next({
                        type: typeWaiting,
                        filter: filter,
                        target: target
                    });
                }
                //completing request
                (0, _ApiCaller.requestApi)(method, _host2.default[process.env.NODE_ENV].front + url, params, function (json) {
                    // if(method.toLowerCase() === 'post') openNotif(json)

                    next({
                        type: typeSuccess,
                        filter: filter,
                        json: json,
                        target: target,
                        extradata: extradata
                    });

                    resolve();
                }, token);
            });
        };
    };
};