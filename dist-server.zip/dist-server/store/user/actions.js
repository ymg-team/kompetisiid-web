'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.profile = profile;
exports.login = login;
exports.register = register;
exports.oauth = oauth;
exports.emailVerification = emailVerification;
exports.logout = logout;

var _consts = require('../consts');

var _api = require('../middlewares/api');

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; } /**
                                                                                                                                                                                                                   * Created by yussan on 28/01/17.
                                                                                                                                                                                                                   */


function profile(username) {
    return _defineProperty({}, _api.CALL_API, {
        method: 'get',
        url: '/api/user/' + username,
        filter: username,
        target: 'user_profile',
        typeWaiting: _consts.REQUEST_DATA,
        typeSuccess: _consts.RECEIVE_DATA
    });
}

function login(params) {
    return _defineProperty({}, _api.CALL_API, {
        method: 'post',
        url: '/api/user/login',
        params: params,
        target: 'user_login',
        typeWaiting: _consts.REQUEST_DATA,
        typeSuccess: _consts.RECEIVE_DATA
    });
}

function register(params) {
    return _defineProperty({}, _api.CALL_API, {
        method: 'post',
        url: '/api/user/register',
        params: params,
        target: 'user_register',
        typeWaiting: _consts.REQUEST_DATA,
        typeSuccess: _consts.RECEIVE_DATA
    });
}

function oauth(type, params) {
    return _defineProperty({}, _api.CALL_API, {
        method: 'post',
        url: '/api/user/oauth/' + type,
        params: params,
        target: 'user_oauth_' + type,
        typeWaiting: _consts.REQUEST_DATA,
        typeSuccess: _consts.RECEIVE_DATA
    });
}

function emailVerification(token) {
    return _defineProperty({}, _api.CALL_API, {
        method: 'post',
        url: '/api/user/emailverification?token=' + token,
        target: 'user_email_verification',
        typeWaiting: _consts.REQUEST_DATA,
        typeSuccess: _consts.RECEIVE_DATA
    });
}

function logout() {
    return _defineProperty({}, _api.CALL_API, {
        method: 'post',
        url: '/api/user/logout',
        target: 'user_logout',
        typeWaiting: _consts.REQUEST_DATA,
        typeSuccess: _consts.RECEIVE_DATA
    });
}