'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _redux = require('redux');

var _Normalizer = require('../helpers/Normalizer');

var _consts = require('../consts');

function profile() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var action = arguments[1];

    if (action.target === 'user_profile') {
        switch (action.type) {
            case _consts.REQUEST_DATA:
                return (0, _Normalizer.setToLoading)(state, action);

            case _consts.RECEIVE_DATA:
                return (0, _Normalizer.receiveData)(state, action);

            default:
                return state;
        }
    }

    return state;
} /**
   * Created by yussan on 28/01/17.
   */

function login() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var action = arguments[1];

    if (action.target === 'user_login') {
        switch (action.type) {
            case _consts.REQUEST_DATA:
                state.is_loading = true;
                return Object.assign({}, state);

            case _consts.RECEIVE_DATA:
                state.is_loading = false;
                return Object.assign({}, state, action.json);

            default:
                return state;
        }
    }

    if (action.target === 'user_logout') return {};

    return state;
}

function register() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var action = arguments[1];

    if (action.target === 'user_register') {
        switch (action.type) {
            case _consts.REQUEST_DATA:
                state.is_loading = true;
                return Object.assign({}, state);

            case _consts.RECEIVE_DATA:
                state.is_loading = false;
                return Object.assign({}, state, action.json);

            default:
                return state;
        }
    }

    return state;
}

function logout() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var action = arguments[1];

    if (action.target === 'user_logout') {
        switch (action.type) {
            case _consts.REQUEST_DATA:
                state.is_loading = true;
                return Object.assign({}, state);

            case _consts.RECEIVE_DATA:
                state.is_loading = false;
                return Object.assign({}, state, action.json);

            default:
                return state;
        }
    }

    return state;
}

function session() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var action = arguments[1];

    return state;
}

function email_verification() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var action = arguments[1];

    if (action.target === 'user_email_verification') {
        switch (action.type) {
            case _consts.REQUEST_DATA:
                state.is_loading = true;
                return Object.assign({}, state);

            case _consts.RECEIVE_DATA:
                state.is_loading = false;
                return Object.assign({}, state, action.json);

            default:
                return state;
        }
    }

    return state;
}

var reducer = (0, _redux.combineReducers)({
    profile: profile,
    login: login,
    register: register,
    logout: logout,
    session: session,
    email_verification: email_verification
});
exports.default = reducer;