'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.removeById = removeById;
exports.updateByKey = updateByKey;
exports.pushData = pushData;
exports.setToLoading = setToLoading;
exports.receiveData = receiveData;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/**
 * function to remove data by id
 * @params (int) id
 * @params (object) data, structure data = {type1:{result:{}}, type2:{result:{}}
 */
function removeById(id, state, action) {
    Object.keys(state).map(function (n) {
        if (state[n].result) {
            state[n].result.map(function (m, key) {
                if (m.id === id) {
                    state[n].result[key]['is_delete'] = true;
                    if (action.json) {
                        if (action.json.status === 200) {
                            delete state[n].result[key];
                            state[n].total = state[n].total - 1;
                        } else {
                            state[n].result[key]['is_delete'] = false;
                        }
                    }
                }
            });
        }
    });

    return state;
}

/**
 * function to update data by key
 * @param (object) state, full data, structure data = {type1:{result:{}}, type2:{result:{}}}
 * @param (string) key
 * @param (object) json, object from superagent response
 */
function updateByKey(id, state, callback) {
    Object.keys(state).map(function (n) {
        if (state[n].result) {
            state[n].result.map(function (m, key) {
                if (m.id === id) {
                    state[n].result[key] = callback(m);
                }
            });
        }
    });

    return state;
}

/**
 * function to push more data to object javascript
 */
function pushData(currentdata, nextdata) {
    nextdata.map(function (n) {
        currentdata.push(n);
    });
    return currentdata;
}

/**
 * function to set loading state on reducer
 */
function setToLoading(state, action) {
    if (!state[action.filter]) state[action.filter] = {};
    state[action.filter].is_loading = true;
    return Object.assign({}, state);
}

/**
 * function to receive new json 
 */
function receiveData(state, action) {
    return Object.assign({}, state, _defineProperty({}, action.filter, action.json));
}