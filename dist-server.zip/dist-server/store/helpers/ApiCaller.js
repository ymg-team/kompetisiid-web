'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.requestApi = requestApi;

var _superagent = require('superagent');

var _superagent2 = _interopRequireDefault(_superagent);

var _Exceptions = require('./Exceptions');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function requestApi(method, path) {
  var params = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  var callback = arguments[3];

  var formdata = !params || method.toLowerCase() === 'get' ? {} : generateFormdata(params);
  return _superagent2.default[method.toLowerCase()](path).withCredentials().timeout(60000).set('Accept', 'application/json').send(formdata).on('error', function () {
    return callback((0, _Exceptions.httpException)(500, 'internal error', true));
  }).end(function (err, res) {
    if (err) {
      return callback((0, _Exceptions.httpException)(500, err, true));
    } else {
      return callback(JSON.parse(res.text));
    }
  });
}

function generateFormdata(params) {
  var formdata = new FormData();
  // return params
  Object.keys(params).map(function (n) {
    formdata.append(n, params[n]);
  });

  return formdata;
}