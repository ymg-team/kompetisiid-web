'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _reducer = require('./kompetisi/reducer');

var _reducer2 = _interopRequireDefault(_reducer);

var _reducer3 = require('./berita/reducer');

var _reducer4 = _interopRequireDefault(_reducer3);

var _reducer5 = require('./pasang/reducer');

var _reducer6 = _interopRequireDefault(_reducer5);

var _reducer7 = require('./user/reducer');

var _reducer8 = _interopRequireDefault(_reducer7);

var _redux = require('redux');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var Reducers = (0, _redux.combineReducers)({
    Kompetisi: _reducer2.default,
    Berita: _reducer4.default,
    Pasang: _reducer6.default,
    User: _reducer8.default
}); /**
     * Created by yussan on 02/10/16.
     */
exports.default = Reducers;