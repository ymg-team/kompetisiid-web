'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.RECEIVE_CATEGORIES = undefined;
exports.fetchJelajah = fetchJelajah;
exports.getRelated = getRelated;
exports.getCategories = getCategories;
exports.setCategories = setCategories;
exports.getJelajah = getJelajah;
exports.getJelajahMore = getJelajahMore;
exports.getDetail = getDetail;
exports.getPengumuman = getPengumuman;
exports.getFavoritedTags = getFavoritedTags;
exports.getStats = getStats;

var _ApiCaller = require('../helpers/ApiCaller');

var _consts = require('../consts');

var _url = require('../../server/helpers/url');

var _api = require('../middlewares/api');

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var RECEIVE_CATEGORIES = exports.RECEIVE_CATEGORIES = 'RECEIVE_CATEGORIES';

function fetchJelajah(params, filter) {
    var url = '/api/jelajah';
    return _defineProperty({}, _api.CALL_API, {
        typeSuccess: _consts.RECEIVE_DATA,
        typeWaiting: _consts.REQUEST_DATA,
        filter: filter,
        method: 'get',
        target: 'kompetisi_jelajah',
        url: url + '?' + (0, _url.serialize)(params)
    });
}

function getRelated(id, filter) {
    return _defineProperty({}, _api.CALL_API, {
        typeSuccess: _consts.RECEIVE_DATA,
        typeWaiting: _consts.REQUEST_DATA,
        method: 'get',
        filter: filter,
        target: 'kompetisi_related',
        url: '/api/kompetisi/related/' + id
    });
}

function getCategories() {
    return _defineProperty({}, _api.CALL_API, {
        typeSuccess: _consts.RECEIVE_DATA,
        typeWaiting: _consts.REQUEST_DATA,
        method: 'get',
        target: 'kompetisi_categories',
        url: '/api/kompetisi/kategori'
    });
}

function setCategories(json) {
    return {
        type: _consts.RECEIVE_DATA,
        json: json,
        target: 'kompetisi_categories'
    };
}

function getJelajah(params, filter) {
    return function (dispatch) {
        dispatch(receiveJelajah(filter));
        (0, _ApiCaller.requestApi)('get', '/api/jelajah?' + (0, _url.serialize)(params), params, function (res) {
            dispatch(receiveJelajah(filter, res));
        });
    };
}

function getJelajahMore(params, filter) {
    return function (dispatch) {
        dispatch(receiveJelajahMore(filter));
        (0, _ApiCaller.requestApi)('get', '/api/jelajah?' + (0, _url.serialize)(params), params, function (res) {
            dispatch(receiveJelajahMore(filter, res));
        });
    };
}

function getDetail(id) {
    return _defineProperty({}, _api.CALL_API, {
        url: '/api/kompetisi/' + id,
        method: 'get',
        typeWaiting: _consts.REQUEST_DATA,
        typeSuccess: _consts.RECEIVE_DATA,
        target: 'kompetisi_detail',
        filter: id
    });
}

function getPengumuman(id) {
    return _defineProperty({}, _api.CALL_API, {
        url: '/api/kompetisi/pengumuman/' + id,
        method: 'get',
        typeWaiting: _consts.REQUEST_DATA,
        typeSuccess: _consts.RECEIVE_DATA,
        target: 'kompetisi_pengumuman',
        filter: id
    });
}

function getFavoritedTags() {
    var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

    return _defineProperty({}, _api.CALL_API, {
        url: '/api/kompetisi/favoritedtags',
        method: 'get',
        typeWaiting: _consts.REQUEST_DATA,
        typeSuccess: _consts.RECEIVE_DATA,
        target: 'tags',
        filter: 'favorited'
    });
}

function getStats() {
    return _defineProperty({}, _api.CALL_API, {
        url: '/api/stats',
        method: 'get',
        typeWaiting: _consts.REQUEST_DATA,
        typeSuccess: _consts.RECEIVE_DATA,
        target: 'stats'
    });
}

function receiveJelajah(filter) {
    var json = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

    var type = void 0,
        target = void 0;
    if (!json) {
        type = _consts.REQUEST_DATA;
        target = 'kompetisi_jelajah';
    } else {
        type = _consts.RECEIVE_DATA;
        target = 'kompetisi_jelajah';
    }
    return {
        type: type,
        target: target,
        filter: filter,
        json: json
    };
}

function receiveJelajahMore(filter) {
    var json = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

    var type = void 0,
        target = void 0;
    if (!json) {
        type = _consts.REQUEST_DATA;
        target = 'kompetisi_jelajah';
    } else {
        type = _consts.RECEIVE_MORE_DATA;
        target = 'kompetisi_jelajah';
    }
    return {
        type: type,
        target: target,
        filter: filter,
        json: json
    };
}