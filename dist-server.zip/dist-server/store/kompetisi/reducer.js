'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _redux = require('redux');

var _Normalizer = require('../helpers/Normalizer');

var _actions = require('./actions');

var _consts = require('../consts');

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function data() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var action = arguments[1];

    var nextstate = {};
    var target = action.target,
        filter = action.filter;

    switch (action.type) {
        case _consts.REQUEST_DATA:
            nextstate = state;

            if (action.target === 'kompetisi_jelajah') {
                if (!nextstate[action.filter]) nextstate[action.filter] = {};
                nextstate[action.filter].is_loading = true;
                return Object.assign({}, state, nextstate);
            }

            return state;

        case _consts.RECEIVE_DATA:

            if (target === 'kompetisi_jelajah') {
                state[filter] = action.json;
                state[filter].is_loading = false;
                return Object.assign({}, state);
            }
            return state;

        case _consts.RECEIVE_MORE_DATA:
            if (action.target === 'kompetisi_jelajah') {
                state[action.filter].is_loading = false;
                nextstate = state;
                nextstate[action.filter].meta = action.json.meta;
                if (parseInt(action.json.meta.code) === 200) {
                    nextstate.data = (0, _Normalizer.pushData)(nextstate[action.filter].data, action.json.data);
                }
                return Object.assign({}, state, nextstate);
            }

        default:
            return state;
    }
}

function detail() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var action = arguments[1];

    switch (action.type) {
        case _consts.REQUEST_DATA:
            if (action.target === 'kompetisi_detail') {
                if (!state[action.filter]) state[action.filter] = {};
                state[action.filter].is_loading = true;
                return Object.assign({}, state);
            }

        case _consts.RECEIVE_DATA:
            if (action.target === 'kompetisi_detail') {
                state[action.filter].is_loading = false;
                state[action.filter] = action.json;
                return Object.assign({}, state);
            }

        default:
            return state;
    }
}

function related() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var action = arguments[1];
    var target = action.target,
        filter = action.filter;

    switch (action.type) {
        case _consts.REQUEST_DATA:
            if (target === 'kompetisi_related') {
                if (!state[filter]) state[filter] = {};
                state[filter].is_loading = true;
                return Object.assign({}, state);
            }
            return state;

        case _consts.RECEIVE_DATA:
            if (target === 'kompetisi_related') {
                state[action.filter].is_loading = false;
                state[action.filter] = action.json;
                return Object.assign({}, state);
            }
            return state;

        default:
            return state;
    }
}

function categories() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var action = arguments[1];

    switch (action.type) {
        case _consts.RECEIVE_DATA:
            if (action.target === 'kompetisi_categories') {
                return Object.assign({}, state, action.json);
            }
            return state;

        default:
            return state;
    }
}

function pengumuman() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var action = arguments[1];
    var target = action.target,
        filter = action.filter;

    switch (action.type) {
        case _consts.REQUEST_DATA:
            if (target === 'kompetisi_pengumuman') {
                if (!state[filter]) state[filter] = {};
                state[filter].is_loading = true;
                return Object.assign({}, state);
            }
            return state;

        case _consts.RECEIVE_DATA:
            if (target === 'kompetisi_pengumuman') {
                state[filter].is_loading = false;
                state[filter] = action.json;
                return Object.assign({}, state);
            }
            return state;

        default:
            return state;
    }
}

function tags() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var action = arguments[1];

    if (action.target === 'tags') {
        switch (action.type) {
            case _consts.REQUEST_DATA:
                return Object.assign({}, state, _defineProperty({}, action.filter, { is_loading: true }));

            case _consts.RECEIVE_DATA:
                return Object.assign({}, state, _defineProperty({}, action.filter, { is_loading: true }), _defineProperty({}, action.filter, action.json));

            default:
                return state;
        }
    }

    return state;
}

function stats() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var action = arguments[1];

    if (action.target === 'stats') {
        switch (action.type) {
            case _consts.REQUEST_DATA:
                return Object.assign({}, state, { is_loading: true });

            case _consts.RECEIVE_DATA:
                return Object.assign({}, state, { is_loading: false }, action.json);

            default:
                return state;
        }
    }

    return state;
}

var reducer = (0, _redux.combineReducers)({
    data: data, related: related, detail: detail, categories: categories, pengumuman: pengumuman, tags: tags, stats: stats
});
exports.default = reducer;