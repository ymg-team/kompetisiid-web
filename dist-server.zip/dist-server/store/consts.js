'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.expectedAction = exports.POST_DATA = exports.DELETE_DATA = exports.RECEIVE_MORE_DATA = exports.RECEIVE_DATA = exports.REQUEST_DATA = undefined;

var _api = require('./middlewares/api');

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/**
 * Created by yussan on 20/10/16.
 */
var REQUEST_DATA = exports.REQUEST_DATA = 'REQUEST_DATA';
var RECEIVE_DATA = exports.RECEIVE_DATA = 'RECEIVE_DATA';
var RECEIVE_MORE_DATA = exports.RECEIVE_MORE_DATA = 'RECEIVE_MORE_DATA';
var DELETE_DATA = exports.DELETE_DATA = 'DELETE_DATA';
var POST_DATA = exports.POST_DATA = 'POST_DATA';

// for tester
var expectedAction = exports.expectedAction = _defineProperty({}, _api.CALL_API, {
    method: '',
    url: '',
    successType: ''
});