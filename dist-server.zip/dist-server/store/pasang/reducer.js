'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _redux = require('redux');

var _Normalizer = require('../helpers/Normalizer');

var _consts = require('../consts');

function cepat() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var action = arguments[1];

    if (action.target === 'pasang_cepat') {
        switch (action.type) {
            case _consts.REQUEST_DATA:
                state.is_loading = true;
                return Object.assign({}, state);

            case _consts.RECEIVE_DATA:
                state.is_loading = false;
                return Object.assign({}, state, action.json);

            default:
                return state;
        }
    } else {
        return state;
    }
} /**
   * Created by yussan on 13/11/16.
   */


function komplit() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var action = arguments[1];

    if (action.target === 'pasang_komplit') {
        switch (action.type) {
            case _consts.REQUEST_DATA:
                return (0, _Normalizer.setToLoading)(state, action);

            case _consts.RECEIVE_DATA:
                return state;

            default:
                return state;
        }
    } else {
        return state;
    }
}

var reducer = (0, _redux.combineReducers)({
    cepat: cepat, komplit: komplit
});
exports.default = reducer;