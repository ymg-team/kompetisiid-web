'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.submitCepat = submitCepat;

var _consts = require('../consts');

var _api = require('../middlewares/api');

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; } /**
                                                                                                                                                                                                                   * Created by yussan on 13/11/16.
                                                                                                                                                                                                                   */


function submitCepat(params) {
    return _defineProperty({}, _api.CALL_API, {
        method: 'post',
        url: '/api/pasang/cepat',
        params: params,
        target: 'pasang_cepat',
        typeWaiting: _consts.REQUEST_DATA,
        typeSuccess: _consts.RECEIVE_DATA
    });
}